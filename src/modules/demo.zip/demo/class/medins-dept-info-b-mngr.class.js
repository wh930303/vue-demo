/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:26:02
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/medins-dept-info-b-mngr.class.js
 */
class MedinsDeptInfoBClass {
  constructor (
    medinsDeptInfoId,
    medinsCode,
    natDeptCode,
    hospDeptCode,
    hospDeptName,
    itro,
    begntime,
    endtime,
    deptResperName,
    deptResperTel,
    deptMedServScp,
    bedCnt,
    drPsncnt,
    pharPsncnt,
    nursPsncnt,
    tecnPsncnt,
    valiFlag,
    rid,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea,
    updtTime
  ) {
    this.medinsDeptInfoId = medinsDeptInfoId
    this.medinsCode = medinsCode
    this.natDeptCode = natDeptCode
    this.hospDeptCode = hospDeptCode
    this.hospDeptName = hospDeptName
    this.itro = itro
    this.begntime = begntime
    this.endtime = endtime
    this.deptResperName = deptResperName
    this.deptResperTel = deptResperTel
    this.deptMedServScp = deptMedServScp
    this.bedCnt = bedCnt
    this.drPsncnt = drPsncnt
    this.pharPsncnt = pharPsncnt
    this.nursPsncnt = nursPsncnt
    this.tecnPsncnt = tecnPsncnt
    this.valiFlag = valiFlag
    this.rid = rid
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
    this.updtTime = updtTime
  }
}

export default MedinsDeptInfoBClass
