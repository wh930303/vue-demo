class ReflAppyDClass {
  constructor (
    trtDclaDetlSn,
    insutype,
    dclaSouc,
    psnNo,
    psnInsuRltsId,
    certType,
    certno,
    psnName,
    gend,
    brdy,
    tel,
    addr,
    insuOptins,
    empNo,
    empName,
    fixmedinsCode,
    fixmedinsName,
    medinsLv,
    fixmedinsPoolarea,
    diseCode,
    diseName,
    drord,
    diseCondDscr,
    reflinMedinsNo,
    reflinMedinsName,
    turnaroundHospLv,
    outFlag,
    reflDate,
    reflRea,
    reflSetlFlag,
    agntName,
    agntCertType,
    agntCertno,
    agntTel,
    agntAddr,
    agntRlts,
    begndate,
    enddate,
    reflOldMdtrtId,
    setlId,
    mdtrtEvtId,
    valiFlag,
    memo,
    rid,
    updtTime,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea
  ) {
    this.trtDclaDetlSn = trtDclaDetlSn
    this.insutype = insutype
    this.dclaSouc = dclaSouc
    this.psnNo = psnNo
    this.psnInsuRltsId = psnInsuRltsId
    this.certType = certType
    this.certno = certno
    this.psnName = psnName
    this.gend = gend
    this.brdy = brdy
    this.tel = tel
    this.addr = addr
    this.insuOptins = insuOptins
    this.empNo = empNo
    this.empName = empName
    this.fixmedinsCode = fixmedinsCode
    this.fixmedinsName = fixmedinsName
    this.medinsLv = medinsLv
    this.fixmedinsPoolarea = fixmedinsPoolarea
    this.diseCode = diseCode
    this.diseName = diseName
    this.drord = drord
    this.diseCondDscr = diseCondDscr
    this.reflinMedinsNo = reflinMedinsNo
    this.reflinMedinsName = reflinMedinsName
    this.turnaroundHospLv = turnaroundHospLv
    this.outFlag = outFlag
    this.reflDate = reflDate
    this.reflRea = reflRea
    this.reflSetlFlag = reflSetlFlag
    this.agntName = agntName
    this.agntCertType = agntCertType
    this.agntCertno = agntCertno
    this.agntTel = agntTel
    this.agntAddr = agntAddr
    this.agntRlts = agntRlts
    this.begndate = begndate
    this.enddate = enddate
    this.reflOldMdtrtId = reflOldMdtrtId
    this.setlId = setlId
    this.mdtrtEvtId = mdtrtEvtId
    this.valiFlag = valiFlag
    this.memo = memo
    this.rid = rid
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
  }
}

export default ReflAppyDClass
