class TrumChkRegDClass {
  constructor (
    trtDclaDetlSn,
    insutype,
    dclaSouc,
    psnNo,
    psnInsuRltsId,
    begndate,
    enddate,
    certType,
    certno,
    psnName,
    gend,
    naty,
    brdy,
    tel,
    addr,
    insuOptins,
    empNo,
    empName,
    mdtrtEvtId,
    setlId,
    fixmedinsCode,
    fixmedinsName,
    medinsLv,
    fixmedinsPoolarea,
    trumPart,
    trumTime,
    trumSite,
    trumRea,
    admMtd,
    admTime,
    admDise,
    agntName,
    agntCertType,
    agntCertno,
    agntTel,
    agntAddr,
    agntRlts,
    chkPayFlag,
    usedStas,
    valiFlag,
    memo,
    rid,
    updtTime,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea
  ) {
    this.trtDclaDetlSn = trtDclaDetlSn
    this.insutype = insutype
    this.dclaSouc = dclaSouc
    this.psnNo = psnNo
    this.psnInsuRltsId = psnInsuRltsId
    this.begndate = begndate
    this.enddate = enddate
    this.certType = certType
    this.certno = certno
    this.psnName = psnName
    this.gend = gend
    this.naty = naty
    this.brdy = brdy
    this.tel = tel
    this.addr = addr
    this.insuOptins = insuOptins
    this.empNo = empNo
    this.empName = empName
    this.mdtrtEvtId = mdtrtEvtId
    this.setlId = setlId
    this.fixmedinsCode = fixmedinsCode
    this.fixmedinsName = fixmedinsName
    this.medinsLv = medinsLv
    this.fixmedinsPoolarea = fixmedinsPoolarea
    this.trumPart = trumPart
    this.trumTime = trumTime
    this.trumSite = trumSite
    this.trumRea = trumRea
    this.admMtd = admMtd
    this.admTime = admTime
    this.admDise = admDise
    this.agntName = agntName
    this.agntCertType = agntCertType
    this.agntCertno = agntCertno
    this.agntTel = agntTel
    this.agntAddr = agntAddr
    this.agntRlts = agntRlts
    this.chkPayFlag = chkPayFlag
    this.usedStas = usedStas
    this.valiFlag = valiFlag
    this.memo = memo
    this.rid = rid
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
  }
}

export default TrumChkRegDClass
