/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:25:51
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/hilist-b-mngr.class.js
 */
class HilistBClass {
  constructor (
    hilistCode,
    hilistName,
    begndate,
    enddate,
    medChrgitmType,
    chrgitmLv,
    lmtUsedFlag,
    crteOptins,
    opter,
    opterName,
    optTime,
    hilistType,
    listType,
    medUseFlag,
    matnUseFlag,
    hilistUseType,
    lmtCpndType,
    wubi,
    pinyin,
    memo,
    valiFlag,
    rid,
    updtTime,
    optins,
    poolarea,
    insuOptins,
    crter,
    crterName,
    crteTime
  ) {
    this.hilistCode = hilistCode
    this.hilistName = hilistName
    this.begndate = begndate
    this.enddate = enddate
    this.medChrgitmType = medChrgitmType
    this.chrgitmLv = chrgitmLv
    this.lmtUsedFlag = lmtUsedFlag
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.hilistType = hilistType
    this.listType = listType
    this.medUseFlag = medUseFlag
    this.matnUseFlag = matnUseFlag
    this.hilistUseType = hilistUseType
    this.lmtCpndType = lmtCpndType
    this.wubi = wubi
    this.pinyin = pinyin
    this.memo = memo
    this.valiFlag = valiFlag
    this.rid = rid
    this.updtTime = updtTime
    this.optins = optins
    this.poolarea = poolarea
    this.insuOptins = insuOptins
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
  }
}

export default HilistBClass
