/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:25:56
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/insu-emp-info-b-mngr.class.js
 */
class InsuEmpInfoBClass {
  constructor (
    empNo,
    empEnttCodg,
    empMgtType,
    prntEmpNo,
    asocLegentFlag,
    empType,
    empName,
    regName,
    locAdmdvs,
    conerName,
    conerEmail,
    tel,
    faxNo,
    taxNo,
    orgcode,
    regno,
    regnoCertType,
    empAddr,
    poscode,
    aprvEstaDept,
    aprvEstaDate,
    aprvEstaDocno,
    prntAdmdvs,
    insuOptins,
    orgValiStas,
    legrepTel,
    legrepName,
    legrepCertType,
    legrepCertno,
    orgcodeIssuEmp,
    valiFlag,
    rid,
    crteTime,
    updtTime,
    crter,
    crterName,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea,
    ver
  ) {
    this.empNo = empNo
    this.empEnttCodg = empEnttCodg
    this.empMgtType = empMgtType
    this.prntEmpNo = prntEmpNo
    this.asocLegentFlag = asocLegentFlag
    this.empType = empType
    this.empName = empName
    this.regName = regName
    this.locAdmdvs = locAdmdvs
    this.conerName = conerName
    this.conerEmail = conerEmail
    this.tel = tel
    this.faxNo = faxNo
    this.taxNo = taxNo
    this.orgcode = orgcode
    this.regno = regno
    this.regnoCertType = regnoCertType
    this.empAddr = empAddr
    this.poscode = poscode
    this.aprvEstaDept = aprvEstaDept
    this.aprvEstaDate = aprvEstaDate
    this.aprvEstaDocno = aprvEstaDocno
    this.prntAdmdvs = prntAdmdvs
    this.insuOptins = insuOptins
    this.orgValiStas = orgValiStas
    this.legrepTel = legrepTel
    this.legrepName = legrepName
    this.legrepCertType = legrepCertType
    this.legrepCertno = legrepCertno
    this.orgcodeIssuEmp = orgcodeIssuEmp
    this.valiFlag = valiFlag
    this.rid = rid
    this.crteTime = crteTime
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
    this.ver = ver
  }
}

export default InsuEmpInfoBClass
