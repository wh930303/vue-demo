/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:26:21
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/psn-insu-d-mngr-query.class.js
 */
class PsnInsuDQueryClass {
  constructor (
    psnInsuMgtEid,
    psnInsuRltsId,
    empNo,
    psnNo,
    hiType,
    insutype,
    psnInsuStas,
    acctCrtnYm,
    fstInsuYm,
    crtInsuDate,
    psnInsuDate,
    pausInsuDate,
    insutypeRetrFlag,
    qudtType,
    clctWay,
    empFom,
    maxAcctprd,
    clctRuleTypeCodg,
    clctstdCrtfRuleCodg,
    insuOrg,
    optins,
    optTime,
    opterName,
    opter,
    poolarea,
    crteTime,
    rid,
    updtTime,
    psnType,
    crter,
    crterName,
    crteOptins
  ) {
    this.psnInsuMgtEid = psnInsuMgtEid
    this.psnInsuRltsId = psnInsuRltsId
    this.empNo = empNo
    this.psnNo = psnNo
    this.hiType = hiType
    this.insutype = insutype
    this.psnInsuStas = psnInsuStas
    this.acctCrtnYm = acctCrtnYm
    this.fstInsuYm = fstInsuYm
    this.crtInsuDate = crtInsuDate
    this.psnInsuDate = psnInsuDate
    this.pausInsuDate = pausInsuDate
    this.insutypeRetrFlag = insutypeRetrFlag
    this.qudtType = qudtType
    this.clctWay = clctWay
    this.empFom = empFom
    this.maxAcctprd = maxAcctprd
    this.clctRuleTypeCodg = clctRuleTypeCodg
    this.clctstdCrtfRuleCodg = clctstdCrtfRuleCodg
    this.insuOrg = insuOrg
    this.optins = optins
    this.optTime = optTime
    this.opterName = opterName
    this.opter = opter
    this.poolarea = poolarea
    this.crteTime = crteTime
    this.rid = rid
    this.updtTime = updtTime
    this.psnType = psnType
    this.crter = crter
    this.crterName = crterName
    this.crteOptins = crteOptins
  }
}

export default PsnInsuDQueryClass
