class InfoCodeClass {
  constructor(
    codeId,
    codeType,
    typeName,
    val,
    valName,
    begnDate,
    enddate,
    valiFlag,
    seq,
  ) {
    this.codeId=codeId
    this.codeType=codeType
    this.typeName=typeName
    this.val=val
    this.valName=valName
    this.begnDate=begnDate
    this.enddate=enddate
    this.valiFlag=valiFlag
    this.seq=seq
  }
}

export default InfoCodeClass
