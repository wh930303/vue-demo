/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:26:19
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/psn-info-b-mngr.class.js
 */
class PsnInfoBClass {
  constructor (
    psnNo,
    brdy,
    certNo,
    tel,
    naty,
    addr,
    psnName,
    gend,
    insutype,
    empName,
    insuOptins,
    empCode,
    test,
    rid
  ) {
    this.psnNo = psnNo
    this.brdy = brdy
    this.certNo = certNo
    this.tel = tel
    this.naty = naty
    this.addr = addr
    this.psnName = psnName
    this.gend = gend
    this.insutype = insutype
    this.empName = empName
    this.insuOptins = insuOptins
    this.empCode = empCode
    this.test = test
    this.rid = rid
  }
}

export default PsnInfoBClass
