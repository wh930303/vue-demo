/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:25:52
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/info-code-mngr-query.class.js
 */
class InfoCodeQueryClass {
  constructor (
    codeId,
    codeType,
    typeName,
    val,
    valName,
    begnDate,
    enddate,
    valiFlag,
    seq
  ) {
    this.codeId = codeId
    this.codeType = codeType
    this.typeName = typeName
    this.val = val
    this.valName = valName
    this.begnDate = begnDate
    this.enddate = enddate
    this.valiFlag = valiFlag
    this.seq = seq
  }
}

export default InfoCodeQueryClass
