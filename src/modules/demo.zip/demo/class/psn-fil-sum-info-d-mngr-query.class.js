/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:26:11
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/psn-fil-sum-info-d-mngr-query.class.js
 */
class PsnFilSumInfoDQueryClass {
  constructor (
    trtDclaDetlSn,
    year,
    insutype,
    psnNo,
    psnInsuRltsId,
    psnCertType,
    certno,
    psnName,
    tel,
    insuOptins,
    bizAppyType,
    appyRea,
    begndate,
    enddate,
    valiFlag,
    memo,
    rid,
    updtTime,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea
  ) {
    this.trtDclaDetlSn = trtDclaDetlSn
    this.year = year
    this.insutype = insutype
    this.psnNo = psnNo
    this.psnInsuRltsId = psnInsuRltsId
    this.psnCertType = psnCertType
    this.certno = certno
    this.psnName = psnName
    this.tel = tel
    this.insuOptins = insuOptins
    this.bizAppyType = bizAppyType
    this.appyRea = appyRea
    this.begndate = begndate
    this.enddate = enddate
    this.valiFlag = valiFlag
    this.memo = memo
    this.rid = rid
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
  }
}

export default PsnFilSumInfoDQueryClass
