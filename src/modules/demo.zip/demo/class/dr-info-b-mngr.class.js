/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:25:44
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/dr-info-b-mngr.class.js
 */
class DrInfoBClass {
  constructor (
    drInfoId,
    drCode,
    psnNo,
    psnItro,
    drPracType,
    drPracScpCode,
    pracRegn,
    mulPracFlag,
    mainPracinsNo,
    mainPracinsName,
    mainPracinsAddr,
    nempTime,
    valiFlag,
    rxPermFlag,
    drProTechDuty,
    rid,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    ver
  ) {
    this.drInfoId = drInfoId
    this.drCode = drCode
    this.psnNo = psnNo
    this.psnItro = psnItro
    this.drPracType = drPracType
    this.drPracScpCode = drPracScpCode
    this.pracRegn = pracRegn
    this.mulPracFlag = mulPracFlag
    this.mainPracinsNo = mainPracinsNo
    this.mainPracinsName = mainPracinsName
    this.mainPracinsAddr = mainPracinsAddr
    this.nempTime = nempTime
    this.valiFlag = valiFlag
    this.rxPermFlag = rxPermFlag
    this.drProTechDuty = drProTechDuty
    this.rid = rid
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.ver = ver
  }
}

export default DrInfoBClass
