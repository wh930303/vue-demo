/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:25:46
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/er-chk-reg-d-mngr-query.class.js
 */
class ErChkRegDQueryClass {
  constructor (
    trtDclaDetlSn,
    dclaSouc,
    psnNo,
    psnInsuRltsId,
    certType,
    certno,
    psnName,
    gend,
    naty,
    brdy,
    empNo,
    empName,
    insuOptins,
    insutype,
    mdtrtareaAdmdvs,
    fixmedinsCode,
    fixmedinsName,
    fixmedinsLv,
    admTime,
    admDise,
    condDscr,
    obsvFlag,
    mdtrtsn,
    agntName,
    agntCertType,
    agntCertno,
    agntTel,
    agntAddr,
    agntRlts,
    begndate,
    enddate,
    valiFlag,
    chkStas,
    memo,
    rid,
    updtTime,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea
  ) {
    this.trtDclaDetlSn = trtDclaDetlSn
    this.dclaSouc = dclaSouc
    this.psnNo = psnNo
    this.psnInsuRltsId = psnInsuRltsId
    this.certType = certType
    this.certno = certno
    this.psnName = psnName
    this.gend = gend
    this.naty = naty
    this.brdy = brdy
    this.empNo = empNo
    this.empName = empName
    this.insuOptins = insuOptins
    this.insutype = insutype
    this.mdtrtareaAdmdvs = mdtrtareaAdmdvs
    this.fixmedinsCode = fixmedinsCode
    this.fixmedinsName = fixmedinsName
    this.fixmedinsLv = fixmedinsLv
    this.admTime = admTime
    this.admDise = admDise
    this.condDscr = condDscr
    this.obsvFlag = obsvFlag
    this.mdtrtsn = mdtrtsn
    this.agntName = agntName
    this.agntCertType = agntCertType
    this.agntCertno = agntCertno
    this.agntTel = agntTel
    this.agntAddr = agntAddr
    this.agntRlts = agntRlts
    this.begndate = begndate
    this.enddate = enddate
    this.valiFlag = valiFlag
    this.chkStas = chkStas
    this.memo = memo
    this.rid = rid
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
  }
}

export default ErChkRegDQueryClass
