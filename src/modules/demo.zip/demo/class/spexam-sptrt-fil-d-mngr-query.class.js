class SpexamSptrtFilDQueryClass {
  constructor (
    trtDclaDetlSn,
    dclaSouc,
    insutype,
    psnNo,
    psnInsuRltsId,
    certType,
    certno,
    psnName,
    gend,
    brdy,
    tel,
    addr,
    insuOptins,
    empNo,
    empName,
    bilgDeptCodg,
    bilgDeptName,
    bilgDrCodg,
    bilgDrName,
    diseCode,
    diseName,
    diseCondDscr,
    trtInfo,
    hilistType,
    hilistCode,
    hilistName,
    cnt,
    prcunt,
    begndate,
    enddate,
    appyDate,
    appyRea,
    mdtrtEvtId,
    setlId,
    bizUsedFlag,
    valiFlag,
    memo,
    rid,
    updtTime,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    poolarea
  ) {
    this.trtDclaDetlSn = trtDclaDetlSn
    this.dclaSouc = dclaSouc
    this.insutype = insutype
    this.psnNo = psnNo
    this.psnInsuRltsId = psnInsuRltsId
    this.certType = certType
    this.certno = certno
    this.psnName = psnName
    this.gend = gend
    this.brdy = brdy
    this.tel = tel
    this.addr = addr
    this.insuOptins = insuOptins
    this.empNo = empNo
    this.empName = empName
    this.bilgDeptCodg = bilgDeptCodg
    this.bilgDeptName = bilgDeptName
    this.bilgDrCodg = bilgDrCodg
    this.bilgDrName = bilgDrName
    this.diseCode = diseCode
    this.diseName = diseName
    this.diseCondDscr = diseCondDscr
    this.trtInfo = trtInfo
    this.hilistType = hilistType
    this.hilistCode = hilistCode
    this.hilistName = hilistName
    this.cnt = cnt
    this.prcunt = prcunt
    this.begndate = begndate
    this.enddate = enddate
    this.appyDate = appyDate
    this.appyRea = appyRea
    this.mdtrtEvtId = mdtrtEvtId
    this.setlId = setlId
    this.bizUsedFlag = bizUsedFlag
    this.valiFlag = valiFlag
    this.memo = memo
    this.rid = rid
    this.updtTime = updtTime
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.poolarea = poolarea
  }
}

export default SpexamSptrtFilDQueryClass
