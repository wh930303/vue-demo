/*
 * @Author: your name
 * @Date: 2022-03-01 21:20:43
 * @LastEditTime: 2022-03-01 21:26:04
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/class/medins-info-b-mngr-query.class.js
 */
class MedinsInfoBQueryClass {
  constructor (
    medinsId,
    medinsNo,
    empNo,
    medinsName,
    medinsAbbr,
    faxNo,
    mainResper,
    admdvs,
    addr,
    medinsNatu,
    medinsType,
    regStas,
    enrdStafPsncnt,
    hospDeptCnt,
    hospKeyDeptCnt,
    senrProfttlPsncnt,
    midProfttlPsncnt,
    proTechstfPsncnt,
    depsenrProfttlPsncnt,
    actOpenBed,
    bizPsncnt,
    othPsncnt,
    bizArea,
    medinslv,
    lnt,
    lat,
    begntime,
    endtime,
    memo,
    grstHospFlag,
    credLv,
    prntMedinsNo,
    medinsPracScpCode,
    medinsPracScpName,
    valiFlag,
    poolarea,
    rid,
    crter,
    crterName,
    crteTime,
    crteOptins,
    opter,
    opterName,
    optTime,
    optins,
    ver
  ) {
    this.medinsId = medinsId
    this.medinsNo = medinsNo
    this.empNo = empNo
    this.medinsName = medinsName
    this.medinsAbbr = medinsAbbr
    this.faxNo = faxNo
    this.mainResper = mainResper
    this.admdvs = admdvs
    this.addr = addr
    this.medinsNatu = medinsNatu
    this.medinsType = medinsType
    this.regStas = regStas
    this.enrdStafPsncnt = enrdStafPsncnt
    this.hospDeptCnt = hospDeptCnt
    this.hospKeyDeptCnt = hospKeyDeptCnt
    this.senrProfttlPsncnt = senrProfttlPsncnt
    this.midProfttlPsncnt = midProfttlPsncnt
    this.proTechstfPsncnt = proTechstfPsncnt
    this.depsenrProfttlPsncnt = depsenrProfttlPsncnt
    this.actOpenBed = actOpenBed
    this.bizPsncnt = bizPsncnt
    this.othPsncnt = othPsncnt
    this.bizArea = bizArea
    this.medinslv = medinslv
    this.lnt = lnt
    this.lat = lat
    this.begntime = begntime
    this.endtime = endtime
    this.memo = memo
    this.grstHospFlag = grstHospFlag
    this.credLv = credLv
    this.prntMedinsNo = prntMedinsNo
    this.medinsPracScpCode = medinsPracScpCode
    this.medinsPracScpName = medinsPracScpName
    this.valiFlag = valiFlag
    this.poolarea = poolarea
    this.rid = rid
    this.crter = crter
    this.crterName = crterName
    this.crteTime = crteTime
    this.crteOptins = crteOptins
    this.opter = opter
    this.opterName = opterName
    this.optTime = optTime
    this.optins = optins
    this.ver = ver
  }
}

export default MedinsInfoBQueryClass
