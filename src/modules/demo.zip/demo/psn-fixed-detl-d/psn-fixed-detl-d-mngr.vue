<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnFixedDetlDFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员定点机构明细流水号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.psnFixedListSn"
                      placeholder="请输入人员定点机构明细流水号"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="待遇申报明细流水号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.trtDclaDetlSn"
                      placeholder="请输入待遇申报明细流水号"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员参保关系ID">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.psnInsuRltsId"
                      placeholder="请输入人员参保关系ID"
                      maxlength="20"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="业务申请类型">
                  <el-select v-model="psnFixedDetlDFormQuery.bizAppyType" type="BIZ_APPY_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="定点排序号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.fixSrtNo"
                      placeholder="请输入定点排序号"
                      maxlength="${field.columnLength}"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="定点医药机构编号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.fixmedinsCode"
                      placeholder="请输入定点医药机构编号"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="定点医药机构名称">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.fixmedinsName"
                      placeholder="请输入定点医药机构名称"
                      maxlength="200"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医药机构等级">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.medinsLv"
                      placeholder="请输入医药机构等级"
                      maxlength="6"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="定点归属机构">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.fixmedinsPoolarea"
                      placeholder="请输入定点归属机构"
                      maxlength="6"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="开始日期">
                  <el-date-picker
                      v-model="psnFixedDetlDFormQuery.begndate"
                      placeholder="请输入开始日期"
                      :disabled="psnFixedDetlDFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="结束日期">
                  <el-date-picker
                      v-model="psnFixedDetlDFormQuery.enddate"
                      placeholder="请输入结束日期"
                      :disabled="psnFixedDetlDFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="备注">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.memo"
                      placeholder="请输入备注"
                      maxlength="500"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="psnFixedDetlDFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="更新时间">
                  <el-date-picker
                      v-model="psnFixedDetlDFormQuery.updtTime"
                      placeholder="请输入更新时间"
                      :disabled="psnFixedDetlDFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.crter"
                      placeholder="请输入创建人"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人姓名">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.crterName"
                      placeholder="请输入创建人姓名"
                      maxlength="50"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建时间">
                  <el-date-picker
                      v-model="psnFixedDetlDFormQuery.crteTime"
                      placeholder="请输入创建时间"
                      :disabled="psnFixedDetlDFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建机构">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.crteOptins"
                      placeholder="请输入创建机构"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.opter"
                      placeholder="请输入经办人"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人姓名">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.opterName"
                      placeholder="请输入经办人姓名"
                      maxlength="50"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办时间">
                  <el-date-picker
                      v-model="psnFixedDetlDFormQuery.optTime"
                      placeholder="请输入经办时间"
                      :disabled="psnFixedDetlDFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办机构">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.optins"
                      placeholder="请输入经办机构"
                      maxlength="30"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="统筹区">
                  <el-input
                      v-model="psnFixedDetlDFormQuery.poolarea"
                      placeholder="请输入统筹区"
                      maxlength="6"
                      :disabled="psnFixedDetlDFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryPsnFixedDetlD">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="psnFixedDetlDTabColDefs"
              :data="psnFixedDetlDList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryPsnFixedDetlD"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="人员定点登记明细信息表"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="psnFixedDetlDFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="psnFixedDetlDEditFormRules"
           ref="psnFixedDetlDEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员定点机构明细流水号" prop="psnFixedListSn">
            <el-input
                v-model="psnFixedDetlDFormEdit.psnFixedListSn"
                placeholder="请输入人员定点机构明细流水号"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="psnFixedDetlDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="psnFixedDetlDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="psnFixedDetlDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="业务申请类型" prop="bizAppyType">
            <el-select v-model="psnFixedDetlDFormEdit.bizAppyType" type="BIZ_APPY_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点排序号" prop="fixSrtNo">
            <el-input
                v-model="psnFixedDetlDFormEdit.fixSrtNo"
                placeholder="请输入定点排序号"
                maxlength="${field.columnLength}"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点医药机构编号" prop="fixmedinsCode">
            <el-input
                v-model="psnFixedDetlDFormEdit.fixmedinsCode"
                placeholder="请输入定点医药机构编号"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点医药机构名称" prop="fixmedinsName">
            <el-input
                v-model="psnFixedDetlDFormEdit.fixmedinsName"
                placeholder="请输入定点医药机构名称"
                maxlength="200"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医药机构等级" prop="medinsLv">
            <el-input
                v-model="psnFixedDetlDFormEdit.medinsLv"
                placeholder="请输入医药机构等级"
                maxlength="6"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点归属机构" prop="fixmedinsPoolarea">
            <el-input
                v-model="psnFixedDetlDFormEdit.fixmedinsPoolarea"
                placeholder="请输入定点归属机构"
                maxlength="6"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始日期" prop="begndate">
            <el-date-picker
                v-model="psnFixedDetlDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="psnFixedDetlDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束日期" prop="enddate">
            <el-date-picker
                v-model="psnFixedDetlDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="psnFixedDetlDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="备注" prop="memo">
            <el-input
                v-model="psnFixedDetlDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="psnFixedDetlDFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="psnFixedDetlDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="psnFixedDetlDFormEdit.updtTime"
                placeholder="请输入更新时间"
                :disabled="psnFixedDetlDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="psnFixedDetlDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="psnFixedDetlDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="psnFixedDetlDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="psnFixedDetlDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="psnFixedDetlDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="psnFixedDetlDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="psnFixedDetlDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="psnFixedDetlDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="psnFixedDetlDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="psnFixedDetlDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="30"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="psnFixedDetlDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="psnFixedDetlDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="psnFixedDetlDEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="psnFixedDetlDEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './psn-fixed-detl-d-mngr.service'
import PsnFixedDetlDClass from '@/modules/demo/class/psn-fixed-detl-d-mngr.class'
import PsnFixedDetlDQueryClass from '@/modules/demo/class/psn-fixed-detl-d-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.psnFixedDetlDFormQuery = new PsnFixedDetlDQueryClass()
      this.psnFixedDetlDFormEdit = new PsnFixedDetlDClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.psnFixedDetlDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.psnFixedDetlDFormDisabled = false
      this.psnFixedDetlDFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryPsnFixedDetlD () {
      try {
        this.tableLoading = true
        const psnFixedDetlDResult = await Service.resources.getByPage(this.psnFixedDetlDFormQuery, this.paginationConfig)
        if (psnFixedDetlDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.psnFixedDetlDList = []
        } else {
          this.psnFixedDetlDList = psnFixedDetlDResult.result
          this.paginationConfig.pageNumber = psnFixedDetlDResult.pageNumber
          this.paginationConfig.pageSize = psnFixedDetlDResult.pageSize
          this.paginationConfig.total = psnFixedDetlDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addPsnFixedDetlD () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.psnFixedDetlDFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryPsnFixedDetlD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updatePsnFixedDetlD () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.psnFixedDetlDFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryPsnFixedDetlD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deletePsnFixedDetlD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryPsnFixedDetlD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetPsnFixedDetlDEditForm () {
      this.$refs.psnFixedDetlDEditForm.resetFields()
    },
    psnFixedDetlDEditCancel () {
      this.resetPsnFixedDetlDEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.psnFixedDetlDFormEdit = new PsnFixedDetlDClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnFixedDetlDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.psnFixedDetlDFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnFixedDetlDEditForm.clearValidate()
      })
    },
    psnFixedDetlDEditConfirm () {
      this.$refs.psnFixedDetlDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updatePsnFixedDetlD()
          } else {
            this.addPsnFixedDetlD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deletePsnFixedDetlD(row.psnFixedListSn)
      })
    }
  },
  data () {
    const psnFixedDetlDColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '待遇申报明细流水号', prop: 'trtDclaDetlSn', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员参保关系ID', prop: 'psnInsuRltsId', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '业务申请类型',
        prop: 'bizAppyType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'BIZ_APPY_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点排序号', prop: 'fixSrtNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点医药机构编号', prop: 'fixmedinsCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点医药机构名称', prop: 'fixmedinsName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医药机构等级', prop: 'medinsLv', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点归属机构', prop: 'fixmedinsPoolarea', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '备注', prop: 'memo', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const psnFixedDetlDRules = {
      trtDclaDetlSn: [{ required: true, message: '请填写待遇申报明细流水号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [{ required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      bizAppyType: [{ required: true, message: '请选择业务申请类型', trigger: 'change' }],
      fixSrtNo: [{ required: true, message: '请填写定点排序号', trigger: 'blur' }
      ],
      fixmedinsCode: [{ required: true, message: '请填写定点医药机构编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsName: [{ required: true, message: '请填写定点医药机构名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      medinsLv: [{ required: true, message: '请填写医药机构等级', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      fixmedinsPoolarea: [{ required: true, message: '请填写定点归属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      begndate: [{ required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }],
      enddate: [{ required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }],
      memo: [{ required: true, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      psnFixedDetlDTabColDefs: psnFixedDetlDColDefs,
      psnFixedDetlDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      psnFixedDetlDFormDisabled: false,
      psnFixedDetlDFormEditDisabled: false,
      psnFixedDetlDFormQuery: new PsnFixedDetlDQueryClass(),
      psnFixedDetlDFormEdit: new PsnFixedDetlDClass(),
      psnFixedDetlDEditFormRules: psnFixedDetlDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
