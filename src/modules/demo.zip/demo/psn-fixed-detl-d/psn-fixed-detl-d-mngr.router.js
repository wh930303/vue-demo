/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/psn-fixed-detl-d',
  component: () => import('@/modules/demo/psn-fixed-detl-d/psn-fixed-detl-d-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
          'BIZ_APPY_TYPE',
          'VALI_FLAG',
    ] }
}
