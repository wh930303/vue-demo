<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="medinsInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构ID">
                  <el-input
                      v-model="medinsInfoBFormQuery.medinsId"
                      placeholder="请输入医疗机构ID"
                      maxlength="40"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构编号">
                  <el-input
                      v-model="medinsInfoBFormQuery.medinsNo"
                      placeholder="请输入医疗机构编号"
                      maxlength="30"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编号">
                  <el-input
                      v-model="medinsInfoBFormQuery.empNo"
                      placeholder="请输入单位编号"
                      maxlength="40"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构名称">
                  <el-input
                      v-model="medinsInfoBFormQuery.medinsName"
                      placeholder="请输入医疗机构名称"
                      maxlength="100"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构简称">
                  <el-input
                      v-model="medinsInfoBFormQuery.medinsAbbr"
                      placeholder="请输入医疗机构简称"
                      maxlength="50"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="传真号码">
                  <el-input
                      v-model="medinsInfoBFormQuery.faxNo"
                      placeholder="请输入传真号码"
                      maxlength="50"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="主要负责人">
                  <el-input
                      v-model="medinsInfoBFormQuery.mainResper"
                      placeholder="请输入主要负责人"
                      maxlength="50"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="行政区划">
                  <el-input
                      v-model="medinsInfoBFormQuery.admdvs"
                      placeholder="请输入行政区划"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="地址">
                  <el-input
                      v-model="medinsInfoBFormQuery.addr"
                      placeholder="请输入地址"
                      maxlength="200"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="机构性质">
                  <el-select v-model="medinsInfoBFormQuery.medinsNatu" type="MEDINS_NATU" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗服务机构类型">
                  <el-select v-model="medinsInfoBFormQuery.medinsType" type="MEDINS_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="登记状态">
                  <el-input
                      v-model="medinsInfoBFormQuery.regStas"
                      placeholder="请输入登记状态"
                      maxlength="10"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="在编职工数">
                  <el-input
                      v-model="medinsInfoBFormQuery.enrdStafPsncnt"
                      placeholder="请输入在编职工数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医院科室数">
                  <el-input
                      v-model="medinsInfoBFormQuery.hospDeptCnt"
                      placeholder="请输入医院科室数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医院重点科室数">
                  <el-input
                      v-model="medinsInfoBFormQuery.hospKeyDeptCnt"
                      placeholder="请输入医院重点科室数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="正高职称人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.senrProfttlPsncnt"
                      placeholder="请输入正高职称人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="中级职称人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.midProfttlPsncnt"
                      placeholder="请输入中级职称人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="专业技术人员人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.proTechstfPsncnt"
                      placeholder="请输入专业技术人员人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="副高职称人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.depsenrProfttlPsncnt"
                      placeholder="请输入副高职称人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="实际开放床位数">
                  <el-input
                      v-model="medinsInfoBFormQuery.actOpenBed"
                      placeholder="请输入实际开放床位数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="营业人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.bizPsncnt"
                      placeholder="请输入营业人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="其他人数">
                  <el-input
                      v-model="medinsInfoBFormQuery.othPsncnt"
                      placeholder="请输入其他人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经营面积">
                  <el-input
                      v-model="medinsInfoBFormQuery.bizArea"
                      placeholder="请输入经营面积"
                      maxlength="100"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构等级">
                  <el-select v-model="medinsInfoBFormQuery.medinslv" type="MEDINSLV" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经度">
                  <el-input
                      v-model="medinsInfoBFormQuery.lnt"
                      placeholder="请输入经度"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="纬度">
                  <el-input
                      v-model="medinsInfoBFormQuery.lat"
                      placeholder="请输入纬度"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="开始时间">
                  <el-date-picker
                      v-model="medinsInfoBFormQuery.begntime"
                      placeholder="请输入开始时间"
                      :disabled="medinsInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="结束时间">
                  <el-date-picker
                      v-model="medinsInfoBFormQuery.endtime"
                      placeholder="请输入结束时间"
                      :disabled="medinsInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="备注">
                  <el-input
                      v-model="medinsInfoBFormQuery.memo"
                      placeholder="请输入备注"
                      maxlength="500"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="基层医院标志">
                  <el-select v-model="medinsInfoBFormQuery.grstHospFlag" type="GRST_HOSP_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="信用等级">
                  <el-select v-model="medinsInfoBFormQuery.credLv" type="CRED_LV" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="上级医疗机构编号">
                  <el-input
                      v-model="medinsInfoBFormQuery.prntMedinsNo"
                      placeholder="请输入上级医疗机构编号"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构执业范围代码">
                  <el-select v-model="medinsInfoBFormQuery.medinsPracScpCode" type="MEDINS_PRAC_SCP_CODE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构执业范围名称">
                  <el-input
                      v-model="medinsInfoBFormQuery.medinsPracScpName"
                      placeholder="请输入医疗机构执业范围名称"
                      maxlength="100"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="medinsInfoBFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="统筹区">
                  <el-input
                      v-model="medinsInfoBFormQuery.poolarea"
                      placeholder="请输入统筹区"
                      maxlength="6"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="medinsInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人">
                  <el-input
                      v-model="medinsInfoBFormQuery.crter"
                      placeholder="请输入创建人"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人姓名">
                  <el-input
                      v-model="medinsInfoBFormQuery.crterName"
                      placeholder="请输入创建人姓名"
                      maxlength="50"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建时间">
                  <el-date-picker
                      v-model="medinsInfoBFormQuery.crteTime"
                      placeholder="请输入创建时间"
                      :disabled="medinsInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建经办机构">
                  <el-input
                      v-model="medinsInfoBFormQuery.crteOptins"
                      placeholder="请输入创建经办机构"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人">
                  <el-input
                      v-model="medinsInfoBFormQuery.opter"
                      placeholder="请输入经办人"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人姓名">
                  <el-input
                      v-model="medinsInfoBFormQuery.opterName"
                      placeholder="请输入经办人姓名"
                      maxlength="50"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办时间">
                  <el-date-picker
                      v-model="medinsInfoBFormQuery.optTime"
                      placeholder="请输入经办时间"
                      :disabled="medinsInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办机构">
                  <el-input
                      v-model="medinsInfoBFormQuery.optins"
                      placeholder="请输入经办机构"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="版本号">
                  <el-input
                      v-model="medinsInfoBFormQuery.ver"
                      placeholder="请输入版本号"
                      maxlength="20"
                      :disabled="medinsInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryMedinsInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="medinsInfoBTabColDefs"
              :data="medinsInfoBList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryMedinsInfoB"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title=""
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="medinsInfoBFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="medinsInfoBEditFormRules"
           ref="medinsInfoBEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构ID" prop="medinsId">
            <el-input
                v-model="medinsInfoBFormEdit.medinsId"
                placeholder="请输入医疗机构ID"
                maxlength="40"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构编号" prop="medinsNo">
            <el-input
                v-model="medinsInfoBFormEdit.medinsNo"
                placeholder="请输入医疗机构编号"
                maxlength="30"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="medinsInfoBFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="40"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构名称" prop="medinsName">
            <el-input
                v-model="medinsInfoBFormEdit.medinsName"
                placeholder="请输入医疗机构名称"
                maxlength="100"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构简称" prop="medinsAbbr">
            <el-input
                v-model="medinsInfoBFormEdit.medinsAbbr"
                placeholder="请输入医疗机构简称"
                maxlength="50"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="传真号码" prop="faxNo">
            <el-input
                v-model="medinsInfoBFormEdit.faxNo"
                placeholder="请输入传真号码"
                maxlength="50"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="主要负责人" prop="mainResper">
            <el-input
                v-model="medinsInfoBFormEdit.mainResper"
                placeholder="请输入主要负责人"
                maxlength="50"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="行政区划" prop="admdvs">
            <el-input
                v-model="medinsInfoBFormEdit.admdvs"
                placeholder="请输入行政区划"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="地址" prop="addr">
            <el-input
                v-model="medinsInfoBFormEdit.addr"
                placeholder="请输入地址"
                maxlength="200"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="机构性质" prop="medinsNatu">
            <el-select v-model="medinsInfoBFormEdit.medinsNatu" type="MEDINS_NATU" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗服务机构类型" prop="medinsType">
            <el-select v-model="medinsInfoBFormEdit.medinsType" type="MEDINS_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="登记状态" prop="regStas">
            <el-input
                v-model="medinsInfoBFormEdit.regStas"
                placeholder="请输入登记状态"
                maxlength="10"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="在编职工数" prop="enrdStafPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.enrdStafPsncnt"
                placeholder="请输入在编职工数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医院科室数" prop="hospDeptCnt">
            <el-input
                v-model="medinsInfoBFormEdit.hospDeptCnt"
                placeholder="请输入医院科室数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医院重点科室数" prop="hospKeyDeptCnt">
            <el-input
                v-model="medinsInfoBFormEdit.hospKeyDeptCnt"
                placeholder="请输入医院重点科室数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="正高职称人数" prop="senrProfttlPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.senrProfttlPsncnt"
                placeholder="请输入正高职称人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="中级职称人数" prop="midProfttlPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.midProfttlPsncnt"
                placeholder="请输入中级职称人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="专业技术人员人数" prop="proTechstfPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.proTechstfPsncnt"
                placeholder="请输入专业技术人员人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="副高职称人数" prop="depsenrProfttlPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.depsenrProfttlPsncnt"
                placeholder="请输入副高职称人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="实际开放床位数" prop="actOpenBed">
            <el-input
                v-model="medinsInfoBFormEdit.actOpenBed"
                placeholder="请输入实际开放床位数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="营业人数" prop="bizPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.bizPsncnt"
                placeholder="请输入营业人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="其他人数" prop="othPsncnt">
            <el-input
                v-model="medinsInfoBFormEdit.othPsncnt"
                placeholder="请输入其他人数"
                maxlength="${field.columnLength}"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经营面积" prop="bizArea">
            <el-input
                v-model="medinsInfoBFormEdit.bizArea"
                placeholder="请输入经营面积"
                maxlength="100"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构等级" prop="medinslv">
            <el-select v-model="medinsInfoBFormEdit.medinslv" type="MEDINSLV" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经度" prop="lnt">
            <el-input
                v-model="medinsInfoBFormEdit.lnt"
                placeholder="请输入经度"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="纬度" prop="lat">
            <el-input
                v-model="medinsInfoBFormEdit.lat"
                placeholder="请输入纬度"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始时间" prop="begntime">
            <el-date-picker
                v-model="medinsInfoBFormEdit.begntime"
                placeholder="请输入开始时间"
                :disabled="medinsInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束时间" prop="endtime">
            <el-date-picker
                v-model="medinsInfoBFormEdit.endtime"
                placeholder="请输入结束时间"
                :disabled="medinsInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="备注" prop="memo">
            <el-input
                v-model="medinsInfoBFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="基层医院标志" prop="grstHospFlag">
            <el-select v-model="medinsInfoBFormEdit.grstHospFlag" type="GRST_HOSP_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="信用等级" prop="credLv">
            <el-select v-model="medinsInfoBFormEdit.credLv" type="CRED_LV" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="上级医疗机构编号" prop="prntMedinsNo">
            <el-input
                v-model="medinsInfoBFormEdit.prntMedinsNo"
                placeholder="请输入上级医疗机构编号"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构执业范围代码" prop="medinsPracScpCode">
            <el-select v-model="medinsInfoBFormEdit.medinsPracScpCode" type="MEDINS_PRAC_SCP_CODE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构执业范围名称" prop="medinsPracScpName">
            <el-input
                v-model="medinsInfoBFormEdit.medinsPracScpName"
                placeholder="请输入医疗机构执业范围名称"
                maxlength="100"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="medinsInfoBFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="medinsInfoBFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="medinsInfoBFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="medinsInfoBFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="medinsInfoBFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="medinsInfoBFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="medinsInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建经办机构" prop="crteOptins">
            <el-input
                v-model="medinsInfoBFormEdit.crteOptins"
                placeholder="请输入创建经办机构"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="medinsInfoBFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="medinsInfoBFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="medinsInfoBFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="medinsInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="medinsInfoBFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="版本号" prop="ver">
            <el-input
                v-model="medinsInfoBFormEdit.ver"
                placeholder="请输入版本号"
                maxlength="20"
                :disabled="medinsInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="medinsInfoBEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="medinsInfoBEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './medins-info-b-mngr.service'
import MedinsInfoBClass from '@/modules/demo/class/medins-info-b-mngr.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.medinsInfoBFormEdit = new MedinsInfoBClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.medinsInfoBList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.medinsInfoBFormDisabled = false
      this.medinsInfoBFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryMedinsInfoB () {
      try {
        this.tableLoading = true
        const medinsInfoBResult = await Service.resources.getByPage(this.medinsInfoBFormQuery, this.paginationConfig)
        if (medinsInfoBResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.medinsInfoBList = []
        } else {
          this.medinsInfoBList = medinsInfoBResult.result
          this.paginationConfig.pageNumber = medinsInfoBResult.pageNumber
          this.paginationConfig.pageSize = medinsInfoBResult.pageSize
          this.paginationConfig.total = medinsInfoBResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addMedinsInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.medinsInfoBFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryMedinsInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateMedinsInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.medinsInfoBFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryMedinsInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteMedinsInfoB (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryMedinsInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetMedinsInfoBEditForm () {
      this.$refs.medinsInfoBEditForm.resetFields()
    },
    medinsInfoBEditCancel () {
      this.resetMedinsInfoBEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.medinsInfoBFormEdit = new MedinsInfoBClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.medinsInfoBEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.medinsInfoBFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.medinsInfoBEditForm.clearValidate()
      })
    },
    medinsInfoBEditConfirm () {
      this.$refs.medinsInfoBEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateMedinsInfoB()
          } else {
            this.addMedinsInfoB()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteMedinsInfoB(row.medinsId)
      })
    }
  },
  data () {
    const medinsInfoBColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗机构编号', prop: 'medinsNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编号', prop: 'empNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗机构名称', prop: 'medinsName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗机构简称', prop: 'medinsAbbr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '传真号码', prop: 'faxNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '主要负责人', prop: 'mainResper', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '行政区划', prop: 'admdvs', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '地址', prop: 'addr', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '机构性质',
        prop: 'medinsNatu',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MEDINS_NATU') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医疗服务机构类型',
        prop: 'medinsType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MEDINS_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '登记状态', prop: 'regStas', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '在编职工数', prop: 'enrdStafPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医院科室数', prop: 'hospDeptCnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医院重点科室数', prop: 'hospKeyDeptCnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '正高职称人数', prop: 'senrProfttlPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '中级职称人数', prop: 'midProfttlPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '专业技术人员人数', prop: 'proTechstfPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '副高职称人数', prop: 'depsenrProfttlPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '实际开放床位数', prop: 'actOpenBed', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '营业人数', prop: 'bizPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '其他人数', prop: 'othPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经营面积', prop: 'bizArea', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医疗机构等级',
        prop: 'medinslv',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MEDINSLV') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经度', prop: 'lnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '纬度', prop: 'lat', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始时间',
        prop: 'begntime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束时间',
        prop: 'endtime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '备注', prop: 'memo', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '基层医院标志',
        prop: 'grstHospFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'GRST_HOSP_FLAG') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '信用等级',
        prop: 'credLv',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'CRED_LV') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '上级医疗机构编号', prop: 'prntMedinsNo', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医疗机构执业范围代码',
        prop: 'medinsPracScpCode',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MEDINS_PRAC_SCP_CODE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗机构执业范围名称', prop: 'medinsPracScpName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建经办机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '版本号', prop: 'ver', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const medinsInfoBRules = {
      medinsNo: [{ required: true, message: '请填写医疗机构编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empNo: [{ required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      medinsName: [{ required: true, message: '请填写医疗机构名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      medinsAbbr: [{ required: true, message: '请填写医疗机构简称', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      faxNo: [{ required: true, message: '请填写传真号码', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      mainResper: [{ required: true, message: '请填写主要负责人', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      admdvs: [{ required: true, message: '请填写行政区划', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      addr: [{ required: true, message: '请填写地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      medinsNatu: [{ required: true, message: '请选择机构性质', trigger: 'change' }],
      medinsType: [{ required: true, message: '请选择医疗服务机构类型', trigger: 'change' }],
      regStas: [{ required: true, message: '请填写登记状态', trigger: 'blur' },
        { max: 10, message: '长度不能超过 10 个字符', trigger: 'blur' }
      ],
      enrdStafPsncnt: [{ required: true, message: '请填写在编职工数', trigger: 'blur' }
      ],
      hospDeptCnt: [{ required: true, message: '请填写医院科室数', trigger: 'blur' }
      ],
      hospKeyDeptCnt: [{ required: true, message: '请填写医院重点科室数', trigger: 'blur' }
      ],
      senrProfttlPsncnt: [{ required: true, message: '请填写正高职称人数', trigger: 'blur' }
      ],
      midProfttlPsncnt: [{ required: true, message: '请填写中级职称人数', trigger: 'blur' }
      ],
      proTechstfPsncnt: [{ required: true, message: '请填写专业技术人员人数', trigger: 'blur' }
      ],
      depsenrProfttlPsncnt: [{ required: true, message: '请填写副高职称人数', trigger: 'blur' }
      ],
      actOpenBed: [{ required: true, message: '请填写实际开放床位数', trigger: 'blur' }
      ],
      bizPsncnt: [{ required: true, message: '请填写营业人数', trigger: 'blur' }
      ],
      othPsncnt: [{ required: true, message: '请填写其他人数', trigger: 'blur' }
      ],
      bizArea: [{ required: true, message: '请填写经营面积', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      medinslv: [{ required: true, message: '请选择医疗机构等级', trigger: 'change' }],
      lnt: [{ required: true, message: '请填写经度', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      lat: [{ required: true, message: '请填写纬度', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      begntime: [{ required: true, type: 'date', message: '请选择开始时间', trigger: 'change' }],
      endtime: [{ required: true, type: 'date', message: '请选择结束时间', trigger: 'change' }],
      memo: [{ required: true, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      grstHospFlag: [{ required: true, message: '请选择基层医院标志', trigger: 'change' }],
      credLv: [{ required: true, message: '请选择信用等级', trigger: 'change' }],
      prntMedinsNo: [{ required: true, message: '请填写上级医疗机构编号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      medinsPracScpCode: [{ required: true, message: '请选择医疗机构执业范围代码', trigger: 'change' }],
      medinsPracScpName: [{ required: true, message: '请填写医疗机构执业范围名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      ver: [{ required: true, message: '请填写版本号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      medinsInfoBTabColDefs: medinsInfoBColDefs,
      medinsInfoBList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      medinsInfoBFormDisabled: false,
      medinsInfoBFormEditDisabled: false,
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      medinsInfoBFormEdit: new MedinsInfoBClass(),
      medinsInfoBEditFormRules: medinsInfoBRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
