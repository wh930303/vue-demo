/*
* Created: 2021-01-06
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-06
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/medins-info-b',
  component: () => import('@/modules/demo/medins-info-b/medins-info-b-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
          'MEDINS_NATU',
          'MEDINS_TYPE',
          'MEDINSLV',
          'GRST_HOSP_FLAG',
          'CRED_LV',
          'MEDINS_PRAC_SCP_CODE',
          'VALI_FLAG',
    ] }
}
