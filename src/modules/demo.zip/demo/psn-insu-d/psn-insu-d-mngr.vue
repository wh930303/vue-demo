<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      @blur="blurPsnInfoB"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                      v-model="psnInfoBFormQuery.psnName"
                      placeholder="请输入人员姓名"
                      maxlength="50"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                      v-model="psnInfoBFormQuery.brdy"
                      placeholder="请输入出生日期"
                      
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                      v-model="psnInfoBFormQuery.certNo"
                      placeholder="请输入证件号码"
                      maxlength="30"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="psnInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                      v-model="psnInfoBFormQuery.naty"
                      placeholder="请输入民族"
                      maxlength="6"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                      v-model="psnInfoBFormQuery.addr"
                      placeholder="请输入联系地址"
                      maxlength="200"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                      v-model="psnInfoBFormQuery.gend"
                      placeholder="请输入性别"
                      maxlength="1"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                      v-model="psnInfoBFormQuery.insutype"
                      placeholder="请输入险种"
                      maxlength="6"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="psnInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="psnInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="6"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                      v-model="psnInfoBFormQuery.empCode"
                      placeholder="请输入单位编码"
                      maxlength="30"
                      
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryPsnInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="psnInsuDTabColDefs"
              :data="psnInsuDList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryPsnInsuD"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="人员参保信息表"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="psnInsuDFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="psnInsuDEditFormRules"
           ref="psnInsuDEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保人员管理事件ID" prop="psnInsuMgtEid">
            <el-input
                v-model="psnInsuDFormEdit.psnInsuMgtEid"
                placeholder="请输入参保人员管理事件ID"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="psnInsuDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="psnInsuDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="psnInsuDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗保险类别" prop="hiType">
            <el-input
                v-model="psnInsuDFormEdit.hiType"
                placeholder="请输入医疗保险类别"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种类型" prop="insutype">
            <el-input
                v-model="psnInsuDFormEdit.insutype"
                placeholder="请输入险种类型"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保状态" prop="psnInsuStas">
            <el-input
                v-model="psnInsuDFormEdit.psnInsuStas"
                placeholder="请输入人员参保状态"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="账户建立年月" prop="acctCrtnYm">
            <el-input
                v-model="psnInsuDFormEdit.acctCrtnYm"
                placeholder="请输入账户建立年月"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="首次参保年月" prop="fstInsuYm">
            <el-input
                v-model="psnInsuDFormEdit.fstInsuYm"
                placeholder="请输入首次参保年月"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="本次参保日期" prop="crtInsuDate">
            <el-date-picker
                v-model="psnInsuDFormEdit.crtInsuDate"
                placeholder="请输入本次参保日期"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="本系统首次参保日期" prop="psnInsuDate">
            <el-date-picker
                v-model="psnInsuDFormEdit.psnInsuDate"
                placeholder="请输入本系统首次参保日期"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="暂停参保日期" prop="pausInsuDate">
            <el-date-picker
                v-model="psnInsuDFormEdit.pausInsuDate"
                placeholder="请输入暂停参保日期"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种离退休标志" prop="insutypeRetrFlag">
            <el-input
                v-model="psnInsuDFormEdit.insutypeRetrFlag"
                placeholder="请输入险种离退休标志"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="编制类型" prop="qudtType">
            <el-input
                v-model="psnInsuDFormEdit.qudtType"
                placeholder="请输入编制类型"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="征收方式" prop="clctWay">
            <el-input
                v-model="psnInsuDFormEdit.clctWay"
                placeholder="请输入征收方式"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="用工形式" prop="empFom">
            <el-input
                v-model="psnInsuDFormEdit.empFom"
                placeholder="请输入用工形式"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="最大做账期号" prop="maxAcctprd">
            <el-input
                v-model="psnInsuDFormEdit.maxAcctprd"
                placeholder="请输入最大做账期号"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="征缴规则类型编码" prop="clctRuleTypeCodg">
            <el-input
                v-model="psnInsuDFormEdit.clctRuleTypeCodg"
                placeholder="请输入征缴规则类型编码"
                maxlength="50"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="基数核定规则类型编码" prop="clctstdCrtfRuleCodg">
            <el-input
                v-model="psnInsuDFormEdit.clctstdCrtfRuleCodg"
                placeholder="请输入基数核定规则类型编码"
                maxlength="50"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保机构行政区划" prop="insuOrg">
            <el-input
                v-model="psnInsuDFormEdit.insuOrg"
                placeholder="请输入参保机构行政区划"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="psnInsuDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="psnInsuDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="psnInsuDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="psnInsuDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="psnInsuDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="psnInsuDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="psnInsuDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="psnInsuDFormEdit.updtTime"
                placeholder="请输入更新时间"
                :disabled="psnInsuDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员类别" prop="psnType">
            <el-select v-model="psnInsuDFormEdit.psnType" type="PSN_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="psnInsuDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="psnInsuDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="psnInsuDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="20"
                :disabled="psnInsuDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="psnInsuDEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="psnInsuDEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// import psnInfoB from '@/common/utils/core/psn-info-b'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './psn-insu-d-mngr.service'
import PsnInsuDClass from '@/modules/demo/class/psn-insu-d-mngr.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormEdit = new PsnInsuDClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.psnInsuDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.psnInsuDFormDisabled = false
      this.psnInsuDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(this.psnInfoBFormQuery)
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          } else {
            this.psnInfoBFormQuery = new PsnInfoBQueryClass()
            this.psnInfoBFormQuery.psnNo = psnNo
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    // 异步调用，一律采用 async/await 语法
    async queryPsnInsuD () {
      try {
        this.tableLoading = true
        const psnInsuDResult = await Service.resources.getByPage(this.psnInsuDFormQuery, this.paginationConfig)
        if (psnInsuDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.psnInsuDList = []
        } else {
          this.psnInsuDList = psnInsuDResult.result
          this.paginationConfig.pageNumber = psnInsuDResult.pageNumber
          this.paginationConfig.pageSize = psnInsuDResult.pageSize
          this.paginationConfig.total = psnInsuDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addPsnInsuD () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.psnInsuDFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryPsnInsuD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updatePsnInsuD () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.psnInsuDFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryPsnInsuD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deletePsnInsuD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryPsnInsuD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetPsnInsuDEditForm () {
      this.$refs.psnInsuDEditForm.resetFields()
    },
    psnInsuDEditCancel () {
      this.resetPsnInsuDEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.psnInsuDFormEdit = new PsnInsuDClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnInsuDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.psnInsuDFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnInsuDEditForm.clearValidate()
      })
    },
    psnInsuDEditConfirm () {
      this.$refs.psnInsuDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updatePsnInsuD()
          } else {
            this.addPsnInsuD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deletePsnInsuD(row.psnInsuRltsId)
      })
    }
  },
  data () {
    const psnInsuDColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保人员管理事件ID', prop: 'psnInsuMgtEid', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编号', prop: 'empNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗保险类别', prop: 'hiType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种类型', prop: 'insutype', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员参保状态', prop: 'psnInsuStas', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '账户建立年月', prop: 'acctCrtnYm', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '首次参保年月', prop: 'fstInsuYm', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '本次参保日期',
        prop: 'crtInsuDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '本系统首次参保日期',
        prop: 'psnInsuDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '暂停参保日期',
        prop: 'pausInsuDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种离退休标志', prop: 'insutypeRetrFlag', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '编制类型', prop: 'qudtType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '征收方式', prop: 'clctWay', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '用工形式', prop: 'empFom', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '最大做账期号', prop: 'maxAcctprd', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '征缴规则类型编码', prop: 'clctRuleTypeCodg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '基数核定规则类型编码', prop: 'clctstdCrtfRuleCodg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保机构行政区划', prop: 'insuOrg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员类别',
        prop: 'psnType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'PSN_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const psnInsuDRules = {
      psnInsuMgtEid: [{ required: true, message: '请填写参保人员管理事件ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      empNo: [{ required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      hiType: [{ required: true, message: '请填写医疗保险类别', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      insutype: [{ required: true, message: '请填写险种类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnInsuStas: [{ required: true, message: '请填写人员参保状态', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      acctCrtnYm: [{ required: true, message: '请填写账户建立年月', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      fstInsuYm: [{ required: true, message: '请填写首次参保年月', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      crtInsuDate: [{ required: true, type: 'date', message: '请选择本次参保日期', trigger: 'change' }],
      psnInsuDate: [{ required: true, type: 'date', message: '请选择本系统首次参保日期', trigger: 'change' }],
      pausInsuDate: [{ required: true, type: 'date', message: '请选择暂停参保日期', trigger: 'change' }],
      insutypeRetrFlag: [{ required: true, message: '请填写险种离退休标志', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      qudtType: [{ required: true, message: '请填写编制类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      clctWay: [{ required: true, message: '请填写征收方式', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empFom: [{ required: true, message: '请填写用工形式', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      maxAcctprd: [{ required: true, message: '请填写最大做账期号', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      clctRuleTypeCodg: [{ required: true, message: '请填写征缴规则类型编码', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      clctstdCrtfRuleCodg: [{ required: true, message: '请填写基数核定规则类型编码', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      insuOrg: [{ required: true, message: '请填写参保机构行政区划', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }],
      psnType: [{ required: true, message: '请选择人员类别', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      psnInsuDTabColDefs: psnInsuDColDefs,
      psnInsuDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      psnInsuDFormDisabled: false,
      psnInsuDFormEditDisabled: false,
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormEdit: new PsnInsuDClass(),
      psnInsuDEditFormRules: psnInsuDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
