/*
* Created: 2021-01-08
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-08
* Modified By: wanghao
* Description:
*/

import NCP from '@ncp-web/core'
//import { codeFilter, tableDataFilter } from '@/common/filters/index'

// 业务服务上下文，必需设置为 process.env.VUE_APP_BASE_URL
const context = process.env.VUE_APP_BASE_URL

// 针对特定资源，创建 axios 实例
const resourcesConst = NCP.createAxios({
  baseURL: context + '/web/demo/medinsDeptInfoB',
  headers: { businessId: 'medinsDeptInfoBbusinessId' }
})

// 针对特定资源，创建资源访问对象
// 对象变量应同资源同名
const resources = {
  // 好用的POS请求示例
  // return empInsuMergeRes.post('/updateEmpMergeInfo', formEdit, {
  //   headers: { 'Content-Type': 'application/json' }
  // })
  
  //查询
  get(medinsDeptInfoBQuery) {
    // 发送请求
    return resourcesConst.request({
      method: 'GET',
      params: medinsDeptInfoBQuery,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  // 分页查询
  getByPage(medinsDeptInfoBQuery, pageConfig) {
    // 发送请求
    return resourcesConst.request({
      url: '/page',
      method: 'GET',
      params: Object.assign({},pageConfig,medinsDeptInfoBQuery),
      headers: { 'Content-Type': 'application/json' }
    })
  },
  post(medinsDeptInfoB) {
    return resourcesConst.request({
      method: 'POST',
      data: medinsDeptInfoB,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  put(medinsDeptInfoB) {
    return resourcesConst.request({
      method: 'PUT',
      data: medinsDeptInfoB,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  delete(id) {
    return resourcesConst.request({
      url: '/' + id,
      method: 'DELETE'
    })
  }
}

export default {
  resources
}

