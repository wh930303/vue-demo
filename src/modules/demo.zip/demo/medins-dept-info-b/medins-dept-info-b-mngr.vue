<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="medinsDeptInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构科室信息ID">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.medinsDeptInfoId"
                      placeholder="请输入医疗机构科室信息ID"
                      maxlength="40"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医疗机构代码">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.medinsCode"
                      placeholder="请输入医疗机构代码"
                      maxlength="30"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="国家科室编码">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.natDeptCode"
                      placeholder="请输入国家科室编码"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医院科室编号">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.hospDeptCode"
                      placeholder="请输入医院科室编号"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医院科室名称">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.hospDeptName"
                      placeholder="请输入医院科室名称"
                      maxlength="50"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="简介">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.itro"
                      placeholder="请输入简介"
                      maxlength="500"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="开始时间">
                  <el-date-picker
                      v-model="medinsDeptInfoBFormQuery.begntime"
                      placeholder="请输入开始时间"
                      :disabled="medinsDeptInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="结束时间">
                  <el-date-picker
                      v-model="medinsDeptInfoBFormQuery.endtime"
                      placeholder="请输入结束时间"
                      :disabled="medinsDeptInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="科室负责人姓名">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.deptResperName"
                      placeholder="请输入科室负责人姓名"
                      maxlength="50"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="科室负责人电话">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.deptResperTel"
                      placeholder="请输入科室负责人电话"
                      maxlength="50"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="科室医疗服务范围">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.deptMedServScp"
                      placeholder="请输入科室医疗服务范围"
                      maxlength="500"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="床位数">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.bedCnt"
                      placeholder="请输入床位数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师人数">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.drPsncnt"
                      placeholder="请输入医师人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="药师人数">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.pharPsncnt"
                      placeholder="请输入药师人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="护士人数">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.nursPsncnt"
                      placeholder="请输入护士人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="技师人数">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.tecnPsncnt"
                      placeholder="请输入技师人数"
                      maxlength="${field.columnLength}"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="medinsDeptInfoBFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.crter"
                      placeholder="请输入创建人"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人姓名">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.crterName"
                      placeholder="请输入创建人姓名"
                      maxlength="50"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建时间">
                  <el-date-picker
                      v-model="medinsDeptInfoBFormQuery.crteTime"
                      placeholder="请输入创建时间"
                      :disabled="medinsDeptInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建机构">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.crteOptins"
                      placeholder="请输入创建机构"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.opter"
                      placeholder="请输入经办人"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人姓名">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.opterName"
                      placeholder="请输入经办人姓名"
                      maxlength="50"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办时间">
                  <el-date-picker
                      v-model="medinsDeptInfoBFormQuery.optTime"
                      placeholder="请输入经办时间"
                      :disabled="medinsDeptInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办机构">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.optins"
                      placeholder="请输入经办机构"
                      maxlength="20"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="统筹区">
                  <el-input
                      v-model="medinsDeptInfoBFormQuery.poolarea"
                      placeholder="请输入统筹区"
                      maxlength="6"
                      :disabled="medinsDeptInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="更新时间">
                  <el-date-picker
                      v-model="medinsDeptInfoBFormQuery.updtTime"
                      placeholder="请输入更新时间"
                      :disabled="medinsDeptInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryMedinsDeptInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="medinsDeptInfoBTabColDefs"
              :data="medinsDeptInfoBList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryMedinsDeptInfoB"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="医疗机构科室表"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="medinsDeptInfoBFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="medinsDeptInfoBEditFormRules"
           ref="medinsDeptInfoBEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构科室信息ID" prop="medinsDeptInfoId">
            <el-input
                v-model="medinsDeptInfoBFormEdit.medinsDeptInfoId"
                placeholder="请输入医疗机构科室信息ID"
                maxlength="40"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗机构代码" prop="medinsCode">
            <el-input
                v-model="medinsDeptInfoBFormEdit.medinsCode"
                placeholder="请输入医疗机构代码"
                maxlength="30"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="国家科室编码" prop="natDeptCode">
            <el-input
                v-model="medinsDeptInfoBFormEdit.natDeptCode"
                placeholder="请输入国家科室编码"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医院科室编号" prop="hospDeptCode">
            <el-input
                v-model="medinsDeptInfoBFormEdit.hospDeptCode"
                placeholder="请输入医院科室编号"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医院科室名称" prop="hospDeptName">
            <el-input
                v-model="medinsDeptInfoBFormEdit.hospDeptName"
                placeholder="请输入医院科室名称"
                maxlength="50"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="简介" prop="itro">
            <el-input
                v-model="medinsDeptInfoBFormEdit.itro"
                placeholder="请输入简介"
                maxlength="500"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始时间" prop="begntime">
            <el-date-picker
                v-model="medinsDeptInfoBFormEdit.begntime"
                placeholder="请输入开始时间"
                :disabled="medinsDeptInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束时间" prop="endtime">
            <el-date-picker
                v-model="medinsDeptInfoBFormEdit.endtime"
                placeholder="请输入结束时间"
                :disabled="medinsDeptInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="科室负责人姓名" prop="deptResperName">
            <el-input
                v-model="medinsDeptInfoBFormEdit.deptResperName"
                placeholder="请输入科室负责人姓名"
                maxlength="50"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="科室负责人电话" prop="deptResperTel">
            <el-input
                v-model="medinsDeptInfoBFormEdit.deptResperTel"
                placeholder="请输入科室负责人电话"
                maxlength="50"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="科室医疗服务范围" prop="deptMedServScp">
            <el-input
                v-model="medinsDeptInfoBFormEdit.deptMedServScp"
                placeholder="请输入科室医疗服务范围"
                maxlength="500"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="床位数" prop="bedCnt">
            <el-input
                v-model="medinsDeptInfoBFormEdit.bedCnt"
                placeholder="请输入床位数"
                maxlength="${field.columnLength}"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师人数" prop="drPsncnt">
            <el-input
                v-model="medinsDeptInfoBFormEdit.drPsncnt"
                placeholder="请输入医师人数"
                maxlength="${field.columnLength}"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="药师人数" prop="pharPsncnt">
            <el-input
                v-model="medinsDeptInfoBFormEdit.pharPsncnt"
                placeholder="请输入药师人数"
                maxlength="${field.columnLength}"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="护士人数" prop="nursPsncnt">
            <el-input
                v-model="medinsDeptInfoBFormEdit.nursPsncnt"
                placeholder="请输入护士人数"
                maxlength="${field.columnLength}"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="技师人数" prop="tecnPsncnt">
            <el-input
                v-model="medinsDeptInfoBFormEdit.tecnPsncnt"
                placeholder="请输入技师人数"
                maxlength="${field.columnLength}"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="medinsDeptInfoBFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="medinsDeptInfoBFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="medinsDeptInfoBFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="medinsDeptInfoBFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="medinsDeptInfoBFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="medinsDeptInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="medinsDeptInfoBFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="medinsDeptInfoBFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="medinsDeptInfoBFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="medinsDeptInfoBFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="medinsDeptInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="medinsDeptInfoBFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="medinsDeptInfoBFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="medinsDeptInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="medinsDeptInfoBFormEdit.updtTime"
                placeholder="请输入更新时间"
                :disabled="medinsDeptInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="medinsDeptInfoBEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="medinsDeptInfoBEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './medins-dept-info-b-mngr.service'
import MedinsDeptInfoBClass from '@/modules/demo/class/medins-dept-info-b-mngr.class'
import MedinsDeptInfoBQueryClass from '@/modules/demo/class/medins-dept-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.medinsDeptInfoBFormQuery = new MedinsDeptInfoBQueryClass()
      this.medinsDeptInfoBFormEdit = new MedinsDeptInfoBClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.medinsDeptInfoBList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.medinsDeptInfoBFormDisabled = false
      this.medinsDeptInfoBFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryMedinsDeptInfoB () {
      try {
        this.tableLoading = true
        const medinsDeptInfoBResult = await Service.resources.getByPage(this.medinsDeptInfoBFormQuery, this.paginationConfig)
        if (medinsDeptInfoBResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.medinsDeptInfoBList = []
        } else {
          this.medinsDeptInfoBList = medinsDeptInfoBResult.result
          this.paginationConfig.pageNumber = medinsDeptInfoBResult.pageNumber
          this.paginationConfig.pageSize = medinsDeptInfoBResult.pageSize
          this.paginationConfig.total = medinsDeptInfoBResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addMedinsDeptInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.medinsDeptInfoBFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryMedinsDeptInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateMedinsDeptInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.medinsDeptInfoBFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryMedinsDeptInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteMedinsDeptInfoB (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryMedinsDeptInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetMedinsDeptInfoBEditForm () {
      this.$refs.medinsDeptInfoBEditForm.resetFields()
    },
    medinsDeptInfoBEditCancel () {
      this.resetMedinsDeptInfoBEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.medinsDeptInfoBFormEdit = new MedinsDeptInfoBClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.medinsDeptInfoBEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.medinsDeptInfoBFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.medinsDeptInfoBEditForm.clearValidate()
      })
    },
    medinsDeptInfoBEditConfirm () {
      this.$refs.medinsDeptInfoBEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateMedinsDeptInfoB()
          } else {
            this.addMedinsDeptInfoB()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteMedinsDeptInfoB(row.medinsDeptInfoId)
      })
    }
  },
  data () {
    const medinsDeptInfoBColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗机构代码', prop: 'medinsCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '国家科室编码', prop: 'natDeptCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医院科室编号', prop: 'hospDeptCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医院科室名称', prop: 'hospDeptName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '简介', prop: 'itro', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始时间',
        prop: 'begntime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束时间',
        prop: 'endtime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '科室负责人姓名', prop: 'deptResperName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '科室负责人电话', prop: 'deptResperTel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '科室医疗服务范围', prop: 'deptMedServScp', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '床位数', prop: 'bedCnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医师人数', prop: 'drPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '药师人数', prop: 'pharPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '护士人数', prop: 'nursPsncnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '技师人数', prop: 'tecnPsncnt', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const medinsDeptInfoBRules = {
      medinsCode: [{ required: true, message: '请填写医疗机构代码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      natDeptCode: [{ required: true, message: '请填写国家科室编码', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      hospDeptCode: [{ required: true, message: '请填写医院科室编号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      hospDeptName: [{ required: true, message: '请填写医院科室名称', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      itro: [{ required: true, message: '请填写简介', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      begntime: [{ required: true, type: 'date', message: '请选择开始时间', trigger: 'change' }],
      endtime: [{ required: true, type: 'date', message: '请选择结束时间', trigger: 'change' }],
      deptResperName: [{ required: true, message: '请填写科室负责人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      deptResperTel: [{ required: true, message: '请填写科室负责人电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      deptMedServScp: [{ required: true, message: '请填写科室医疗服务范围', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      bedCnt: [{ required: true, message: '请填写床位数', trigger: 'blur' }
      ],
      drPsncnt: [{ required: true, message: '请填写医师人数', trigger: 'blur' }
      ],
      pharPsncnt: [{ required: true, message: '请填写药师人数', trigger: 'blur' }
      ],
      nursPsncnt: [{ required: true, message: '请填写护士人数', trigger: 'blur' }
      ],
      tecnPsncnt: [{ required: true, message: '请填写技师人数', trigger: 'blur' }
      ],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      medinsDeptInfoBTabColDefs: medinsDeptInfoBColDefs,
      medinsDeptInfoBList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      medinsDeptInfoBFormDisabled: false,
      medinsDeptInfoBFormEditDisabled: false,
      medinsDeptInfoBFormQuery: new MedinsDeptInfoBQueryClass(),
      medinsDeptInfoBFormEdit: new MedinsDeptInfoBClass(),
      medinsDeptInfoBEditFormRules: medinsDeptInfoBRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
