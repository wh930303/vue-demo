<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      @blur="blurPsnInfoB"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                      v-model="psnInfoBFormQuery.psnName"
                      placeholder="请输入人员姓名"
                      maxlength="50"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                      v-model="psnInfoBFormQuery.brdy"
                      placeholder="请输入出生日期"
                      :disabled="true"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                      v-model="psnInfoBFormQuery.certNo"
                      placeholder="请输入证件号码"
                      maxlength="30"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="psnInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                      v-model="psnInfoBFormQuery.naty"
                      placeholder="请输入民族"
                      maxlength="6"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                      v-model="psnInfoBFormQuery.addr"
                      placeholder="请输入联系地址"
                      maxlength="200"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                      v-model="psnInfoBFormQuery.gend"
                      placeholder="请输入性别"
                      maxlength="1"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                      v-model="psnInfoBFormQuery.insutype"
                      placeholder="请输入险种"
                      maxlength="6"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="psnInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="psnInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="6"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                      v-model="psnInfoBFormQuery.empCode"
                      placeholder="请输入单位编码"
                      maxlength="30"
                      :disabled="true"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryPsnInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="psnInfoBTabColDefs"
              :data="psnInfoBList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryPsnInfoB"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title=""
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="psnInfoBFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="psnInfoBEditFormRules"
           ref="psnInfoBEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="psnInfoBFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="20"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员姓名" prop="psnName">
            <el-input
                v-model="psnInfoBFormEdit.psnName"
                placeholder="请输入人员姓名"
                maxlength="50"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="psnInfoBFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="psnInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certNo">
            <el-input
                v-model="psnInfoBFormEdit.certNo"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系电话" prop="tel">
            <el-input
                v-model="psnInfoBFormEdit.tel"
                placeholder="请输入联系电话"
                maxlength="50"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="民族" prop="naty">
            <el-input
                v-model="psnInfoBFormEdit.naty"
                placeholder="请输入民族"
                maxlength="6"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系地址" prop="addr">
            <el-input
                v-model="psnInfoBFormEdit.addr"
                placeholder="请输入联系地址"
                maxlength="200"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-input
                v-model="psnInfoBFormEdit.gend"
                placeholder="请输入性别"
                maxlength="1"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种" prop="insutype">
            <el-input
                v-model="psnInfoBFormEdit.insutype"
                placeholder="请输入险种"
                maxlength="6"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="psnInfoBFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保所属机构" prop="insuOptins">
            <el-input
                v-model="psnInfoBFormEdit.insuOptins"
                placeholder="请输入参保所属机构"
                maxlength="6"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编码" prop="empCode">
            <el-input
                v-model="psnInfoBFormEdit.empCode"
                placeholder="请输入单位编码"
                maxlength="30"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="测试创建" prop="test">
            <el-input
                v-model="psnInfoBFormEdit.test"
                placeholder="请输入测试创建"
                maxlength="255"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="psnInfoBFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="psnInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="psnInfoBEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="psnInfoBEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './psn-info-b-mngr.service'
import PsnInfoBClass from '@/modules/demo/class/psn-info-b-mngr.class'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInfoBFormEdit = new PsnInfoBClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.psnInfoBList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.psnInfoBFormDisabled = false
      this.psnInfoBFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async blurPsnInfoB () {
      var psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          const psnInfoBResult = await Service.resources.queryAll(this.psnInfoBFormQuery)
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          } else {
            this.psnInfoBFormQuery = new PsnInfoBQueryClass()
            this.psnInfoBFormQuery.psnNo = psnNo
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    // 异步调用，一律采用 async/await 语法
    async queryPsnInfoB () {
      try {
        this.tableLoading = true
        const psnInfoBResult = await Service.resources.getByPage(this.psnInfoBFormQuery, this.paginationConfig)
        if (psnInfoBResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.psnInfoBList = []
        } else {
          this.psnInfoBList = psnInfoBResult.result
          this.paginationConfig.pageNumber = psnInfoBResult.pageNumber
          this.paginationConfig.pageSize = psnInfoBResult.pageSize
          this.paginationConfig.total = psnInfoBResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addPsnInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.psnInfoBFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryPsnInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updatePsnInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.psnInfoBFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryPsnInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deletePsnInfoB (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryPsnInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetPsnInfoBEditForm () {
      this.$refs.psnInfoBEditForm.resetFields()
    },
    psnInfoBEditCancel () {
      this.resetPsnInfoBEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.psnInfoBFormEdit = new PsnInfoBClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnInfoBEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.psnInfoBFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.psnInfoBEditForm.clearValidate()
      })
    },
    psnInfoBEditConfirm () {
      this.$refs.psnInfoBEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updatePsnInfoB()
          } else {
            this.addPsnInfoB()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deletePsnInfoB(row.rid)
      })
    }
  },
  data () {
    const psnInfoBColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员姓名', prop: 'psnName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '证件号码', prop: 'certNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系电话', prop: 'tel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '民族', prop: 'naty', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系地址', prop: 'addr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '性别', prop: 'gend', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种', prop: 'insutype', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位名称', prop: 'empName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保所属机构', prop: 'insuOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编码', prop: 'empCode', width: '120px' },
      // { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '测试创建', prop: 'test', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const psnInfoBRules = {
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      brdy: [{ required: true, type: 'date', message: '请选择出生日期', trigger: 'change' }],
      certNo: [{ required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      tel: [{ required: true, message: '请填写联系电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      naty: [{ required: true, message: '请填写民族', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      addr: [{ required: true, message: '请填写联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      psnName: [{ required: true, message: '请填写人员姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [{ required: true, message: '请填写性别', trigger: 'blur' },
        { max: 1, message: '长度不能超过 1 个字符', trigger: 'blur' }
      ],
      insutype: [{ required: true, message: '请填写险种', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empName: [{ required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      insuOptins: [{ required: true, message: '请填写参保所属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empCode: [{ required: true, message: '请填写单位编码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ]
      // test: [{  required:true, message: '请填写测试创建', trigger: 'blur' },
      //   {  max: 255, message: '长度不能超过 255 个字符', trigger: 'blur' }
      // ],
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      psnInfoBTabColDefs: psnInfoBColDefs,
      psnInfoBList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      psnInfoBFormDisabled: false,
      psnInfoBFormEditDisabled: false,
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInfoBFormEdit: new PsnInfoBClass(),
      psnInfoBEditFormRules: psnInfoBRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
