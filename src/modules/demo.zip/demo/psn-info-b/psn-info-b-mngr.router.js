/*
* Created: 2021-01-05
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-05
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/psn-info-b',
  component: () => import('@/modules/demo/psn-info-b/psn-info-b-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
    ] }
}
