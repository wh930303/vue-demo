<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="infoCodeFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="代码ID">
                  <el-input
                      v-model="infoCodeFormQuery.codeId"
                      placeholder="请输入代码ID"
                      maxlength="30"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="代码类别">
                  <el-input
                      v-model="infoCodeFormQuery.codeType"
                      placeholder="请输入代码类别"
                      maxlength="30"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="类别名称">
                  <el-input
                      v-model="infoCodeFormQuery.typeName"
                      placeholder="请输入类别名称"
                      maxlength="100"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="代码值">
                  <el-input
                      v-model="infoCodeFormQuery.val"
                      placeholder="请输入代码值"
                      maxlength="20"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="代码名称">
                  <el-input
                      v-model="infoCodeFormQuery.valName"
                      placeholder="请输入代码名称"
                      maxlength="100"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="开始日期">
                  <el-date-picker
                      v-model="infoCodeFormQuery.begnDate"
                      placeholder="请输入开始日期"
                      :disabled="infoCodeFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="终止日期">
                  <el-date-picker
                      v-model="infoCodeFormQuery.enddate"
                      placeholder="请输入终止日期"
                      :disabled="infoCodeFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="infoCodeFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="顺序号">
                  <el-input
                      v-model="infoCodeFormQuery.seq"
                      placeholder="请输入顺序号"
                      maxlength="${field.columnLength}"
                      :disabled="infoCodeFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
<!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryInfoCode">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="infoCodeTabColDefs"
              :data="infoCodeList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryInfoCode"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="代码表"
        :visible.sync="editDialogVisible"
        width="80%"
:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="infoCodeFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="infoCodeEditFormRules"
           ref="infoCodeEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代码ID" prop="codeId">
            <el-input
                v-model="infoCodeFormEdit.codeId"
                placeholder="请输入代码ID"
                maxlength="30"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代码类别" prop="codeType">
            <el-input
                v-model="infoCodeFormEdit.codeType"
                placeholder="请输入代码类别"
                maxlength="30"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="类别名称" prop="typeName">
            <el-input
                v-model="infoCodeFormEdit.typeName"
                placeholder="请输入类别名称"
                maxlength="100"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代码值" prop="val">
            <el-input
                v-model="infoCodeFormEdit.val"
                placeholder="请输入代码值"
                maxlength="20"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代码名称" prop="valName">
            <el-input
                v-model="infoCodeFormEdit.valName"
                placeholder="请输入代码名称"
                maxlength="100"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始日期" prop="begnDate">
            <el-date-picker
                v-model="infoCodeFormEdit.begnDate"
                placeholder="请输入开始日期"
                :disabled="infoCodeFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="终止日期" prop="enddate">
            <el-date-picker
                v-model="infoCodeFormEdit.enddate"
                placeholder="请输入终止日期"
                :disabled="infoCodeFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="infoCodeFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="顺序号" prop="seq">
            <el-input
                v-model="infoCodeFormEdit.seq"
                placeholder="请输入顺序号"
                maxlength="${field.columnLength}"
                :disabled="infoCodeFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="infoCodeEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="infoCodeEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './info-code-mngr.service'
import InfoCodeClass from '@/modules/demo/class/info-code-mngr.class'
import InfoCodeQueryClass from '@/modules/demo/class/info-code-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {
    this.queryInfoCode()
  },
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.infoCodeFormQuery = new InfoCodeQueryClass()
      this.infoCodeFormEdit = new InfoCodeClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.infoCodeList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.infoCodeFormDisabled = false
      this.infoCodeFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryInfoCode () {
      try {
        this.tableLoading = true
        const infoCodeResult = await Service.resources.getByPage(this.infoCodeFormQuery, this.paginationConfig)
        if (infoCodeResult.result.length === 0) {
          this.$message.info('没有查询到数据！')
          this.infoCodeList = []
        } else {
          this.infoCodeList = infoCodeResult.result
          this.paginationConfig.pageNumber = infoCodeResult.pageNumber
          this.paginationConfig.pageSize = infoCodeResult.pageSize
          this.paginationConfig.total = infoCodeResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addInfoCode () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.infoCodeFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryInfoCode()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateInfoCode () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.infoCodeFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryInfoCode()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteInfoCode (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryInfoCode()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetInfoCodeEditForm () {
      this.$refs.infoCodeEditForm.resetFields()
    },
    infoCodeEditCancel () {
      this.resetInfoCodeEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.infoCodeFormEdit = new InfoCodeClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.infoCodeEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.infoCodeFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.infoCodeEditForm.clearValidate()
      })
    },
    infoCodeEditConfirm () {
      this.$refs.infoCodeEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateInfoCode()
          } else {
            this.addInfoCode()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteInfoCode(row.codeId)
      })
    }
  },
  data () {
    const infoCodeColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代码类别', prop: 'codeType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '类别名称', prop: 'typeName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代码值', prop: 'val', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代码名称', prop: 'valName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begnDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        minWidth: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '终止日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        minWidth: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        minWidth: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '顺序号', prop: 'seq', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        minWidth: '150px',
        fixed: 'right'
      }
    ]
    const infoCodeRules = {
      codeType: [{ required: true, message: '请填写代码类别', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      typeName: [{ required: true, message: '请填写类别名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      val: [{ required: true, message: '请填写代码值', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      valName: [{ required: true, message: '请填写代码名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      begnDate: [{ required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }],
      enddate: [{ required: true, type: 'date', message: '请选择终止日期', trigger: 'change' }],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      seq: [{ required: true, message: '请填写顺序号', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      infoCodeTabColDefs: infoCodeColDefs,
      infoCodeList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      infoCodeFormDisabled: false,
      infoCodeFormEditDisabled: false,
      infoCodeFormQuery: new InfoCodeQueryClass(),
      infoCodeFormEdit: new InfoCodeClass(),
      infoCodeEditFormRules: infoCodeRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
