<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      @blur="blurPsnInfoB"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                      v-model="psnInfoBFormQuery.psnName"
                      placeholder="请输入人员姓名"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                      v-model="psnInfoBFormQuery.brdy"
                      placeholder="请输入出生日期"

                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                      v-model="psnInfoBFormQuery.certNo"
                      placeholder="请输入证件号码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="psnInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                      v-model="psnInfoBFormQuery.naty"
                      placeholder="请输入民族"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                      v-model="psnInfoBFormQuery.addr"
                      placeholder="请输入联系地址"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                      v-model="psnInfoBFormQuery.gend"
                      placeholder="请输入性别"
                      maxlength="1"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                      v-model="psnInfoBFormQuery.insutype"
                      placeholder="请输入险种"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="psnInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="psnInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                      v-model="psnInfoBFormQuery.empCode"
                      placeholder="请输入单位编码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryTrumChkRegD">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="trumChkRegDTabColDefs"
              :data="trumChkRegDList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryTrumChkRegD"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="外伤审核登记信息"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="trumChkRegDFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="trumChkRegDEditFormRules"
           ref="trumChkRegDEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="trumChkRegDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种" prop="insutype">
            <el-input
                v-model="trumChkRegDFormEdit.insutype"
                placeholder="请输入险种"
                maxlength="6"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="trumChkRegDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="trumChkRegDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件类型" prop="certType">
            <el-input
                v-model="trumChkRegDFormEdit.certType"
                placeholder="请输入证件类型"
                maxlength="6"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certno">
            <el-input
                v-model="trumChkRegDFormEdit.certno"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员姓名" prop="psnName">
            <el-input
                v-model="trumChkRegDFormEdit.psnName"
                placeholder="请输入人员姓名"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-input
                v-model="trumChkRegDFormEdit.gend"
                placeholder="请输入性别"
                maxlength="1"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="民族" prop="naty">
            <el-select v-model="trumChkRegDFormEdit.naty" type="NATY" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="trumChkRegDFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系电话" prop="tel">
            <el-input
                v-model="trumChkRegDFormEdit.tel"
                placeholder="请输入联系电话"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系地址" prop="addr">
            <el-input
                v-model="trumChkRegDFormEdit.addr"
                placeholder="请输入联系地址"
                maxlength="200"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保所属机构" prop="insuOptins">
            <el-input
                v-model="trumChkRegDFormEdit.insuOptins"
                placeholder="请输入参保所属机构"
                maxlength="6"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="trumChkRegDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="trumChkRegDFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="就诊事件ID" prop="mdtrtEvtId">
            <el-input
                v-model="trumChkRegDFormEdit.mdtrtEvtId"
                placeholder="请输入就诊事件ID"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结算事件ID" prop="setlId">
            <el-input
                v-model="trumChkRegDFormEdit.setlId"
                placeholder="请输入结算事件ID"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点机构编号" prop="fixmedinsCode">
            <el-input
                v-model="trumChkRegDFormEdit.fixmedinsCode"
                placeholder="请输入定点机构编号"
                maxlength="30"
                @blur="queryMedinsInfoB"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点机构名称" prop="fixmedinsName">
            <el-input
                v-model="trumChkRegDFormEdit.fixmedinsName"
                placeholder="请输入定点机构名称"
                maxlength="200"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <!-- <el-form-item label="医药机构等级" prop="medinsLv">
            <el-input
                v-model="trumChkRegDFormEdit.medinsLv"
                placeholder="请输入医药机构等级"
                maxlength="6"

            ></el-input>
          </el-form-item> -->
          <el-form-item label="医药机构等级">
            <el-select v-model="trumChkRegDFormEdit.medinsLv" type="MEDINSLV"  class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点归属机构" prop="fixmedinsPoolarea">
            <el-input
                v-model="trumChkRegDFormEdit.fixmedinsPoolarea"
                placeholder="请输入定点归属机构"
                maxlength="6"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始日期" prop="begndate">
            <el-date-picker
                v-model="trumChkRegDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束日期" prop="enddate">
            <el-date-picker
                v-model="trumChkRegDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="伤害部位" prop="trumPart">
            <el-input
                v-model="trumChkRegDFormEdit.trumPart"
                placeholder="请输入伤害部位"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="受伤时间" prop="trumTime">
            <el-date-picker
                v-model="trumChkRegDFormEdit.trumTime"
                placeholder="请输入受伤时间"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="受伤地点" prop="trumSite">
            <el-input
                v-model="trumChkRegDFormEdit.trumSite"
                placeholder="请输入受伤地点"
                maxlength="200"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="致伤原因" prop="trumRea">
            <el-input
                v-model="trumChkRegDFormEdit.trumRea"
                placeholder="请输入致伤原因"
                maxlength="200"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="入院时间" prop="admTime">
            <el-date-picker
                v-model="trumChkRegDFormEdit.admTime"
                placeholder="请输入入院时间"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="入院方式" prop="admMtd">
            <el-select v-model="trumChkRegDFormEdit.admMtd" type="ADM_MTD" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="入院诊断" prop="admDise">
            <el-input
                v-model="trumChkRegDFormEdit.admDise"
                placeholder="请输入入院诊断"
                maxlength="100"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="审核支付标志" prop="chkPayFlag">
            <el-select v-model="trumChkRegDFormEdit.chkPayFlag" type="CHK_PAY_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="使用状态" prop="usedStas">
            <el-select v-model="trumChkRegDFormEdit.usedStas" type="USED_STAS" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人姓名" prop="agntName">
            <el-input
                v-model="trumChkRegDFormEdit.agntName"
                placeholder="请输入代办人姓名"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人证件类型" prop="agntCertType">
            <el-input
                v-model="trumChkRegDFormEdit.agntCertType"
                placeholder="请输入代办人证件类型"
                maxlength="6"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人证件号码" prop="agntCertno">
            <el-input
                v-model="trumChkRegDFormEdit.agntCertno"
                placeholder="请输入代办人证件号码"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人联系方式" prop="agntTel">
            <el-input
                v-model="trumChkRegDFormEdit.agntTel"
                placeholder="请输入代办人联系方式"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人联系地址" prop="agntAddr">
            <el-input
                v-model="trumChkRegDFormEdit.agntAddr"
                placeholder="请输入代办人联系地址"
                maxlength="200"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人关系" prop="agntRlts">
            <el-select v-model="trumChkRegDFormEdit.agntRlts" type="AGNT_RLTS" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="备注" prop="memo">
            <el-input
                v-model="trumChkRegDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="申报来源" prop="dclaSouc">
            <el-input
                v-model="trumChkRegDFormEdit.dclaSouc"
                placeholder="请输入申报来源"
                maxlength="6"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="trumChkRegDFormEdit.valiFlag" type="VALI_FLAG"  class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="trumChkRegDFormEdit.updtTime"
                placeholder="请输入更新时间"

                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>

        <!--

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="trumChkRegDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="trumChkRegDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="trumChkRegDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="trumChkRegDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="trumChkRegDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="trumChkRegDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="trumChkRegDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="trumChkRegDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="trumChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="trumChkRegDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="30"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="trumChkRegDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="trumChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="trumChkRegDEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="trumChkRegDEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './trum-chk-reg-d-mngr.service'
import TrumChkRegDClass from '@/modules/demo/class/trum-chk-reg-d-mngr.class'
import TrumChkRegDQueryClass from '@/modules/demo/class/trum-chk-reg-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.trumChkRegDFormQuery = new TrumChkRegDQueryClass()
      this.trumChkRegDFormEdit = new TrumChkRegDClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.trumChkRegDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.trumChkRegDFormDisabled = false
      this.trumChkRegDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          this.psnInfoBFormQuery = new PsnInfoBQueryClass()
          this.psnInfoBFormQuery.psnNo = psnNo
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(this.psnInfoBFormQuery)
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    async checkIsPass () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInsuDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
      const psnInsuDResult = await psnInfoBService.getPsnInsuD(this.psnInsuDFormQuery)
      // 已经参保且参保状正常
      if (psnInsuDResult.length > 0 && psnInsuDResult[0].psnInsuStas == '1') {
        this.psnInsuDFormQuery = psnInsuDResult[0]
        return true
      } else {
        return false
      }
    },
    // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
    checkBegnDate () {
      const begnDate = this.trumChkRegDFormEdit.begndate
      const endDate = this.trumChkRegDFormEdit.enddate
      if (begnDate != null && begnDate != '' && endDate != null && endDate != '') {
        if (begnDate > endDate) {
          this.$message.error('开始日期不得晚于结束日期!')
          return false
        }
      }
      return true
    },
    // 查询开始时间和结束时间相交的信息
    async checkOverlapping () {
      try {
        this.trumChkRegDFormQuery = new TrumChkRegDQueryClass()
        this.trumChkRegDFormQuery.rid = this.trumChkRegDFormEdit.rid
        this.trumChkRegDFormQuery.psnNo = this.trumChkRegDFormEdit.psnNo
        if (this.trumChkRegDFormEdit.begndate != null && this.trumChkRegDFormEdit.begndate != '') {
          this.trumChkRegDFormQuery.begndate = new Date(this.trumChkRegDFormEdit.begndate).getTime()
        }

        if (this.trumChkRegDFormEdit.enddate != null && this.trumChkRegDFormEdit.enddate != '') {
          this.trumChkRegDFormQuery.enddate = new Date(this.trumChkRegDFormEdit.enddate).getTime()
        } else {
          this.trumChkRegDFormQuery.enddate = new Date(this.trumChkRegDFormEdit.begndate)
          this.trumChkRegDFormQuery.enddate.setDate(this.trumChkRegDFormQuery.enddate.getDate() + 1)
          this.trumChkRegDFormQuery.enddate = new Date(this.trumChkRegDFormQuery.enddate).getTime()
        }
        const reflAppyDResult = await Service.resources.queryOverlapping(this.trumChkRegDFormQuery)
        if (reflAppyDResult.length == '0') {
          return true
        } else {
          this.$message.error('与其他登记信息的开始日期和结束日期不能交叉、重叠!')
          return false
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.trumChkRegDFormQuery = new TrumChkRegDQueryClass()
      }
    },
    // 查询医药机构信息
    async queryMedinsInfoB () {
      this.medinsInfoBFormQuery.medinsNo = this.trumChkRegDFormEdit.fixmedinsCode
      if (this.medinsInfoBFormQuery.medinsNo != null && this.medinsInfoBFormQuery.medinsNo != '') {
        const result = await psnInfoBService.getMedinsInfoB(this.medinsInfoBFormQuery)
        // 存在医药机构信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医药机构名称
          this.trumChkRegDFormEdit.fixmedinsName = result[0].medinsName
          // 医药机构等级
          this.trumChkRegDFormEdit.medinsLv = result[0].medinslv
          // 定点归属机构
          this.trumChkRegDFormEdit.fixmedinsPoolarea = result[0].poolarea
        } else {
          this.trumChkRegDFormEdit.fixmedinsName = ''
          this.trumChkRegDFormEdit.medinsLv = ''
          this.trumChkRegDFormEdit.fixmedinsPoolarea = ''
          this.$message.error('该医药机构不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.trumChkRegDFormEdit.fixmedinsName = ''
        this.trumChkRegDFormEdit.medinsLv = ''
        this.trumChkRegDFormEdit.fixmedinsPoolarea = ''
      }
    },
    // 异步调用，一律采用 async/await 语法
    async queryTrumChkRegD () {
      try {
        this.trumChkRegDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
        this.tableLoading = true
        const trumChkRegDResult = await Service.resources.getByPage(this.trumChkRegDFormQuery, this.paginationConfig)
        if (trumChkRegDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.trumChkRegDList = []
        } else {
          this.trumChkRegDList = trumChkRegDResult.result
          this.paginationConfig.pageNumber = trumChkRegDResult.pageNumber
          this.paginationConfig.pageSize = trumChkRegDResult.pageSize
          this.paginationConfig.total = trumChkRegDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async saveBeforeCheck () {
      // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
      const flag1 = this.checkBegnDate()
      if (flag1) {
        // 转出医院不能和转入医院相同
        const flag2 = await this.checkOverlapping()
        if (flag2) {
          return true
        }
      }
      return false
    },
    async addTrumChkRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.post(this.trumChkRegDFormEdit)
          this.$message.info('新增成功！')
          this.editDialogVisible = false
          this.queryTrumChkRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateTrumChkRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.put(this.trumChkRegDFormEdit)
          this.$message.info('更新成功！')
          this.editDialogVisible = false
          this.queryTrumChkRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteTrumChkRegD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryTrumChkRegD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetTrumChkRegDEditForm () {
      this.$refs.trumChkRegDEditForm.resetFields()
    },
    trumChkRegDEditCancel () {
      this.resetTrumChkRegDEditForm()
      this.editDialogVisible = false
    },
    async showAddDialog () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo == null || psnNo == '') {
        this.$message.info('请输入人员编号！')
        return
      }
      const flag = await this.checkIsPass()
      if (!flag) {
        this.$message.info('该用户未参保或参保状态异常！')
        return
      }
      this.trumChkRegDFormEdit = new TrumChkRegDClass()
      this.operateType = 'add'
      // 添加默认信息
      this.trumChkRegDFormEdit.dclaSouc = '中心经办系统'
      this.trumChkRegDFormEdit.begndate = new Date()
      this.trumChkRegDFormEdit.updtTime = new Date()
      this.trumChkRegDFormEdit.valiFlag = '1'

      // 添加个人基本信息
      this.trumChkRegDFormEdit.psnNo = this.psnInfoBFormQuery.psnNo
      this.trumChkRegDFormEdit.certno = this.psnInfoBFormQuery.certNo
      this.trumChkRegDFormEdit.psnName = this.psnInfoBFormQuery.psnName
      this.trumChkRegDFormEdit.gend = this.psnInfoBFormQuery.gend
      this.trumChkRegDFormEdit.naty = '0' // 汉族
      this.trumChkRegDFormEdit.brdy = this.psnInfoBFormQuery.brdy
      this.trumChkRegDFormEdit.tel = this.psnInfoBFormQuery.tel
      this.trumChkRegDFormEdit.addr = this.psnInfoBFormQuery.addr
      this.trumChkRegDFormEdit.insuOptins = this.psnInfoBFormQuery.insuOptins
      this.trumChkRegDFormEdit.empNo = this.psnInfoBFormQuery.empCode
      this.trumChkRegDFormEdit.empName = this.psnInfoBFormQuery.empName
      this.trumChkRegDFormEdit.certType = '0' // 身份证
      this.trumChkRegDFormEdit.insutype = this.psnInfoBFormQuery.insutype
      // 添加人员参保关系ID
      this.trumChkRegDFormEdit.psnInsuRltsId = this.psnInsuDFormQuery.psnInsuRltsId
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.trumChkRegDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.trumChkRegDFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.trumChkRegDEditForm.clearValidate()
      })
    },
    trumChkRegDEditConfirm () {
      this.$refs.trumChkRegDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateTrumChkRegD()
          } else {
            this.addTrumChkRegD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteTrumChkRegD(row.trtDclaDetlSn)
      })
    }
  },
  data () {
    const trumChkRegDColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种', prop: 'insutype', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '申报来源', prop: 'dclaSouc', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员参保关系ID', prop: 'psnInsuRltsId', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      // { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '证件类型', prop: 'certType', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '证件类型',
        prop: 'certType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'CERT_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '证件号码', prop: 'certno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员姓名', prop: 'psnName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '性别', prop: 'gend', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '民族',
        prop: 'naty',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'NATY') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系电话', prop: 'tel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系地址', prop: 'addr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保所属机构', prop: 'insuOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编号', prop: 'empNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位名称', prop: 'empName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '就诊事件ID', prop: 'mdtrtEvtId', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '结算事件ID', prop: 'setlId', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点机构编号', prop: 'fixmedinsCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点机构名称', prop: 'fixmedinsName', width: '120px' },
      // { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医药机构等级', prop: 'medinsLv', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医药机构等级',
        prop: 'medinslv',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MEDINSLV') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点归属机构', prop: 'fixmedinsPoolarea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '伤害部位', prop: 'trumPart', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '受伤时间',
        prop: 'trumTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '受伤地点', prop: 'trumSite', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '致伤原因', prop: 'trumRea', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '入院方式',
        prop: 'admMtd',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'ADM_MTD') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '入院时间',
        prop: 'admTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '入院诊断', prop: 'admDise', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代办人姓名', prop: 'agntName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代办人证件类型', prop: 'agntCertType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代办人证件号码', prop: 'agntCertno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代办人联系方式', prop: 'agntTel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '代办人联系地址', prop: 'agntAddr', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人关系',
        prop: 'agntRlts',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'AGNT_RLTS') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '审核支付标志',
        prop: 'chkPayFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'CHK_PAY_FLAG') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '使用状态',
        prop: 'usedStas',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'USED_STAS') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '备注', prop: 'memo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const trumChkRegDRules = {
      insutype: [{ required: true, message: '请填写险种', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      dclaSouc: [{ required: true, message: '请填写申报来源', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [{ required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      begndate: [{ required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }],
      enddate: [{ required: false, type: 'date', message: '请选择结束日期', trigger: 'change' }],
      certType: [{ required: true, message: '请填写证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      certno: [{ required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnName: [{ required: true, message: '请填写人员姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [{ required: true, message: '请填写性别', trigger: 'blur' },
        { max: 1, message: '长度不能超过 1 个字符', trigger: 'blur' }
      ],
      naty: [{ required: true, message: '请选择民族', trigger: 'change' }],
      brdy: [{ required: true, type: 'date', message: '请选择出生日期', trigger: 'change' }],
      tel: [{ required: true, message: '请填写联系电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      addr: [{ required: true, message: '请填写联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      insuOptins: [{ required: true, message: '请填写参保所属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empNo: [{ required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empName: [{ required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      mdtrtEvtId: [{ required: true, message: '请填写就诊事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      setlId: [{ required: true, message: '请填写结算事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsCode: [{ required: true, message: '请填写定点机构编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsName: [{ required: false, message: '请填写定点机构名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      // medinsLv: [{  required:false, message: '请填写医药机构等级', trigger: 'blur' },
      //   {  max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      // ],
      medinslv: [{ required: false, message: '请选择医疗机构等级', trigger: 'change' }],
      fixmedinsPoolarea: [{ required: false, message: '请填写定点归属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      trumPart: [{ required: false, message: '请填写伤害部位', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      trumTime: [{ required: false, type: 'date', message: '请选择受伤时间', trigger: 'change' }],
      trumSite: [{ required: false, message: '请填写受伤地点', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      trumRea: [{ required: false, message: '请填写致伤原因', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      admMtd: [{ required: false, message: '请选择入院方式', trigger: 'change' }],
      admTime: [{ required: false, type: 'date', message: '请选择入院时间', trigger: 'change' }],
      admDise: [{ required: false, message: '请填写入院诊断', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      agntName: [{ required: false, message: '请填写代办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      agntCertType: [{ required: false, message: '请填写代办人证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      agntCertno: [{ required: false, message: '请填写代办人证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntTel: [{ required: false, message: '请填写代办人联系方式', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntAddr: [{ required: false, message: '请填写代办人联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      agntRlts: [{ required: false, message: '请选择代办人关系', trigger: 'change' }],
      chkPayFlag: [{ required: true, message: '请选择审核支付标志', trigger: 'change' }],
      usedStas: [{ required: true, message: '请选择使用状态', trigger: 'change' }],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      memo: [{ required: false, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      trumChkRegDTabColDefs: trumChkRegDColDefs,
      trumChkRegDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      trumChkRegDFormDisabled: false,
      trumChkRegDFormEditDisabled: false,
      trumChkRegDFormQuery: new TrumChkRegDQueryClass(),
      trumChkRegDFormEdit: new TrumChkRegDClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      trumChkRegDEditFormRules: trumChkRegDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
