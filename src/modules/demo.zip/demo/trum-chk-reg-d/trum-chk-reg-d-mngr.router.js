/*
 * @Author: your name
 * @Date: 2022-03-01 21:50:25
 * @LastEditTime: 2022-03-02 11:48:06
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/trum-chk-reg-d/trum-chk-reg-d-mngr.router.js
 */
/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
  // path 保证全局唯一
  path: '/trum-chk-reg-d',
  component: () => import('@/modules/demo/trum-chk-reg-d/trum-chk-reg-d-mngr.vue'),
  // typeList 中编写模块所需二级代码
  meta: {
    typeList: [
      'NATY',
      'ADM_MTD',
      'AGNT_RLTS',
      'CHK_PAY_FLAG',
      'USED_STAS',
      'VALI_FLAG',
      'MEDINSLV',
      'CERT_TYPE'
    ]
  }
}
