/*
 * @Author: your name
 * @Date: 2022-03-01 21:50:24
 * @LastEditTime: 2022-03-02 11:29:24
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/dr-info-b/dr-info-b-mngr.router.js
 */
/*
* Created: 2021-01-08
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-08
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/dr-info-b',
  component: () => import('@/modules/demo/dr-info-b/dr-info-b-mngr.vue'),
  // typeList 中编写模块所需二级代码
  meta: { typeList: [
    'DR_PRAC_TYPE',
    'DR_PRAC_SCP_CODE',
    'MUL_PRAC_FLAG',
    'VALI_FLAG',
    'RX_PERM_FLAG',
    'DR_PRO_TECH_DUTY'
  ] }
}
