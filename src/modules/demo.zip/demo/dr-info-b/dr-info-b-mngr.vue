<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="drInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师信息ID">
                  <el-input
                      v-model="drInfoBFormQuery.drInfoId"
                      placeholder="请输入医师信息ID"
                      maxlength="40"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师代码">
                  <el-input
                      v-model="drInfoBFormQuery.drCode"
                      placeholder="请输入医师代码"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="drInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="个人能力简介">
                  <el-input
                      v-model="drInfoBFormQuery.psnItro"
                      placeholder="请输入个人能力简介"
                      maxlength="500"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师执业类别">
                  <el-select v-model="drInfoBFormQuery.drPracType" type="DR_PRAC_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师执业范围代码">
                  <el-select v-model="drInfoBFormQuery.drPracScpCode" type="DR_PRAC_SCP_CODE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="执业地区">
                  <el-input
                      v-model="drInfoBFormQuery.pracRegn"
                      placeholder="请输入执业地区"
                      maxlength="100"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="多点执业标志">
                  <el-select v-model="drInfoBFormQuery.mulPracFlag" type="MUL_PRAC_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="主执业机构编号">
                  <el-input
                      v-model="drInfoBFormQuery.mainPracinsNo"
                      placeholder="请输入主执业机构编号"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="主执业机构名称">
                  <el-input
                      v-model="drInfoBFormQuery.mainPracinsName"
                      placeholder="请输入主执业机构名称"
                      maxlength="50"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="主执业机构地址">
                  <el-input
                      v-model="drInfoBFormQuery.mainPracinsAddr"
                      placeholder="请输入主执业机构地址"
                      maxlength="100"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="离职时间">
                  <el-date-picker
                      v-model="drInfoBFormQuery.nempTime"
                      placeholder="请输入离职时间"
                      :disabled="drInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="drInfoBFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="拥有处方权标志">
                  <el-select v-model="drInfoBFormQuery.rxPermFlag" type="RX_PERM_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="医师卫生技术人员专业技术职务">
                  <el-select v-model="drInfoBFormQuery.drProTechDuty" type="DR_PRO_TECH_DUTY" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="drInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人">
                  <el-input
                      v-model="drInfoBFormQuery.crter"
                      placeholder="请输入创建人"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人姓名">
                  <el-input
                      v-model="drInfoBFormQuery.crterName"
                      placeholder="请输入创建人姓名"
                      maxlength="50"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建时间">
                  <el-date-picker
                      v-model="drInfoBFormQuery.crteTime"
                      placeholder="请输入创建时间"
                      :disabled="drInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建经办机构">
                  <el-input
                      v-model="drInfoBFormQuery.crteOptins"
                      placeholder="请输入创建经办机构"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人">
                  <el-input
                      v-model="drInfoBFormQuery.opter"
                      placeholder="请输入经办人"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人姓名">
                  <el-input
                      v-model="drInfoBFormQuery.opterName"
                      placeholder="请输入经办人姓名"
                      maxlength="50"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办时间">
                  <el-date-picker
                      v-model="drInfoBFormQuery.optTime"
                      placeholder="请输入经办时间"
                      :disabled="drInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办机构">
                  <el-input
                      v-model="drInfoBFormQuery.optins"
                      placeholder="请输入经办机构"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="版本号">
                  <el-input
                      v-model="drInfoBFormQuery.ver"
                      placeholder="请输入版本号"
                      maxlength="20"
                      :disabled="drInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryDrInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="drInfoBTabColDefs"
              :data="drInfoBList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryDrInfoB"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title=""
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="drInfoBFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="drInfoBEditFormRules"
           ref="drInfoBEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师信息ID" prop="drInfoId">
            <el-input
                v-model="drInfoBFormEdit.drInfoId"
                placeholder="请输入医师信息ID"
                maxlength="40"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师代码" prop="drCode">
            <el-input
                v-model="drInfoBFormEdit.drCode"
                placeholder="请输入医师代码"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="drInfoBFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="个人能力简介" prop="psnItro">
            <el-input
                v-model="drInfoBFormEdit.psnItro"
                placeholder="请输入个人能力简介"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师执业类别" prop="drPracType">
            <!-- <el-select v-model="drInfoBFormEdit.drPracType" type="DR_PRAC_TYPE" class="widthAuto"></el-select> -->
            <el-input
                v-model="drInfoBFormEdit.drPracType"
                placeholder="请输入医师执业类别"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师执业范围代码" prop="drPracScpCode">
            <!-- <el-select v-model="drInfoBFormEdit.drPracScpCode" type="DR_PRAC_SCP_CODE" class="widthAuto"></el-select> -->
            <el-input
                v-model="drInfoBFormEdit.drPracScpCode"
                placeholder="请输入医师执业范围代码"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="执业地区" prop="pracRegn">
            <el-input
                v-model="drInfoBFormEdit.pracRegn"
                placeholder="请输入执业地区"
                maxlength="100"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="多点执业标志" prop="mulPracFlag">
            <!-- <el-select v-model="drInfoBFormEdit.mulPracFlag" type="MUL_PRAC_FLAG" class="widthAuto"></el-select> -->
            <el-input
                v-model="drInfoBFormEdit.mulPracFlag"
                placeholder="请输入多点执业标志"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="主执业机构编号" prop="mainPracinsNo">
            <el-input
                v-model="drInfoBFormEdit.mainPracinsNo"
                placeholder="请输入主执业机构编号"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="主执业机构名称" prop="mainPracinsName">
            <el-input
                v-model="drInfoBFormEdit.mainPracinsName"
                placeholder="请输入主执业机构名称"
                maxlength="50"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="主执业机构地址" prop="mainPracinsAddr">
            <el-input
                v-model="drInfoBFormEdit.mainPracinsAddr"
                placeholder="请输入主执业机构地址"
                maxlength="100"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="离职时间" prop="nempTime">
            <el-date-picker
                v-model="drInfoBFormEdit.nempTime"
                placeholder="请输入离职时间"
                :disabled="drInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="drInfoBFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="拥有处方权标志" prop="rxPermFlag">
            <!-- <el-select v-model="drInfoBFormEdit.rxPermFlag" type="RX_PERM_FLAG" class="widthAuto"></el-select> -->
            <el-input
                v-model="drInfoBFormEdit.rxPermFlag"
                placeholder="请输入拥有处方权标志"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医师卫生技术人员专业技术职务" prop="drProTechDuty">
            <!-- <el-select v-model="drInfoBFormEdit.drProTechDuty" type="DR_PRO_TECH_DUTY" class="widthAuto"></el-select> -->
            <el-input
                v-model="drInfoBFormEdit.drProTechDuty"
                placeholder="请输入医师卫生技术人员专业技术职务"
                maxlength="500"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="drInfoBFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="drInfoBFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="drInfoBFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="drInfoBFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="drInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建经办机构" prop="crteOptins">
            <el-input
                v-model="drInfoBFormEdit.crteOptins"
                placeholder="请输入创建经办机构"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="drInfoBFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="drInfoBFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="drInfoBFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="drInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="drInfoBFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="版本号" prop="ver">
            <el-input
                v-model="drInfoBFormEdit.ver"
                placeholder="请输入版本号"
                maxlength="20"
                :disabled="drInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="drInfoBEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="drInfoBEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './dr-info-b-mngr.service'
import DrInfoBClass from '@/modules/demo/class/dr-info-b-mngr.class'
import DrInfoBQueryClass from '@/modules/demo/class/dr-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.drInfoBFormQuery = new DrInfoBQueryClass()
      this.drInfoBFormEdit = new DrInfoBClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.drInfoBList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.drInfoBFormDisabled = false
      this.drInfoBFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryDrInfoB () {
      try {
        this.tableLoading = true
        const drInfoBResult = await Service.resources.getByPage(this.drInfoBFormQuery, this.paginationConfig)
        if (drInfoBResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.drInfoBList = []
        } else {
          this.drInfoBList = drInfoBResult.result
          this.paginationConfig.pageNumber = drInfoBResult.pageNumber
          this.paginationConfig.pageSize = drInfoBResult.pageSize
          this.paginationConfig.total = drInfoBResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addDrInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.drInfoBFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryDrInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateDrInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.drInfoBFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryDrInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteDrInfoB (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryDrInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetDrInfoBEditForm () {
      this.$refs.drInfoBEditForm.resetFields()
    },
    drInfoBEditCancel () {
      this.resetDrInfoBEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.drInfoBFormEdit = new DrInfoBClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.drInfoBEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.drInfoBFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.drInfoBEditForm.clearValidate()
      })
    },
    drInfoBEditConfirm () {
      this.$refs.drInfoBEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateDrInfoB()
          } else {
            this.addDrInfoB()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteDrInfoB(row.drInfoId)
      })
    }
  },
  data () {
    const drInfoBColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医师代码', prop: 'drCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '个人能力简介', prop: 'psnItro', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医师执业类别',
        prop: 'drPracType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'DR_PRAC_TYPE') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医师执业范围代码',
        prop: 'drPracScpCode',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'DR_PRAC_SCP_CODE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '执业地区', prop: 'pracRegn', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '多点执业标志',
        prop: 'mulPracFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'MUL_PRAC_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '主执业机构编号', prop: 'mainPracinsNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '主执业机构名称', prop: 'mainPracinsName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '主执业机构地址', prop: 'mainPracinsAddr', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '离职时间',
        prop: 'nempTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '拥有处方权标志',
        prop: 'rxPermFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'RX_PERM_FLAG') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医师卫生技术人员专业技术职务',
        prop: 'drProTechDuty',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'DR_PRO_TECH_DUTY') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建经办机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '版本号', prop: 'ver', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const drInfoBRules = {
      drCode: [{ required: true, message: '请填写医师代码', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      psnItro: [{ required: true, message: '请填写个人能力简介', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      drPracType: [{ required: true, message: '请选择医师执业类别', trigger: 'change' }],
      drPracScpCode: [{ required: true, message: '请选择医师执业范围代码', trigger: 'change' }],
      pracRegn: [{ required: true, message: '请填写执业地区', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      mulPracFlag: [{ required: true, message: '请选择多点执业标志', trigger: 'change' }],
      mainPracinsNo: [{ required: true, message: '请填写主执业机构编号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      mainPracinsName: [{ required: true, message: '请填写主执业机构名称', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      mainPracinsAddr: [{ required: true, message: '请填写主执业机构地址', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      nempTime: [{ required: true, type: 'date', message: '请选择离职时间', trigger: 'change' }],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      rxPermFlag: [{ required: true, message: '请选择拥有处方权标志', trigger: 'change' }],
      drProTechDuty: [{ required: true, message: '请选择医师卫生技术人员专业技术职务', trigger: 'change' }],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      ver: [{ required: true, message: '请填写版本号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      drInfoBTabColDefs: drInfoBColDefs,
      drInfoBList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      drInfoBFormDisabled: false,
      drInfoBFormEditDisabled: false,
      drInfoBFormQuery: new DrInfoBQueryClass(),
      drInfoBFormEdit: new DrInfoBClass(),
      drInfoBEditFormRules: drInfoBRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
