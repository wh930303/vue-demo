<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
            :model="psnInfoBFormQuery"
            label-position="right"
            label-width="120px"
            size="medium"
            @submit.native.prevent
          >
            <hsa-row collapseBtn>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                    v-model="psnInfoBFormQuery.psnNo"
                    placeholder="请输入人员编号"
                    maxlength="20"
                    @blur="blurPsnInfoB"
                    :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                    v-model="psnInfoBFormQuery.psnName"
                    placeholder="请输入人员姓名"
                    maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                    v-model="psnInfoBFormQuery.brdy"
                    placeholder="请输入出生日期"

                    style="width: 100%"
                    type="date"
                    format="yyyy 年 MM 月 dd 日"
                    value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                    v-model="psnInfoBFormQuery.certNo"
                    placeholder="请输入证件号码"
                    maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                    v-model="psnInfoBFormQuery.tel"
                    placeholder="请输入联系电话"
                    maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                    v-model="psnInfoBFormQuery.naty"
                    placeholder="请输入民族"
                    maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                    v-model="psnInfoBFormQuery.addr"
                    placeholder="请输入联系地址"
                    maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                    v-model="psnInfoBFormQuery.gend"
                    placeholder="请输入性别"
                    maxlength="1"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                    v-model="psnInfoBFormQuery.insutype"
                    placeholder="请输入险种"
                    maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                    v-model="psnInfoBFormQuery.empName"
                    placeholder="请输入单位名称"
                    maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                    v-model="psnInfoBFormQuery.insuOptins"
                    placeholder="请输入参保所属机构"
                    maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                    v-model="psnInfoBFormQuery.empCode"
                    placeholder="请输入单位编码"
                    maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
              <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
              <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
              <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryReflAppyD"
                  >查询</el-button
                >
              </template>
            </hsa-row>
          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success" @click="showAddDialog"
              >增加
            </el-button>
          </template>

          <ncp-table
            :columnDefs="reflAppyDTabColDefs"
            :data="reflAppyDList"
            :enablePagination="true"
            :paginationConfig="paginationConfig"
            :useExternalPagination="true"
            @paginationConfigChange="queryReflAppyD"
            v-loading="tableLoading"
            :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
      title="转院申请信息"
      :visible.sync="editDialogVisible"
      width="80%"
      :close-on-click-modal="false"
      class="hsa-dialog"
    >
      <el-form
        :model="reflAppyDFormEdit"
        label-position="right"
        label-width="120px"
        size="medium"
        :rules="reflAppyDEditFormRules"
        ref="reflAppyDEditForm"
        @submit.native.prevent
      >
        <hsa-row>
          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="reflAppyDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种" prop="insutype">
            <el-input
                v-model="reflAppyDFormEdit.insutype"
                placeholder="请输入险种"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="reflAppyDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="reflAppyDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件类型" prop="certType">
            <el-input
                v-model="reflAppyDFormEdit.certType"
                placeholder="请输入证件类型"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certno">
            <el-input
                v-model="reflAppyDFormEdit.certno"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员姓名" prop="psnName">
            <el-input
                v-model="reflAppyDFormEdit.psnName"
                placeholder="请输入人员姓名"
                maxlength="50"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-input
                v-model="reflAppyDFormEdit.gend"
                placeholder="请输入性别"
                maxlength="1"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="reflAppyDFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系电话" prop="tel">
            <el-input
                v-model="reflAppyDFormEdit.tel"
                placeholder="请输入联系电话"
                maxlength="50"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系地址" prop="addr">
            <el-input
                v-model="reflAppyDFormEdit.addr"
                placeholder="请输入联系地址"
                maxlength="200"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保所属机构" prop="insuOptins">
            <el-input
                v-model="reflAppyDFormEdit.insuOptins"
                placeholder="请输入参保所属机构"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="reflAppyDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="reflAppyDFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="定点机构编号" prop="fixmedinsCode">
              <el-input
                v-model="reflAppyDFormEdit.fixmedinsCode"
                placeholder="请输入定点机构编号"
                maxlength="30"
                @blur="queryMedinsInfoB"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="定点机构名称" prop="fixmedinsName">
              <el-input
                v-model="reflAppyDFormEdit.fixmedinsName"
                placeholder="请输入定点机构名称"
                maxlength="200"

              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <!-- <el-form-item label="医药机构等级" prop="medinsLv">
            <el-input
                v-model="reflAppyDFormEdit.medinsLv"
                placeholder="请输入医药机构等级"
                maxlength="6"

            ></el-input>
          </el-form-item> -->
            <el-form-item label="医药机构等级">
              <el-select
                v-model="reflAppyDFormEdit.medinsLv"
                type="MEDINSLV"

                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="定点归属机构" prop="fixmedinsPoolarea">
              <el-input
                v-model="reflAppyDFormEdit.fixmedinsPoolarea"
                placeholder="请输入定点归属机构"
                maxlength="6"

              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="诊断代码" prop="diseCode">
              <el-input
                v-model="reflAppyDFormEdit.diseCode"
                placeholder="请输入诊断代码"
                maxlength="20"
                @blur="queryDiseListB"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="诊断名称" prop="diseName">
              <el-input
                v-model="reflAppyDFormEdit.diseName"
                placeholder="请输入诊断名称"
                maxlength="300"

              ></el-input>
            </el-form-item>
          </hsa-col>
          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医嘱" prop="drord">
            <el-input
                v-model="reflAppyDFormEdit.drord"
                placeholder="请输入医嘱"
                maxlength="2000"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
         -->
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="转往医院编号" prop="reflinMedinsNo">
              <el-input
                v-model="reflAppyDFormEdit.reflinMedinsNo"
                placeholder="请输入医院编号"
                maxlength="30"
                @blur="queryReflinMedinsInfoB"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="转往医院名称" prop="reflinMedinsName">
              <el-input
                v-model="reflAppyDFormEdit.reflinMedinsName"
                placeholder="请输入转往医院名称"
                maxlength="200"

              ></el-input>
            </el-form-item>
          </hsa-col>
          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="转住医院等级" prop="turnaroundHospLv">
            <el-input
                v-model="reflAppyDFormEdit.turnaroundHospLv"
                placeholder="请输入转住医院等级"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
         -->
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="转院日期" prop="reflDate">
              <el-date-picker
                v-model="reflAppyDFormEdit.reflDate"
                placeholder="请输入转院日期"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="开始日期" prop="begndate">
              <el-date-picker
                v-model="reflAppyDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="结束日期" prop="enddate">
              <el-date-picker
                v-model="reflAppyDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="转院原因" prop="reflRea">
              <el-input
                v-model="reflAppyDFormEdit.reflRea"
                placeholder="请输入转院原因"
                maxlength="2000"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="疾病病情描述" prop="diseCondDscr">
              <el-input
                v-model="reflAppyDFormEdit.diseCondDscr"
                placeholder="请输入疾病病情描述"
                maxlength="1000"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="转院结算标志" prop="reflSetlFlag">
              <el-select
                v-model="reflAppyDFormEdit.reflSetlFlag"
                type="REFL_SETL_FLAG"
                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="异地标志" prop="outFlag">
              <el-select
                v-model="reflAppyDFormEdit.outFlag"
                type="OUT_FLAG"
                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="代办人姓名" prop="agntName">
              <el-input
                v-model="reflAppyDFormEdit.agntName"
                placeholder="请输入代办人姓名"
                maxlength="50"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="代办人证件类型" prop="agntCertType">
              <el-input
                v-model="reflAppyDFormEdit.agntCertType"
                placeholder="请输入代办人证件类型"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="代办人证件号码" prop="agntCertno">
              <el-input
                v-model="reflAppyDFormEdit.agntCertno"
                placeholder="请输入代办人证件号码"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="代办人联系方式" prop="agntTel">
              <el-input
                v-model="reflAppyDFormEdit.agntTel"
                placeholder="请输入代办人联系方式"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="代办人联系地址" prop="agntAddr">
              <el-input
                v-model="reflAppyDFormEdit.agntAddr"
                placeholder="请输入代办人联系地址"
                maxlength="200"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="申报来源" prop="dclaSouc">
              <el-input
                v-model="reflAppyDFormEdit.dclaSouc"
                placeholder="请输入申报来源"
                maxlength="6"

              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="备注" prop="memo">
              <el-input
                v-model="reflAppyDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="reflAppyDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="有效标志" prop="valiFlag">
              <el-select
                v-model="reflAppyDFormEdit.valiFlag"
                type="VALI_FLAG"

                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="更新时间" prop="updtTime">
              <el-date-picker
                v-model="reflAppyDFormEdit.updtTime"
                placeholder="请输入更新时间"

                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人关系" prop="agntRlts">
            <el-select v-model="reflAppyDFormEdit.agntRlts" type="AGNT_RLTS" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="转诊前就诊事件ID" prop="reflOldMdtrtId">
            <el-input
                v-model="reflAppyDFormEdit.reflOldMdtrtId"
                placeholder="请输入转诊前就诊事件ID"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结算事件ID" prop="setlId">
            <el-input
                v-model="reflAppyDFormEdit.setlId"
                placeholder="请输入结算事件ID"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="就诊事件ID" prop="mdtrtEvtId">
            <el-input
                v-model="reflAppyDFormEdit.mdtrtEvtId"
                placeholder="请输入就诊事件ID"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="reflAppyDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="reflAppyDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="reflAppyDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="reflAppyDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="reflAppyDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="reflAppyDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="reflAppyDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="reflAppyDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="reflAppyDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="reflAppyDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="30"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="reflAppyDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="reflAppyDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="reflAppyDEditCancel" size="medium">取 消</el-button>
        <el-button
          type="primary"
          @click="reflAppyDEditConfirm"
          size="medium"
          :loading="buttonLoading"
          :disabled="buttonLoading"
          >保 存</el-button
        >
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './refl-appy-d-mngr.service'
import ReflAppyDClass from '@/modules/demo/class/refl-appy-d-mngr.class'
import ReflAppyDQueryClass from '@/modules/demo/class/refl-appy-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
import DiseListBQueryClass from '@/modules/demo/class/dise-list-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.reflAppyDFormQuery = new ReflAppyDQueryClass()
      this.reflAppyDFormEdit = new ReflAppyDClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.diseListBFormQuery = new DiseListBQueryClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.reflAppyDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.reflAppyDFormDisabled = false
      this.reflAppyDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          this.psnInfoBFormQuery = new PsnInfoBQueryClass()
          this.psnInfoBFormQuery.psnNo = psnNo
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(
            this.psnInfoBFormQuery
          )
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    async checkIsPass () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInsuDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
      const psnInsuDResult = await psnInfoBService.getPsnInsuD(
        this.psnInsuDFormQuery
      )
      // 已经参保且参保状正常
      if (psnInsuDResult.length > 0 && psnInsuDResult[0].psnInsuStas == '1') {
        this.psnInsuDFormQuery = psnInsuDResult[0]
        return true
      } else {
        return false
      }
    },
    // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
    checkBegnDate () {
      const begnDate = this.reflAppyDFormEdit.begndate
      const endDate = this.reflAppyDFormEdit.enddate
      if (
        begnDate != null &&
        begnDate != '' &&
        endDate != null &&
        endDate != ''
      ) {
        if (begnDate > endDate) {
          this.$message.error('开始日期不得晚于结束日期!')
          return false
        }
      }
      return true
    },
    // 转出医院与转往医院不可以为同一家医院
    checkMedins () {
      // 转出医院编号
      const fixmedinsCode = this.reflAppyDFormEdit.fixmedinsCode
      // 转往医院编号
      const reflinMedinsNo = this.reflAppyDFormEdit.reflinMedinsNo
      if (
        fixmedinsCode != null &&
        fixmedinsCode != '' &&
        reflinMedinsNo != null &&
        reflinMedinsNo != ''
      ) {
        if (fixmedinsCode == reflinMedinsNo) {
          this.$message.error('转出医院与转往医院不可以为同一家医院!')
          return false
        }
      }
      return true
    },
    // 查询开始时间和结束时间相交的信息
    async checkOverlapping () {
      try {
        this.reflAppyDFormQuery = new ReflAppyDQueryClass()
        this.reflAppyDFormQuery.rid = this.reflAppyDFormEdit.rid
        this.reflAppyDFormQuery.psnNo = this.reflAppyDFormEdit.psnNo
        if (
          this.reflAppyDFormEdit.begndate != null &&
          this.reflAppyDFormEdit.begndate != ''
        ) {
          this.reflAppyDFormQuery.begndate = new Date(
            this.reflAppyDFormEdit.begndate
          ).getTime()
        }

        if (
          this.reflAppyDFormEdit.enddate != null &&
          this.reflAppyDFormEdit.enddate != ''
        ) {
          this.reflAppyDFormQuery.enddate = new Date(
            this.reflAppyDFormEdit.enddate
          ).getTime()
        } else {
          this.reflAppyDFormQuery.enddate = new Date(
            this.reflAppyDFormEdit.begndate
          )
          this.reflAppyDFormQuery.enddate.setDate(
            this.reflAppyDFormQuery.enddate.getDate() + 1
          )
          this.reflAppyDFormQuery.enddate = new Date(
            this.reflAppyDFormQuery.enddate
          ).getTime()
        }
        const reflAppyDResult = await Service.resources.queryOverlapping(
          this.reflAppyDFormQuery
        )
        if (reflAppyDResult.length == '0') {
          return true
        } else {
          this.$message.error(
            '与其他登记信息的开始日期和结束日期不能交叉、重叠!'
          )
          return false
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.reflAppyDFormQuery = new ReflAppyDQueryClass()
      }
    },
    // 查询医药机构信息
    async queryMedinsInfoB () {
      this.medinsInfoBFormQuery.medinsNo = this.reflAppyDFormEdit.fixmedinsCode
      if (
        this.medinsInfoBFormQuery.medinsNo != null &&
        this.medinsInfoBFormQuery.medinsNo != ''
      ) {
        const result = await psnInfoBService.getMedinsInfoB(
          this.medinsInfoBFormQuery
        )
        // 存在医药机构信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医药机构名称
          this.reflAppyDFormEdit.fixmedinsName = result[0].medinsName
          // 医药机构等级
          this.reflAppyDFormEdit.medinsLv = result[0].medinslv
          // 定点归属机构
          this.reflAppyDFormEdit.fixmedinsPoolarea = result[0].poolarea
        } else {
          this.reflAppyDFormEdit.fixmedinsName = ''
          this.reflAppyDFormEdit.medinsLv = ''
          this.reflAppyDFormEdit.fixmedinsPoolarea = ''
          this.$message.error('该医药机构不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.reflAppyDFormEdit.fixmedinsName = ''
        this.reflAppyDFormEdit.medinsLv = ''
        this.reflAppyDFormEdit.fixmedinsPoolarea = ''
      }
    },
    // 查询转往医药机构信息
    async queryReflinMedinsInfoB () {
      this.medinsInfoBFormQuery.medinsNo = this.reflAppyDFormEdit.reflinMedinsNo
      if (
        this.medinsInfoBFormQuery.medinsNo != null &&
        this.medinsInfoBFormQuery.medinsNo != ''
      ) {
        const result = await psnInfoBService.getMedinsInfoB(
          this.medinsInfoBFormQuery
        )
        // 存在医药机构信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医药机构名称
          this.reflAppyDFormEdit.reflinMedinsName = result[0].medinsName
        } else {
          this.reflAppyDFormEdit.reflinMedinsName = ''
          this.$message.error('该医药机构不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.reflAppyDFormEdit.reflinMedinsName = ''
      }
    },
    // 查询疾病诊断目录信息
    async queryDiseListB () {
      this.diseListBFormQuery.diseCode = this.reflAppyDFormEdit.diseCode
      if (
        this.diseListBFormQuery.diseCode != null &&
        this.diseListBFormQuery.diseCode != ''
      ) {
        const result = await psnInfoBService.getDiseListB(
          this.diseListBFormQuery
        )
        // 存在疾病诊断目录信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 诊断名称
          this.reflAppyDFormEdit.diseName = result[0].diseName
        } else {
          this.reflAppyDFormEdit.diseName = ''
          this.$message.error('该诊断目录不存在或无效！')
        }
      } else {
        this.reflAppyDFormEdit.diseName = ''
      }
    },
    // 异步调用，一律采用 async/await 语法
    async queryReflAppyD () {
      try {
        this.reflAppyDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
        this.tableLoading = true
        const reflAppyDResult = await Service.resources.getByPage(
          this.reflAppyDFormQuery,
          this.paginationConfig
        )
        if (reflAppyDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.reflAppyDList = []
        } else {
          this.reflAppyDList = reflAppyDResult.result
          this.paginationConfig.pageNumber = reflAppyDResult.pageNumber
          this.paginationConfig.pageSize = reflAppyDResult.pageSize
          this.paginationConfig.total = reflAppyDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async saveBeforeCheck () {
      // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
      const flag1 = this.checkBegnDate()
      if (flag1) {
        // 转出医院不能和转入医院相同
        const flag2 = this.checkMedins()
        if (flag2) {
          // 查询开始时间和结束时间相交的信息
          const flag3 = await this.checkOverlapping()
          if (flag3) {
            return true
          }
        }
      }
      return false
    },
    async addReflAppyD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.post(this.reflAppyDFormEdit)
          this.$message.info('新增成功！')
          this.editDialogVisible = false
          this.queryReflAppyD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateReflAppyD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.put(this.reflAppyDFormEdit)
          this.$message.info('更新成功！')
          this.editDialogVisible = false
          this.queryReflAppyD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteReflAppyD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryReflAppyD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetReflAppyDEditForm () {
      this.$refs.reflAppyDEditForm.resetFields()
    },
    reflAppyDEditCancel () {
      this.resetReflAppyDEditForm()
      this.editDialogVisible = false
    },
    async showAddDialog () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo == null || psnNo == '') {
        this.$message.info('请输入人员编号！')
        return
      }
      const flag = await this.checkIsPass()
      if (!flag) {
        this.$message.info('该用户未参保或参保状态异常！')
        return
      }
      this.reflAppyDFormEdit = new ReflAppyDClass()
      this.operateType = 'add'
      // 添加默认信息
      this.reflAppyDFormEdit.dclaSouc = '中心经办系统'
      this.reflAppyDFormEdit.begndate = new Date()
      this.reflAppyDFormEdit.updtTime = new Date()
      this.reflAppyDFormEdit.valiFlag = '1'

      // 添加个人基本信息
      this.reflAppyDFormEdit.psnNo = this.psnInfoBFormQuery.psnNo
      this.reflAppyDFormEdit.certno = this.psnInfoBFormQuery.certNo
      this.reflAppyDFormEdit.psnName = this.psnInfoBFormQuery.psnName
      this.reflAppyDFormEdit.gend = this.psnInfoBFormQuery.gend
      this.reflAppyDFormEdit.brdy = this.psnInfoBFormQuery.brdy
      this.reflAppyDFormEdit.tel = this.psnInfoBFormQuery.tel
      this.reflAppyDFormEdit.addr = this.psnInfoBFormQuery.addr
      this.reflAppyDFormEdit.insuOptins = this.psnInfoBFormQuery.insuOptins
      this.reflAppyDFormEdit.empNo = this.psnInfoBFormQuery.empCode
      this.reflAppyDFormEdit.empName = this.psnInfoBFormQuery.empName
      this.reflAppyDFormEdit.certType = '0' // 身份证
      // 添加人员参保关系ID
      this.reflAppyDFormEdit.psnInsuRltsId = this.psnInsuDFormQuery.psnInsuRltsId

      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.reflAppyDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.reflAppyDFormEdit = Object.assign({}, row)
      // 判断结束时间（修改登记信息时，如果结束日期为空，需要置为开始日期加一年）
      if (
        this.reflAppyDFormEdit.enddate == null ||
        this.reflAppyDFormEdit.enddate == ''
      ) {
        // this.reflAppyDFormEdit.begndate
        this.reflAppyDFormEdit.enddate = new Date(
          this.reflAppyDFormEdit.begndate
        )
        this.reflAppyDFormEdit.enddate.setFullYear(
          this.reflAppyDFormEdit.enddate.getFullYear() + 1
        )
      }
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.reflAppyDEditForm.clearValidate()
      })
    },
    reflAppyDEditConfirm () {
      this.$refs.reflAppyDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateReflAppyD()
          } else {
            this.addReflAppyD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm('是否刪除?', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'info'
      }).then(() => {
        this.deleteReflAppyD(row.trtDclaDetlSn)
      })
    }
  },
  data () {
    const reflAppyDColDefs = [
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '险种',
        prop: 'insutype',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '申报来源',
        prop: 'dclaSouc',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员编号',
        prop: 'psnNo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员参保关系ID',
        prop: 'psnInsuRltsId',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '证件类型',
        prop: 'certType',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'CERT_TYPE')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '证件号码',
        prop: 'certno',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员姓名',
        prop: 'psnName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '性别',
        prop: 'gend',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '联系电话',
        prop: 'tel',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '联系地址',
        prop: 'addr',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '参保所属机构',
        prop: 'insuOptins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '单位编号',
        prop: 'empNo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '单位名称',
        prop: 'empName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '定点机构编号',
        prop: 'fixmedinsCode',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '定点机构名称',
        prop: 'fixmedinsName',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医药机构等级',
        prop: 'medinslv',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'MEDINSLV')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '定点归属机构',
        prop: 'fixmedinsPoolarea',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '诊断代码',
        prop: 'diseCode',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '诊断名称',
        prop: 'diseName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医嘱',
        prop: 'drord',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '疾病病情描述',
        prop: 'diseCondDscr',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转往医院编号',
        prop: 'reflinMedinsNo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转往医院名称',
        prop: 'reflinMedinsName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转住医院等级',
        prop: 'turnaroundHospLv',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '异地标志',
        prop: 'outFlag',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'OUT_FLAG')
            }
          }
        ]
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转院日期',
        prop: 'reflDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转院原因',
        prop: 'reflRea',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转院结算标志',
        prop: 'reflSetlFlag',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'REFL_SETL_FLAG')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人姓名',
        prop: 'agntName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人证件类型',
        prop: 'agntCertType',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人证件号码',
        prop: 'agntCertno',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人联系方式',
        prop: 'agntTel',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人联系地址',
        prop: 'agntAddr',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人关系',
        prop: 'agntRlts',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'AGNT_RLTS')
            }
          }
        ]
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '转诊前就诊事件ID',
        prop: 'reflOldMdtrtId',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结算事件ID',
        prop: 'setlId',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '就诊事件ID',
        prop: 'mdtrtEvtId',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'VALI_FLAG')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '备注',
        prop: 'memo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '唯一记录号',
        prop: 'rid',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建人',
        prop: 'crter',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建人姓名',
        prop: 'crterName',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建机构',
        prop: 'crteOptins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办人',
        prop: 'opter',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办人姓名',
        prop: 'opterName',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办机构',
        prop: 'optins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '统筹区',
        prop: 'poolarea',
        width: '120px'
      },
      {
        label: '操作',
        type: 'Button',
        buttonGroup: [
          {
            type: 'primary',
            icon: 'el-icon-edit',
            size: 'mini',
            handle: (row) => this.showEditDialog(row)
          },
          {
            type: 'danger',
            icon: 'el-icon-delete',
            size: 'mini',
            handle: (row) => this.deleteRow(row)
          }
        ],
        width: '150px',
        fixed: 'right'
      }
    ]
    const reflAppyDRules = {
      insutype: [
        { required: true, message: '请填写险种', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      dclaSouc: [
        { required: true, message: '请填写申报来源', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnNo: [
        { required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [
        { required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      certType: [
        { required: true, message: '请填写证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      certno: [
        { required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnName: [
        { required: true, message: '请填写人员姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [
        { required: true, message: '请填写性别', trigger: 'blur' },
        { max: 1, message: '长度不能超过 1 个字符', trigger: 'blur' }
      ],
      brdy: [
        {
          required: true,
          type: 'date',
          message: '请选择出生日期',
          trigger: 'change'
        }
      ],
      tel: [
        { required: true, message: '请填写联系电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      addr: [
        { required: true, message: '请填写联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      insuOptins: [
        { required: true, message: '请填写参保所属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empNo: [
        { required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empName: [
        { required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      fixmedinsCode: [
        { required: true, message: '请填写定点机构编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsName: [
        { required: false, message: '请填写定点机构名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      // medinsLv: [{  required:false, message: '请填写医药机构等级', trigger: 'blur' },
      //   {  max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      // ],
      medinslv: [
        { required: false, message: '请选择医疗机构等级', trigger: 'change' }
      ],
      fixmedinsPoolarea: [
        { required: false, message: '请填写定点归属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      diseCode: [
        { required: true, message: '请填写诊断代码', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      diseName: [
        { required: false, message: '请填写诊断名称', trigger: 'blur' },
        { max: 300, message: '长度不能超过 300 个字符', trigger: 'blur' }
      ],
      drord: [
        { required: true, message: '请填写医嘱', trigger: 'blur' },
        { max: 2000, message: '长度不能超过 2000 个字符', trigger: 'blur' }
      ],
      diseCondDscr: [
        { required: true, message: '请填写疾病病情描述', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      reflinMedinsNo: [
        { required: true, message: '请填写转往医院编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      reflinMedinsName: [
        { required: false, message: '请填写转往医院名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      turnaroundHospLv: [
        { required: true, message: '请填写转住医院等级', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      outFlag: [
        { required: false, message: '请选择异地标志', trigger: 'change' }
      ],
      reflDate: [
        {
          required: false,
          type: 'date',
          message: '请选择转院日期',
          trigger: 'change'
        }
      ],
      reflRea: [
        { required: false, message: '请填写转院原因', trigger: 'blur' },
        { max: 2000, message: '长度不能超过 2000 个字符', trigger: 'blur' }
      ],
      reflSetlFlag: [
        { required: false, message: '请选择转院结算标志', trigger: 'change' }
      ],
      agntName: [
        { required: false, message: '请填写代办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      agntCertType: [
        { required: false, message: '请填写代办人证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      agntCertno: [
        { required: false, message: '请填写代办人证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntTel: [
        { required: false, message: '请填写代办人联系方式', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntAddr: [
        { required: false, message: '请填写代办人联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      agntRlts: [
        { required: true, message: '请选择代办人关系', trigger: 'change' }
      ],
      begndate: [
        {
          required: true,
          type: 'date',
          message: '请选择开始日期',
          trigger: 'change'
        }
      ],
      enddate: [
        {
          required: false,
          type: 'date',
          message: '请选择结束日期',
          trigger: 'change'
        }
      ],
      reflOldMdtrtId: [
        { required: true, message: '请填写转诊前就诊事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      setlId: [
        { required: true, message: '请填写结算事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      mdtrtEvtId: [
        { required: true, message: '请填写就诊事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      valiFlag: [
        { required: true, message: '请选择有效标志', trigger: 'change' }
      ],
      memo: [
        { required: false, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      rid: [
        { required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [
        {
          required: true,
          type: 'date',
          message: '请选择更新时间',
          trigger: 'change'
        }
      ],
      crter: [
        { required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [
        { required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [
        {
          required: true,
          type: 'date',
          message: '请选择创建时间',
          trigger: 'change'
        }
      ],
      crteOptins: [
        { required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opter: [
        { required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opterName: [
        { required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [
        {
          required: true,
          type: 'date',
          message: '请选择经办时间',
          trigger: 'change'
        }
      ],
      optins: [
        { required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      poolarea: [
        { required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      reflAppyDTabColDefs: reflAppyDColDefs,
      reflAppyDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      reflAppyDFormDisabled: false,
      reflAppyDFormEditDisabled: false,
      reflAppyDFormQuery: new ReflAppyDQueryClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      diseListBFormQuery: new DiseListBQueryClass(),
      reflAppyDFormEdit: new ReflAppyDClass(),
      reflAppyDEditFormRules: reflAppyDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
