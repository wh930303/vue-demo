/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/

import NCP from '@ncp-web/core'
//import { codeFilter, tableDataFilter } from '@/common/filters/index'

// 业务服务上下文，必需设置为 process.env.VUE_APP_BASE_URL
const context = process.env.VUE_APP_BASE_URL

// 针对特定资源，创建 axios 实例
const resourcesConst = NCP.createAxios({
  baseURL: context + '/web/demo/reflAppyD',
  headers: { businessId: 'reflAppyDbusinessId' }
})

// 针对特定资源，创建资源访问对象
// 对象变量应同资源同名
const resources = {
  // 好用的POS请求示例
  // return empInsuMergeRes.post('/updateEmpMergeInfo', formEdit, {
  //   headers: { 'Content-Type': 'application/json' }
  // })
  
  //查询
  get(reflAppyDQuery) {
    // 发送请求
    return resourcesConst.request({
      method: 'GET',
      params: reflAppyDQuery,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  // 查询开始时间和结束时间相交的信息
  queryOverlapping(reflAppyDQuery) {
    // 发送请求
    return resourcesConst.request({
      url: '/queryOverlapping',
      method: 'GET',
      params: Object.assign({},reflAppyDQuery),
      headers: { 'Content-Type': 'application/json' }
    })
  },
  // 分页查询
  getByPage(reflAppyDQuery, pageConfig) {
    // 发送请求
    return resourcesConst.request({
      url: '/page',
      method: 'GET',
      params: Object.assign({},pageConfig,reflAppyDQuery),
      headers: { 'Content-Type': 'application/json' }
    })
  },
  post(reflAppyD) {
    return resourcesConst.request({
      method: 'POST',
      data: reflAppyD,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  put(reflAppyD) {
    return resourcesConst.request({
      method: 'PUT',
      data: reflAppyD,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  delete(id) {
    return resourcesConst.request({
      url: '/' + id,
      method: 'DELETE'
    })
  }
}

export default {
  resources
}

