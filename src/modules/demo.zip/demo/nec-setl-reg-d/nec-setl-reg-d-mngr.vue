<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      @blur="blurPsnInfoB"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                      v-model="psnInfoBFormQuery.psnName"
                      placeholder="请输入人员姓名"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                      v-model="psnInfoBFormQuery.brdy"
                      placeholder="请输入出生日期"

                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                      v-model="psnInfoBFormQuery.certNo"
                      placeholder="请输入证件号码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="psnInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                      v-model="psnInfoBFormQuery.naty"
                      placeholder="请输入民族"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                      v-model="psnInfoBFormQuery.addr"
                      placeholder="请输入联系地址"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                      v-model="psnInfoBFormQuery.gend"
                      placeholder="请输入性别"
                      maxlength="1"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                      v-model="psnInfoBFormQuery.insutype"
                      placeholder="请输入险种"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="psnInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="psnInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                      v-model="psnInfoBFormQuery.empCode"
                      placeholder="请输入单位编码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryNecSetlRegD">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="necSetlRegDTabColDefs"
              :data="necSetlRegDList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryNecSetlRegD"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="无医保凭证结算备案登记信息"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="necSetlRegDFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="necSetlRegDEditFormRules"
           ref="necSetlRegDEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="necSetlRegDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="就诊事件ID" prop="mdtrtEvtId">
            <el-input
                v-model="necSetlRegDFormEdit.mdtrtEvtId"
                placeholder="请输入就诊事件ID"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结算事件ID" prop="setlId">
            <el-input
                v-model="necSetlRegDFormEdit.setlId"
                placeholder="请输入结算事件ID"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种" prop="insutype">
            <el-input
                v-model="necSetlRegDFormEdit.insutype"
                placeholder="请输入险种"
                maxlength="6"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="necSetlRegDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="necSetlRegDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员证件类型" prop="psnCertType">
            <el-select v-model="necSetlRegDFormEdit.psnCertType" type="PSN_CERT_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certno">
            <el-input
                v-model="necSetlRegDFormEdit.certno"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员姓名" prop="psnName">
            <el-input
                v-model="necSetlRegDFormEdit.psnName"
                placeholder="请输入人员姓名"
                maxlength="50"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-select v-model="necSetlRegDFormEdit.gend" type="GEND" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="年龄" prop="age">
            <el-input
                v-model="necSetlRegDFormEdit.age"
                placeholder="请输入年龄"
                maxlength="${field.columnLength}"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="necSetlRegDFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="necSetlRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保机构行政区划" prop="insuOptins">
            <el-input
                v-model="necSetlRegDFormEdit.insuOptins"
                placeholder="请输入参保机构行政区划"
                maxlength="6"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="necSetlRegDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="necSetlRegDFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点机构编号" prop="fixmedinsCode">
            <el-input
                v-model="necSetlRegDFormEdit.fixmedinsCode"
                placeholder="请输入定点机构编号"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
                @blur="queryMedinsInfoB"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点机构名称" prop="fixmedinsName">
            <el-input
                v-model="necSetlRegDFormEdit.fixmedinsName"
                placeholder="请输入定点机构名称"
                maxlength="200"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="定点归属机构" prop="fixmedinsPoolarea">
            <el-input
                v-model="necSetlRegDFormEdit.fixmedinsPoolarea"
                placeholder="请输入定点归属机构"
                maxlength="6"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="申请理由" prop="appyRea">
            <el-input
                v-model="necSetlRegDFormEdit.appyRea"
                placeholder="请输入申请理由"
                maxlength="1000"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗类别" prop="medType">
            <el-input
                v-model="necSetlRegDFormEdit.medType"
                placeholder="请输入医疗类别"
                maxlength="6"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医疗费总额" prop="medfeeSumamt">
            <el-input
                v-model="necSetlRegDFormEdit.medfeeSumamt"
                placeholder="请输入医疗费总额"
                maxlength="${field.columnLength}"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="住院号" prop="mdtrtsn">
            <el-input
                v-model="necSetlRegDFormEdit.mdtrtsn"
                placeholder="请输入住院号"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="入院床位" prop="admBed">
            <el-input
                v-model="necSetlRegDFormEdit.admBed"
                placeholder="请输入入院床位"
                maxlength="30"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="入院科室" prop="admDept">
            <el-input
                v-model="necSetlRegDFormEdit.admDept"
                placeholder="请输入入院科室"
                maxlength="50"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="病区床位" prop="wardareaBed">
            <el-input
                v-model="necSetlRegDFormEdit.wardareaBed"
                placeholder="请输入病区床位"
                maxlength="50"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始日期" prop="begndate">
            <el-date-picker
                v-model="necSetlRegDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="necSetlRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束日期" prop="enddate">
            <el-date-picker
                v-model="necSetlRegDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="necSetlRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="备注" prop="memo">
            <el-input
                v-model="necSetlRegDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标识" prop="valiFlag">
            <el-select v-model="necSetlRegDFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto" ></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="necSetlRegDFormEdit.updtTime"
                placeholder="请输入更新时间"

                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>

        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="necSetlRegDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="necSetlRegDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="20"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="necSetlRegDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="necSetlRegDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="necSetlRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="necSetlRegDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="20"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="necSetlRegDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="necSetlRegDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="necSetlRegDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="necSetlRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="necSetlRegDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="necSetlRegDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="necSetlRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="necSetlRegDEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="necSetlRegDEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './nec-setl-reg-d-mngr.service'
import NecSetlRegDClass from '@/modules/demo/class/nec-setl-reg-d-mngr.class'
import NecSetlRegDQueryClass from '@/modules/demo/class/nec-setl-reg-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.necSetlRegDFormQuery = new NecSetlRegDQueryClass()
      this.necSetlRegDFormEdit = new NecSetlRegDClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.necSetlRegDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.necSetlRegDFormDisabled = false
      this.necSetlRegDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          this.psnInfoBFormQuery = new PsnInfoBQueryClass()
          this.psnInfoBFormQuery.psnNo = psnNo
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(this.psnInfoBFormQuery)
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    async checkIsPass () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInsuDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
      const psnInsuDResult = await psnInfoBService.getPsnInsuD(this.psnInsuDFormQuery)
      // 已经参保且参保状正常
      if (psnInsuDResult.length > 0 && psnInsuDResult[0].psnInsuStas == '1') {
        this.psnInsuDFormQuery = psnInsuDResult[0]
        return true
      } else {
        return false
      }
    },
    // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
    checkBegnDate () {
      const begnDate = this.necSetlRegDFormEdit.begndate
      const endDate = this.necSetlRegDFormEdit.enddate
      if (begnDate != null && begnDate != '' && endDate != null && endDate != '') {
        if (begnDate > endDate) {
          this.$message.error('开始日期不得晚于结束日期!')
          return false
        }
      }
      return true
    },
    // 查询开始时间和结束时间相交的信息
    async checkOverlapping () {
      try {
        this.necSetlRegDFormQuery = new NecSetlRegDQueryClass()
        this.necSetlRegDFormQuery.rid = this.necSetlRegDFormEdit.rid
        this.necSetlRegDFormQuery.psnNo = this.necSetlRegDFormEdit.psnNo
        if (this.necSetlRegDFormEdit.begndate != null && this.necSetlRegDFormEdit.begndate != '') {
          this.necSetlRegDFormQuery.begndate = new Date(this.necSetlRegDFormEdit.begndate).getTime()
        }

        if (this.necSetlRegDFormEdit.enddate != null && this.necSetlRegDFormEdit.enddate != '') {
          this.necSetlRegDFormQuery.enddate = new Date(this.necSetlRegDFormEdit.enddate).getTime()
        } else {
          this.necSetlRegDFormQuery.enddate = new Date(this.necSetlRegDFormEdit.begndate)
          this.necSetlRegDFormQuery.enddate.setDate(this.necSetlRegDFormQuery.enddate.getDate() + 1)
          this.necSetlRegDFormQuery.enddate = new Date(this.necSetlRegDFormQuery.enddate).getTime()
        }
        const reflAppyDResult = await Service.resources.queryOverlapping(this.necSetlRegDFormQuery)
        if (reflAppyDResult.length == '0') {
          return true
        } else {
          this.$message.error('与其他登记信息的开始日期和结束日期不能交叉、重叠!')
          return false
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.necSetlRegDFormQuery = new NecSetlRegDQueryClass()
      }
    },
    // 查询医药机构信息
    async queryMedinsInfoB () {
      this.medinsInfoBFormQuery.medinsNo = this.necSetlRegDFormEdit.fixmedinsCode
      if (this.medinsInfoBFormQuery.medinsNo != null && this.medinsInfoBFormQuery.medinsNo != '') {
        const result = await psnInfoBService.getMedinsInfoB(this.medinsInfoBFormQuery)
        // 存在医药机构信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医药机构名称
          this.necSetlRegDFormEdit.fixmedinsName = result[0].medinsName
          // 定点归属机构
          this.necSetlRegDFormEdit.fixmedinsPoolarea = result[0].poolarea
        } else {
          this.necSetlRegDFormEdit.fixmedinsName = ''
          this.necSetlRegDFormEdit.fixmedinsPoolarea = ''
          this.$message.error('该医药机构不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.necSetlRegDFormEdit.fixmedinsName = ''
        this.necSetlRegDFormEdit.fixmedinsPoolarea = ''
      }
    },
    async saveBeforeCheck () {
      // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
      const flag1 = this.checkBegnDate()
      if (flag1) {
        // 转出医院不能和转入医院相同
        const flag2 = await this.checkOverlapping()
        if (flag2) {
          return true
        }
      }
      return false
    },
    // 异步调用，一律采用 async/await 语法
    async queryNecSetlRegD () {
      try {
        this.necSetlRegDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
        this.tableLoading = true
        const necSetlRegDResult = await Service.resources.getByPage(this.necSetlRegDFormQuery, this.paginationConfig)
        if (necSetlRegDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.necSetlRegDList = []
        } else {
          this.necSetlRegDList = necSetlRegDResult.result
          this.paginationConfig.pageNumber = necSetlRegDResult.pageNumber
          this.paginationConfig.pageSize = necSetlRegDResult.pageSize
          this.paginationConfig.total = necSetlRegDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addNecSetlRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.post(this.necSetlRegDFormEdit)
          this.$message.info('新增成功！')
          this.editDialogVisible = false
          this.queryNecSetlRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateNecSetlRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.put(this.necSetlRegDFormEdit)
          this.$message.info('更新成功！')
          this.editDialogVisible = false
          this.queryNecSetlRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteNecSetlRegD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryNecSetlRegD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetNecSetlRegDEditForm () {
      this.$refs.necSetlRegDEditForm.resetFields()
    },
    necSetlRegDEditCancel () {
      this.resetNecSetlRegDEditForm()
      this.editDialogVisible = false
    },
    async showAddDialog () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo == null || psnNo == '') {
        this.$message.info('请输入人员编号！')
        return
      }
      const flag = await this.checkIsPass()
      if (!flag) {
        this.$message.info('该用户未参保或参保状态异常！')
        return
      }
      this.necSetlRegDFormEdit = new NecSetlRegDClass()
      this.operateType = 'add'
      // 添加默认信息
      this.necSetlRegDFormEdit.dclaSouc = '中心经办系统'
      this.necSetlRegDFormEdit.begndate = new Date()
      this.necSetlRegDFormEdit.updtTime = new Date()
      this.necSetlRegDFormEdit.valiFlag = '1'

      // 添加个人基本信息
      this.necSetlRegDFormEdit.psnNo = this.psnInfoBFormQuery.psnNo
      this.necSetlRegDFormEdit.certno = this.psnInfoBFormQuery.certNo
      this.necSetlRegDFormEdit.psnName = this.psnInfoBFormQuery.psnName
      this.necSetlRegDFormEdit.gend = this.psnInfoBFormQuery.gend
      this.necSetlRegDFormEdit.naty = '0' // 汉族
      this.necSetlRegDFormEdit.brdy = this.psnInfoBFormQuery.brdy
      this.necSetlRegDFormEdit.tel = this.psnInfoBFormQuery.tel
      this.necSetlRegDFormEdit.addr = this.psnInfoBFormQuery.addr
      this.necSetlRegDFormEdit.insuOptins = this.psnInfoBFormQuery.insuOptins
      this.necSetlRegDFormEdit.empNo = this.psnInfoBFormQuery.empCode
      this.necSetlRegDFormEdit.empName = this.psnInfoBFormQuery.empName
      this.necSetlRegDFormEdit.psnCertType = '0' // 身份证
      this.necSetlRegDFormEdit.insutype = this.psnInfoBFormQuery.insutype
      // 添加人员参保关系ID
      this.necSetlRegDFormEdit.psnInsuRltsId = this.psnInsuDFormQuery.psnInsuRltsId
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.necSetlRegDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.necSetlRegDFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.necSetlRegDEditForm.clearValidate()
      })
    },
    necSetlRegDEditConfirm () {
      this.$refs.necSetlRegDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateNecSetlRegD()
          } else {
            this.addNecSetlRegD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteNecSetlRegD(row.trtDclaDetlSn)
      })
    }
  },
  data () {
    const necSetlRegDColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '就诊事件ID', prop: 'mdtrtEvtId', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '结算事件ID', prop: 'setlId', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种', prop: 'insutype', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员参保关系ID', prop: 'psnInsuRltsId', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员证件类型',
        prop: 'psnCertType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'PSN_CERT_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '证件号码', prop: 'certno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员姓名', prop: 'psnName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '性别',
        prop: 'gend',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'GEND') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '年龄', prop: 'age', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保机构行政区划', prop: 'insuOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编号', prop: 'empNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位名称', prop: 'empName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点机构编号', prop: 'fixmedinsCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点机构名称', prop: 'fixmedinsName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '定点归属机构', prop: 'fixmedinsPoolarea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '申请理由', prop: 'appyRea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗类别', prop: 'medType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医疗费总额', prop: 'medfeeSumamt', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '住院号', prop: 'mdtrtsn', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '入院床位', prop: 'admBed', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '入院科室', prop: 'admDept', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '病区床位', prop: 'wardareaBed', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标识',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '备注', prop: 'memo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const necSetlRegDRules = {
      mdtrtEvtId: [{ required: true, message: '请填写就诊事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      setlId: [{ required: true, message: '请填写结算事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      insutype: [{ required: true, message: '请填写险种', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [{ required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      psnCertType: [{ required: true, message: '请选择人员证件类型', trigger: 'change' }],
      certno: [{ required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnName: [{ required: true, message: '请填写人员姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [{ required: true, message: '请选择性别', trigger: 'change' }],
      age: [{ required: true, message: '请填写年龄', trigger: 'blur' }
      ],
      brdy: [{ required: true, type: 'date', message: '请选择出生日期', trigger: 'change' }],
      insuOptins: [{ required: true, message: '请填写参保机构行政区划', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empNo: [{ required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empName: [{ required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      fixmedinsCode: [{ required: true, message: '请填写定点机构编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsName: [{ required: false, message: '请填写定点机构名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      fixmedinsPoolarea: [{ required: false, message: '请填写定点归属机构', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      appyRea: [{ required: true, message: '请填写申请理由', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      medType: [{ required: false, message: '请填写医疗类别', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      medfeeSumamt: [{ required: false, message: '请填写医疗费总额', trigger: 'blur' }
      ],
      begndate: [{ required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }],
      enddate: [{ required: false, type: 'date', message: '请选择结束日期', trigger: 'change' }],
      mdtrtsn: [{ required: false, message: '请填写住院号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      admBed: [{ required: false, message: '请填写入院床位', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      admDept: [{ required: false, message: '请填写入院科室', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      wardareaBed: [{ required: false, message: '请填写病区床位', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      valiFlag: [{ required: true, message: '请选择有效标识', trigger: 'change' }],
      memo: [{ required: false, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      necSetlRegDTabColDefs: necSetlRegDColDefs,
      necSetlRegDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      necSetlRegDFormDisabled: false,
      necSetlRegDFormEditDisabled: false,
      necSetlRegDFormQuery: new NecSetlRegDQueryClass(),
      necSetlRegDFormEdit: new NecSetlRegDClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      necSetlRegDEditFormRules: necSetlRegDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
