/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/

import NCP from '@ncp-web/core'
//import { codeFilter, tableDataFilter } from '@/common/filters/index'

// 业务服务上下文，必需设置为 process.env.VUE_APP_BASE_URL
const context = process.env.VUE_APP_BASE_URL

// 针对特定资源，创建 axios 实例
const resourcesConst = NCP.createAxios({
  baseURL: context + '/web/demo/necSetlRegD',
  headers: { businessId: 'necSetlRegDbusinessId' }
})

// 针对特定资源，创建资源访问对象
// 对象变量应同资源同名
const resources = {
  // 好用的POS请求示例
  // return empInsuMergeRes.post('/updateEmpMergeInfo', formEdit, {
  //   headers: { 'Content-Type': 'application/json' }
  // })
  
  //查询
  get(necSetlRegDQuery) {
    // 发送请求
    return resourcesConst.request({
      method: 'GET',
      params: necSetlRegDQuery,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  // 查询开始时间和结束时间相交的信息
  queryOverlapping(necSetlRegDQuery) {
    // 发送请求
    return resourcesConst.request({
      url: '/queryOverlapping',
      method: 'GET',
      params: Object.assign({},necSetlRegDQuery),
      headers: { 'Content-Type': 'application/json' }
    })
  },
  // 分页查询
  getByPage(necSetlRegDQuery, pageConfig) {
    // 发送请求
    return resourcesConst.request({
      url: '/page',
      method: 'GET',
      params: Object.assign({},pageConfig,necSetlRegDQuery),
      headers: { 'Content-Type': 'application/json' }
    })
  },
  post(necSetlRegD) {
    return resourcesConst.request({
      method: 'POST',
      data: necSetlRegD,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  put(necSetlRegD) {
    return resourcesConst.request({
      method: 'PUT',
      data: necSetlRegD,
      headers: { 'Content-Type': 'application/json' }
    })
  },
  delete(id) {
    return resourcesConst.request({
      url: '/' + id,
      method: 'DELETE'
    })
  }
}

export default {
  resources
}

