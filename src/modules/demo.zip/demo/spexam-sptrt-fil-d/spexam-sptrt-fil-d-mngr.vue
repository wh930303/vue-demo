<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="psnInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                      v-model="psnInfoBFormQuery.psnNo"
                      placeholder="请输入人员编号"
                      maxlength="20"
                      @blur="blurPsnInfoB"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                      v-model="psnInfoBFormQuery.psnName"
                      placeholder="请输入人员姓名"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                      v-model="psnInfoBFormQuery.brdy"
                      placeholder="请输入出生日期"

                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                      v-model="psnInfoBFormQuery.certNo"
                      placeholder="请输入证件号码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="psnInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                      v-model="psnInfoBFormQuery.naty"
                      placeholder="请输入民族"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                      v-model="psnInfoBFormQuery.addr"
                      placeholder="请输入联系地址"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                      v-model="psnInfoBFormQuery.gend"
                      placeholder="请输入性别"
                      maxlength="1"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                      v-model="psnInfoBFormQuery.insutype"
                      placeholder="请输入险种"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="psnInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="psnInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="6"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                      v-model="psnInfoBFormQuery.empCode"
                      placeholder="请输入单位编码"
                      maxlength="30"

                  ></el-input>
                </el-form-item>
              </hsa-col>
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
                <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="querySpexamSptrtFilD">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="spexamSptrtFilDTabColDefs"
              :data="spexamSptrtFilDList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="querySpexamSptrtFilD"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="特检特治审批备案信息"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="spexamSptrtFilDFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="spexamSptrtFilDEditFormRules"
           ref="spexamSptrtFilDEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="spexamSptrtFilDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种" prop="insutype">
            <el-input
                v-model="spexamSptrtFilDFormEdit.insutype"
                placeholder="请输入险种"
                maxlength="6"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="spexamSptrtFilDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="spexamSptrtFilDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="20"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员证件类型" prop="certType">
            <el-select v-model="spexamSptrtFilDFormEdit.certType" type="CERT_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certno">
            <el-input
                v-model="spexamSptrtFilDFormEdit.certno"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员姓名" prop="psnName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.psnName"
                placeholder="请输入人员姓名"
                maxlength="50"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-select v-model="spexamSptrtFilDFormEdit.gend" type="GEND" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系电话" prop="tel">
            <el-input
                v-model="spexamSptrtFilDFormEdit.tel"
                placeholder="请输入联系电话"
                maxlength="50"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系地址" prop="addr">
            <el-input
                v-model="spexamSptrtFilDFormEdit.addr"
                placeholder="请输入联系地址"
                maxlength="300"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保机构行政区划" prop="insuOptins">
            <el-input
                v-model="spexamSptrtFilDFormEdit.insuOptins"
                placeholder="请输入参保机构行政区划"
                maxlength="6"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="spexamSptrtFilDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="申请日期" prop="appyDate">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.appyDate"
                placeholder="请输入申请日期"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="申请理由" prop="appyRea">
            <el-input
                v-model="spexamSptrtFilDFormEdit.appyRea"
                placeholder="请输入申请理由"
                maxlength="1000"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="目录类别" prop="hilistType">
            <el-select v-model="spexamSptrtFilDFormEdit.hilistType" type="HILIST_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医保目录编码" prop="hilistCode">
            <el-input
                v-model="spexamSptrtFilDFormEdit.hilistCode"
                placeholder="请输入医保目录编码"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
                @blur="queryHilistB"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="医保目录名称" prop="hilistName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.hilistName"
                placeholder="请输入医保目录名称"
                maxlength="200"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="数量" prop="cnt">
            <el-input
                v-model="spexamSptrtFilDFormEdit.cnt"
                placeholder="请输入数量"
                maxlength="${field.columnLength}"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="计价单位" prop="prcunt">
            <el-input
                v-model="spexamSptrtFilDFormEdit.prcunt"
                placeholder="请输入计价单位"
                maxlength="100"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开单科室编码" prop="bilgDeptCodg">
            <el-input
                v-model="spexamSptrtFilDFormEdit.bilgDeptCodg"
                placeholder="请输入开单科室编码"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
                @blur="queryMedinsDeptInfoB"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开单科室名称" prop="bilgDeptName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.bilgDeptName"
                placeholder="请输入开单科室名称"
                maxlength="100"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开单医生编码" prop="bilgDrCodg">
            <el-input
                v-model="spexamSptrtFilDFormEdit.bilgDrCodg"
                placeholder="请输入开单医生编码"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
                @blur="queryDrInfoB"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开单医生姓名" prop="bilgDrName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.bilgDrName"
                placeholder="请输入开单医生姓名"
                maxlength="50"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="诊断代码" prop="diseCode">
            <el-input
                v-model="spexamSptrtFilDFormEdit.diseCode"
                placeholder="请输入诊断代码"
                maxlength="20"
                :disabled="spexamSptrtFilDFormEditDisabled"
                @blur="queryDiseListB"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="诊断名称" prop="diseName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.diseName"
                placeholder="请输入诊断名称"
                maxlength="300"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="疾病病情描述" prop="diseCondDscr">
            <el-input
                v-model="spexamSptrtFilDFormEdit.diseCondDscr"
                placeholder="请输入疾病病情描述"
                maxlength="1000"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="治疗情况" prop="trtInfo">
            <el-input
                v-model="spexamSptrtFilDFormEdit.trtInfo"
                placeholder="请输入治疗情况"
                maxlength="1000"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="开始日期" prop="begndate">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结束日期" prop="enddate">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="业务使用标志" prop="bizUsedFlag">
            <el-select v-model="spexamSptrtFilDFormEdit.bizUsedFlag" type="BIZ_USED_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="备注" prop="memo">
            <el-input
                v-model="spexamSptrtFilDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="spexamSptrtFilDFormEdit.valiFlag" type="VALI_FLAG"  class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="更新时间" prop="updtTime">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.updtTime"
                placeholder="请输入更新时间"

                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="申报来源" prop="dclaSouc">
            <el-input
                v-model="spexamSptrtFilDFormEdit.dclaSouc"
                placeholder="请输入申报来源"
                maxlength="6"

            ></el-input>
          </el-form-item>
        </hsa-col>
        <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="就诊事件ID" prop="mdtrtEvtId">
            <el-input
                v-model="spexamSptrtFilDFormEdit.mdtrtEvtId"
                placeholder="请输入就诊事件ID"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="结算事件ID" prop="setlId">
            <el-input
                v-model="spexamSptrtFilDFormEdit.setlId"
                placeholder="请输入结算事件ID"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="spexamSptrtFilDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="spexamSptrtFilDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="spexamSptrtFilDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="spexamSptrtFilDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="spexamSptrtFilDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="spexamSptrtFilDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="spexamSptrtFilDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="spexamSptrtFilDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="30"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="spexamSptrtFilDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="spexamSptrtFilDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="spexamSptrtFilDEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="spexamSptrtFilDEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './spexam-sptrt-fil-d-mngr.service'
import SpexamSptrtFilDClass from '@/modules/demo/class/spexam-sptrt-fil-d-mngr.class'
import SpexamSptrtFilDQueryClass from '@/modules/demo/class/spexam-sptrt-fil-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
import MedinsDeptInfoBQueryClass from '@/modules/demo/class/medins-dept-info-b-mngr-query.class'
import HilistBQueryClass from '@/modules/demo/class/hilist-b-mngr-query.class'
import DrInfoBQueryClass from '@/modules/demo/class/dr-info-b-mngr-query.class'
import DiseListBQueryClass from '@/modules/demo/class/dise-list-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.spexamSptrtFilDFormQuery = new SpexamSptrtFilDQueryClass()
      this.spexamSptrtFilDFormEdit = new SpexamSptrtFilDClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.medinsDeptInfoBFormQuery = new MedinsDeptInfoBQueryClass()
      this.hilistBFormQuery = new HilistBQueryClass()
      this.drInfoBFormQuery = new DrInfoBQueryClass()
      this.diseListBFormQuery = new DiseListBQueryClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.spexamSptrtFilDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.spexamSptrtFilDFormDisabled = false
      this.spexamSptrtFilDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo != '') {
        try {
          this.psnInfoBFormQuery = new PsnInfoBQueryClass()
          this.psnInfoBFormQuery.psnNo = psnNo
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(this.psnInfoBFormQuery)
          if (psnInfoBResult.length != '0') {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    async checkIsPass () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInsuDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
      const psnInsuDResult = await psnInfoBService.getPsnInsuD(this.psnInsuDFormQuery)
      // 已经参保且参保状正常
      if (psnInsuDResult.length > 0 && psnInsuDResult[0].psnInsuStas == '1') {
        this.psnInsuDFormQuery = psnInsuDResult[0]
        return true
      } else {
        return false
      }
    },
    // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
    checkBegnDate () {
      const begnDate = this.spexamSptrtFilDFormEdit.begndate
      const endDate = this.spexamSptrtFilDFormEdit.enddate
      if (begnDate != null && begnDate != '' && endDate != null && endDate != '') {
        if (begnDate > endDate) {
          this.$message.error('开始日期不得晚于结束日期!')
          return false
        }
      }
      return true
    },
    // 查询开始时间和结束时间相交的信息
    async checkOverlapping () {
      try {
        this.spexamSptrtFilDFormQuery = new SpexamSptrtFilDQueryClass()
        this.spexamSptrtFilDFormQuery.rid = this.spexamSptrtFilDFormEdit.rid
        this.spexamSptrtFilDFormQuery.psnNo = this.spexamSptrtFilDFormEdit.psnNo
        if (this.spexamSptrtFilDFormEdit.begndate != null && this.spexamSptrtFilDFormEdit.begndate != '') {
          this.spexamSptrtFilDFormQuery.begndate = new Date(this.spexamSptrtFilDFormEdit.begndate).getTime()
        }

        if (this.spexamSptrtFilDFormEdit.enddate != null && this.spexamSptrtFilDFormEdit.enddate != '') {
          this.spexamSptrtFilDFormQuery.enddate = new Date(this.spexamSptrtFilDFormEdit.enddate).getTime()
        } else {
          this.spexamSptrtFilDFormQuery.enddate = new Date(this.spexamSptrtFilDFormEdit.begndate)
          this.spexamSptrtFilDFormQuery.enddate.setDate(this.spexamSptrtFilDFormQuery.enddate.getDate() + 1)
          this.spexamSptrtFilDFormQuery.enddate = new Date(this.spexamSptrtFilDFormQuery.enddate).getTime()
        }
        const reflAppyDResult = await Service.resources.queryOverlapping(this.spexamSptrtFilDFormQuery)
        if (reflAppyDResult.length == '0') {
          return true
        } else {
          this.$message.error('与其他登记信息的开始日期和结束日期不能交叉、重叠!')
          return false
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.spexamSptrtFilDFormQuery = new SpexamSptrtFilDQueryClass()
      }
    },
    // 查询医保目录信息
    async queryHilistB () {
      if (this.spexamSptrtFilDFormEdit.hilistType == null || this.spexamSptrtFilDFormEdit.hilistType == '') {
        this.$message.info('请先选择目录类别！')
        this.spexamSptrtFilDFormEdit.hilistCode = ''
        return
      }
      this.hilistBFormQuery.hilistCode = this.spexamSptrtFilDFormEdit.hilistCode
      this.hilistBFormQuery.hilistType = this.spexamSptrtFilDFormEdit.hilistType
      if (this.hilistBFormQuery.hilistCode != null && this.hilistBFormQuery.hilistCode != '') {
        const result = await psnInfoBService.getHilistB(this.hilistBFormQuery)
        // 存在医保目录信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医保目录名称
          this.spexamSptrtFilDFormEdit.hilistName = result[0].hilistName
        } else {
          this.spexamSptrtFilDFormEdit.hilistName = ''
          this.$message.error('该医保目录不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.spexamSptrtFilDFormEdit.hilistName = ''
      }
    },
    // 查询医疗机构科室信息
    async queryMedinsDeptInfoB () {
      this.medinsDeptInfoBFormQuery.hospDeptCode = this.spexamSptrtFilDFormEdit.bilgDeptCodg
      if (this.medinsDeptInfoBFormQuery.hospDeptCode != null && this.medinsDeptInfoBFormQuery.hospDeptCode != '') {
        const result = await psnInfoBService.getMedinsDeptInfoB(this.medinsDeptInfoBFormQuery)
        // 存在医疗机构科室信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 科室名称
          this.spexamSptrtFilDFormEdit.bilgDeptName = result[0].hospDeptName
        } else {
          this.spexamSptrtFilDFormEdit.bilgDeptName = ''
          this.$message.error('该科室不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.spexamSptrtFilDFormEdit.bilgDeptName = ''
      }
    },
    // 查询医师信息
    async queryDrInfoB () {
      this.drInfoBFormQuery.drCode = this.spexamSptrtFilDFormEdit.bilgDrCodg
      if (this.drInfoBFormQuery.drCode != null && this.drInfoBFormQuery.drCode != '') {
        const result = await psnInfoBService.getDrInfoB(this.drInfoBFormQuery)
        // 存在医师信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 医师信息
          this.spexamSptrtFilDFormEdit.bilgDrName = result[0].psnName
        } else {
          this.spexamSptrtFilDFormEdit.bilgDrName = ''
          this.$message.error('该医师不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.spexamSptrtFilDFormEdit.bilgDrName = ''
      }
    },
    // 查询疾病诊断目录信息
    async queryDiseListB () {
      this.diseListBFormQuery.diseCode = this.spexamSptrtFilDFormEdit.diseCode
      if (this.diseListBFormQuery.diseCode != null && this.diseListBFormQuery.diseCode != '') {
        const result = await psnInfoBService.getDiseListB(this.diseListBFormQuery)
        // 存在疾病诊断目录信息且有效
        if (result.length > 0 && result[0].valiFlag == '1') {
          // 诊断名称
          this.spexamSptrtFilDFormEdit.diseName = result[0].diseName
        } else {
          this.spexamSptrtFilDFormEdit.diseName = ''
          this.$message.error('该诊断目录不存在或无效！')
        }
      } else {
        this.spexamSptrtFilDFormEdit.diseName = ''
      }
    },
    // 异步调用，一律采用 async/await 语法
    async querySpexamSptrtFilD () {
      try {
        this.spexamSptrtFilDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
        this.tableLoading = true
        const spexamSptrtFilDResult = await Service.resources.getByPage(this.spexamSptrtFilDFormQuery, this.paginationConfig)
        if (spexamSptrtFilDResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.spexamSptrtFilDList = []
        } else {
          this.spexamSptrtFilDList = spexamSptrtFilDResult.result
          this.paginationConfig.pageNumber = spexamSptrtFilDResult.pageNumber
          this.paginationConfig.pageSize = spexamSptrtFilDResult.pageSize
          this.paginationConfig.total = spexamSptrtFilDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async saveBeforeCheck () {
      // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
      const flag1 = this.checkBegnDate()
      if (flag1) {
        // 查询开始时间和结束时间相交的信息
        const flag2 = await this.checkOverlapping()
        if (flag2) {
          return true
        }
      }
      return false
    },
    async addSpexamSptrtFilD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.post(this.spexamSptrtFilDFormEdit)
          this.$message.info('新增成功！')
          this.editDialogVisible = false
          this.querySpexamSptrtFilD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateSpexamSptrtFilD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.put(this.spexamSptrtFilDFormEdit)
          this.$message.info('更新成功！')
          this.editDialogVisible = false
          this.querySpexamSptrtFilD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteSpexamSptrtFilD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.querySpexamSptrtFilD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetSpexamSptrtFilDEditForm () {
      this.$refs.spexamSptrtFilDEditForm.resetFields()
    },
    spexamSptrtFilDEditCancel () {
      this.resetSpexamSptrtFilDEditForm()
      this.editDialogVisible = false
    },
    async showAddDialog () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo == null || psnNo == '') {
        this.$message.info('请输入人员编号！')
        return
      }
      const flag = await this.checkIsPass()
      if (!flag) {
        this.$message.info('该用户未参保或参保状态异常！')
        return
      }
      this.spexamSptrtFilDFormEdit = new SpexamSptrtFilDClass()
      this.operateType = 'add'
      // 添加默认信息
      this.spexamSptrtFilDFormEdit.dclaSouc = '中心经办系统'
      this.spexamSptrtFilDFormEdit.begndate = new Date()
      this.spexamSptrtFilDFormEdit.updtTime = new Date()
      this.spexamSptrtFilDFormEdit.appyDate = new Date()
      this.spexamSptrtFilDFormEdit.valiFlag = '1'

      // 添加个人基本信息
      this.spexamSptrtFilDFormEdit.psnNo = this.psnInfoBFormQuery.psnNo
      this.spexamSptrtFilDFormEdit.certno = this.psnInfoBFormQuery.certNo
      this.spexamSptrtFilDFormEdit.psnName = this.psnInfoBFormQuery.psnName
      this.spexamSptrtFilDFormEdit.gend = this.psnInfoBFormQuery.gend
      this.spexamSptrtFilDFormEdit.naty = '0' // 汉族
      this.spexamSptrtFilDFormEdit.brdy = this.psnInfoBFormQuery.brdy
      this.spexamSptrtFilDFormEdit.tel = this.psnInfoBFormQuery.tel
      this.spexamSptrtFilDFormEdit.addr = this.psnInfoBFormQuery.addr
      this.spexamSptrtFilDFormEdit.insuOptins = this.psnInfoBFormQuery.insuOptins
      this.spexamSptrtFilDFormEdit.empNo = this.psnInfoBFormQuery.empCode
      this.spexamSptrtFilDFormEdit.empName = this.psnInfoBFormQuery.empName
      this.spexamSptrtFilDFormEdit.certType = '0' // 身份证
      this.spexamSptrtFilDFormEdit.insutype = this.psnInfoBFormQuery.insutype
      // 添加人员参保关系ID
      this.spexamSptrtFilDFormEdit.psnInsuRltsId = this.psnInsuDFormQuery.psnInsuRltsId
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.spexamSptrtFilDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.spexamSptrtFilDFormEdit = Object.assign({}, row)
      // 判断结束时间（修改登记信息时，如果结束日期为空，需要置为开始日期加一年）
      if (this.spexamSptrtFilDFormEdit.enddate == null || this.spexamSptrtFilDFormEdit.enddate == '') {
        this.spexamSptrtFilDFormEdit.enddate = new Date(this.spexamSptrtFilDFormEdit.begndate)
        this.spexamSptrtFilDFormEdit.enddate.setFullYear(this.spexamSptrtFilDFormEdit.enddate.getFullYear() + 1)
      }
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.spexamSptrtFilDEditForm.clearValidate()
      })
    },
    spexamSptrtFilDEditConfirm () {
      this.$refs.spexamSptrtFilDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateSpexamSptrtFilD()
          } else {
            this.addSpexamSptrtFilD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteSpexamSptrtFilD(row.trtDclaDetlSn)
      })
    }
  },
  data () {
    const spexamSptrtFilDColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '申报来源', prop: 'dclaSouc', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '险种', prop: 'insutype', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员编号', prop: 'psnNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员参保关系ID', prop: 'psnInsuRltsId', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员证件类型',
        prop: 'certType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'CERT_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '证件号码', prop: 'certno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '人员姓名', prop: 'psnName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '性别',
        prop: 'gend',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'GEND') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系电话', prop: 'tel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系地址', prop: 'addr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保机构行政区划', prop: 'insuOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位编号', prop: 'empNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位名称', prop: 'empName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '开单科室编码', prop: 'bilgDeptCodg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '开单科室名称', prop: 'bilgDeptName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '开单医生编码', prop: 'bilgDrCodg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '开单医生姓名', prop: 'bilgDrName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '诊断代码', prop: 'diseCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '诊断名称', prop: 'diseName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '疾病病情描述', prop: 'diseCondDscr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '治疗情况', prop: 'trtInfo', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '目录类别',
        prop: 'hilistType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'HILIST_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医保目录编码', prop: 'hilistCode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医保目录名称', prop: 'hilistName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '数量', prop: 'cnt', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '计价单位', prop: 'prcunt', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '申请日期',
        prop: 'appyDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '申请理由', prop: 'appyRea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '就诊事件ID', prop: 'mdtrtEvtId', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '结算事件ID', prop: 'setlId', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '业务使用标志',
        prop: 'bizUsedFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'BIZ_USED_FLAG') } }] },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '备注', prop: 'memo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const spexamSptrtFilDRules = {
      dclaSouc: [{ required: true, message: '请填写申报来源', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      insutype: [{ required: true, message: '请填写险种', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnNo: [{ required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [{ required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      certType: [{ required: true, message: '请选择人员证件类型', trigger: 'change' }],
      certno: [{ required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnName: [{ required: true, message: '请填写人员姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [{ required: true, message: '请选择性别', trigger: 'change' }],
      brdy: [{ required: true, type: 'date', message: '请选择出生日期', trigger: 'change' }],
      tel: [{ required: true, message: '请填写联系电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      addr: [{ required: true, message: '请填写联系地址', trigger: 'blur' },
        { max: 300, message: '长度不能超过 300 个字符', trigger: 'blur' }
      ],
      insuOptins: [{ required: true, message: '请填写参保机构行政区划', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empNo: [{ required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empName: [{ required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      bilgDeptCodg: [{ required: false, message: '请填写开单科室编码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      bilgDeptName: [{ required: false, message: '请填写开单科室名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      bilgDrCodg: [{ required: false, message: '请填写开单医生编码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      bilgDrName: [{ required: false, message: '请填写开单医生姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      diseCode: [{ required: false, message: '请填写诊断代码', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      diseName: [{ required: false, message: '请填写诊断名称', trigger: 'blur' },
        { max: 300, message: '长度不能超过 300 个字符', trigger: 'blur' }
      ],
      diseCondDscr: [{ required: false, message: '请填写疾病病情描述', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      trtInfo: [{ required: false, message: '请填写治疗情况', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      hilistType: [{ required: true, message: '请选择目录类别', trigger: 'change' }],
      hilistCode: [{ required: true, message: '请填写医保目录编码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      hilistName: [{ required: false, message: '请填写医保目录名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      cnt: [{ required: false, message: '请填写数量', trigger: 'blur' }
      ],
      prcunt: [{ required: false, message: '请填写计价单位', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      begndate: [{ required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }],
      enddate: [{ required: false, type: 'date', message: '请选择结束日期', trigger: 'change' }],
      appyDate: [{ required: true, type: 'date', message: '请选择申请日期', trigger: 'change' }],
      appyRea: [{ required: false, message: '请填写申请理由', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      mdtrtEvtId: [{ required: true, message: '请填写就诊事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      setlId: [{ required: true, message: '请填写结算事件ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      bizUsedFlag: [{ required: true, message: '请选择业务使用标志', trigger: 'change' }],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      memo: [{ required: false, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [{ required: true, type: 'date', message: '请选择更新时间', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择创建时间', trigger: 'change' }],
      crteOptins: [{ required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      spexamSptrtFilDTabColDefs: spexamSptrtFilDColDefs,
      spexamSptrtFilDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      spexamSptrtFilDFormDisabled: false,
      spexamSptrtFilDFormEditDisabled: false,
      spexamSptrtFilDFormQuery: new SpexamSptrtFilDQueryClass(),
      spexamSptrtFilDFormEdit: new SpexamSptrtFilDClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      medinsDeptInfoBFormQuery: new MedinsDeptInfoBQueryClass(),
      hilistBFormQuery: new HilistBQueryClass(),
      drInfoBFormQuery: new DrInfoBQueryClass(),
      diseListBFormQuery: new DiseListBQueryClass(),
      spexamSptrtFilDEditFormRules: spexamSptrtFilDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
