/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/spexam-sptrt-fil-d',
  component: () => import('@/modules/demo/spexam-sptrt-fil-d/spexam-sptrt-fil-d-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
          'CERT_TYPE',
          'GEND',
          'HILIST_TYPE',
          'BIZ_USED_FLAG',
          'VALI_FLAG',
    ] }
}
