/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/psn-fil-sum-info-d',
  component: () => import('@/modules/demo/psn-fil-sum-info-d/psn-fil-sum-info-d-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
          'YEAR',
          'BIZ_APPY_TYPE',
          'VALI_FLAG',
    ] }
}
