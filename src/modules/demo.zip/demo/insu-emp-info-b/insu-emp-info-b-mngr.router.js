/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/insu-emp-info-b',
  component: () => import('@/modules/demo/insu-emp-info-b/insu-emp-info-b-mngr.vue'),
// typeList 中编写模块所需二级代码
  meta: { typeList: [
          'EMP_TYPE',
          'REGNO_CERT_TYPE',
          'ORG_VALI_STAS',
          'LEGREP_CERT_TYPE',
          'VALI_FLAG',
    ] }
}
