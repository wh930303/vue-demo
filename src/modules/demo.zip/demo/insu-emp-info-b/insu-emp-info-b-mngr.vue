<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
              :model="insuEmpInfoBFormQuery"
              label-position="right"
              label-width="120px"
              size="medium"
              @submit.native.prevent
          >
            <hsa-row collapseBtn>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.empNo"
                      placeholder="请输入单位编号"
                      maxlength="30"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位实体编码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.empEnttCodg"
                      placeholder="请输入单位实体编码"
                      maxlength="40"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位管理类型">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.empMgtType"
                      placeholder="请输入单位管理类型"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="上级单位编号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.prntEmpNo"
                      placeholder="请输入上级单位编号"
                      maxlength="40"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="关联法人标志">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.asocLegentFlag"
                      placeholder="请输入关联法人标志"
                      maxlength="6"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位类型">
                  <el-select v-model="insuEmpInfoBFormQuery.empType" type="EMP_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.empName"
                      placeholder="请输入单位名称"
                      maxlength="200"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="注册名称">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.regName"
                      placeholder="请输入注册名称"
                      maxlength="255"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="所属行政区">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.locAdmdvs"
                      placeholder="请输入所属行政区"
                      maxlength="6"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系人姓名">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.conerName"
                      placeholder="请输入联系人姓名"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系人电子邮箱">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.conerEmail"
                      placeholder="请输入联系人电子邮箱"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.tel"
                      placeholder="请输入联系电话"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="传真号码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.faxNo"
                      placeholder="请输入传真号码"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="税号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.taxNo"
                      placeholder="请输入税号"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="组织机构代码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.orgcode"
                      placeholder="请输入组织机构代码"
                      maxlength="30"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="注册号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.regno"
                      placeholder="请输入注册号"
                      maxlength="100"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="注册号证件类型">
                  <el-select v-model="insuEmpInfoBFormQuery.regnoCertType" type="REGNO_CERT_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位地址">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.empAddr"
                      placeholder="请输入单位地址"
                      maxlength="500"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="邮政编码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.poscode"
                      placeholder="请输入邮政编码"
                      maxlength="6"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="批准成立部门">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.aprvEstaDept"
                      placeholder="请输入批准成立部门"
                      maxlength="100"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="批准成立日期">
                  <el-date-picker
                      v-model="insuEmpInfoBFormQuery.aprvEstaDate"
                      placeholder="请输入批准成立日期"
                      :disabled="insuEmpInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="批准成立文号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.aprvEstaDocno"
                      placeholder="请输入批准成立文号"
                      maxlength="100"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="上级行政区划">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.prntAdmdvs"
                      placeholder="请输入上级行政区划"
                      maxlength="6"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.insuOptins"
                      placeholder="请输入参保所属机构"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="组织有效状态">
                  <el-select v-model="insuEmpInfoBFormQuery.orgValiStas" type="ORG_VALI_STAS" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="法定代表人电话号码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.legrepTel"
                      placeholder="请输入法定代表人电话号码"
                      maxlength="200"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="法定代表人姓名">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.legrepName"
                      placeholder="请输入法定代表人姓名"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="法定代表人证件类型">
                  <el-select v-model="insuEmpInfoBFormQuery.legrepCertType" type="LEGREP_CERT_TYPE" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="法定代表人证件号码">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.legrepCertno"
                      placeholder="请输入法定代表人证件号码"
                      maxlength="40"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="组织机构代码证颁发单位">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.orgcodeIssuEmp"
                      placeholder="请输入组织机构代码证颁发单位"
                      maxlength="100"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="有效标志">
                  <el-select v-model="insuEmpInfoBFormQuery.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="数据创建时间">
                  <el-date-picker
                      v-model="insuEmpInfoBFormQuery.crteTime"
                      placeholder="请输入数据创建时间"
                      :disabled="insuEmpInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="数据更新时间">
                  <el-date-picker
                      v-model="insuEmpInfoBFormQuery.updtTime"
                      placeholder="请输入数据更新时间"
                      :disabled="insuEmpInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.crter"
                      placeholder="请输入创建人"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建人姓名">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.crterName"
                      placeholder="请输入创建人姓名"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="创建经办机构">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.crteOptins"
                      placeholder="请输入创建经办机构"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.opter"
                      placeholder="请输入经办人"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办人姓名">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.opterName"
                      placeholder="请输入经办人姓名"
                      maxlength="50"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办时间">
                  <el-date-picker
                      v-model="insuEmpInfoBFormQuery.optTime"
                      placeholder="请输入经办时间"
                      :disabled="insuEmpInfoBFormDisabled"
                      style="width: 100%;"
                      type="date"
                      format="yyyy 年 MM 月 dd 日"
                      value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="经办机构">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.optins"
                      placeholder="请输入经办机构"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="统筹区">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.poolarea"
                      placeholder="请输入统筹区"
                      maxlength="6"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
                <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="版本号">
                  <el-input
                      v-model="insuEmpInfoBFormQuery.ver"
                      placeholder="请输入版本号"
                      maxlength="20"
                      :disabled="insuEmpInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col>
  			  <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryInsuEmpInfoB">查询</el-button>
              </template>

            </hsa-row>

          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
      </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success"  @click="showAddDialog">增加 </el-button>
          </template>

          <ncp-table
              :columnDefs="insuEmpInfoBTabColDefs"
              :data="insuEmpInfoBList"
              :enablePagination="true"
              :paginationConfig="paginationConfig"
              :useExternalPagination="true"
              @paginationConfigChange="queryInsuEmpInfoB"
              v-loading="tableLoading"
              :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
        title="参保单位信息表"
        :visible.sync="editDialogVisible"
        width="80%"
      	:close-on-click-modal="false"
        class="hsa-dialog"
    >
      <el-form :model="insuEmpInfoBFormEdit"
           label-position="right"
           label-width="120px"
           size="medium"
           :rules="insuEmpInfoBEditFormRules"
           ref="insuEmpInfoBEditForm"
           @submit.native.prevent
      >
        <hsa-row>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="insuEmpInfoBFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位实体编码" prop="empEnttCodg">
            <el-input
                v-model="insuEmpInfoBFormEdit.empEnttCodg"
                placeholder="请输入单位实体编码"
                maxlength="40"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位管理类型" prop="empMgtType">
            <el-input
                v-model="insuEmpInfoBFormEdit.empMgtType"
                placeholder="请输入单位管理类型"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="上级单位编号" prop="prntEmpNo">
            <el-input
                v-model="insuEmpInfoBFormEdit.prntEmpNo"
                placeholder="请输入上级单位编号"
                maxlength="40"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="关联法人标志" prop="asocLegentFlag">
            <el-input
                v-model="insuEmpInfoBFormEdit.asocLegentFlag"
                placeholder="请输入关联法人标志"
                maxlength="6"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位类型" prop="empType">
            <el-select v-model="insuEmpInfoBFormEdit.empType" type="EMP_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="insuEmpInfoBFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="200"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="注册名称" prop="regName">
            <el-input
                v-model="insuEmpInfoBFormEdit.regName"
                placeholder="请输入注册名称"
                maxlength="255"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="所属行政区" prop="locAdmdvs">
            <el-input
                v-model="insuEmpInfoBFormEdit.locAdmdvs"
                placeholder="请输入所属行政区"
                maxlength="6"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系人姓名" prop="conerName">
            <el-input
                v-model="insuEmpInfoBFormEdit.conerName"
                placeholder="请输入联系人姓名"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系人电子邮箱" prop="conerEmail">
            <el-input
                v-model="insuEmpInfoBFormEdit.conerEmail"
                placeholder="请输入联系人电子邮箱"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="联系电话" prop="tel">
            <el-input
                v-model="insuEmpInfoBFormEdit.tel"
                placeholder="请输入联系电话"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="传真号码" prop="faxNo">
            <el-input
                v-model="insuEmpInfoBFormEdit.faxNo"
                placeholder="请输入传真号码"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="税号" prop="taxNo">
            <el-input
                v-model="insuEmpInfoBFormEdit.taxNo"
                placeholder="请输入税号"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="组织机构代码" prop="orgcode">
            <el-input
                v-model="insuEmpInfoBFormEdit.orgcode"
                placeholder="请输入组织机构代码"
                maxlength="30"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="注册号" prop="regno">
            <el-input
                v-model="insuEmpInfoBFormEdit.regno"
                placeholder="请输入注册号"
                maxlength="100"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="注册号证件类型" prop="regnoCertType">
            <el-select v-model="insuEmpInfoBFormEdit.regnoCertType" type="REGNO_CERT_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位地址" prop="empAddr">
            <el-input
                v-model="insuEmpInfoBFormEdit.empAddr"
                placeholder="请输入单位地址"
                maxlength="500"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="邮政编码" prop="poscode">
            <el-input
                v-model="insuEmpInfoBFormEdit.poscode"
                placeholder="请输入邮政编码"
                maxlength="6"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="批准成立部门" prop="aprvEstaDept">
            <el-input
                v-model="insuEmpInfoBFormEdit.aprvEstaDept"
                placeholder="请输入批准成立部门"
                maxlength="100"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="批准成立日期" prop="aprvEstaDate">
            <el-date-picker
                v-model="insuEmpInfoBFormEdit.aprvEstaDate"
                placeholder="请输入批准成立日期"
                :disabled="insuEmpInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="批准成立文号" prop="aprvEstaDocno">
            <el-input
                v-model="insuEmpInfoBFormEdit.aprvEstaDocno"
                placeholder="请输入批准成立文号"
                maxlength="100"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="上级行政区划" prop="prntAdmdvs">
            <el-input
                v-model="insuEmpInfoBFormEdit.prntAdmdvs"
                placeholder="请输入上级行政区划"
                maxlength="6"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保所属机构" prop="insuOptins">
            <el-input
                v-model="insuEmpInfoBFormEdit.insuOptins"
                placeholder="请输入参保所属机构"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="组织有效状态" prop="orgValiStas">
            <el-select v-model="insuEmpInfoBFormEdit.orgValiStas" type="ORG_VALI_STAS" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="法定代表人电话号码" prop="legrepTel">
            <el-input
                v-model="insuEmpInfoBFormEdit.legrepTel"
                placeholder="请输入法定代表人电话号码"
                maxlength="200"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="法定代表人姓名" prop="legrepName">
            <el-input
                v-model="insuEmpInfoBFormEdit.legrepName"
                placeholder="请输入法定代表人姓名"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="法定代表人证件类型" prop="legrepCertType">
            <el-select v-model="insuEmpInfoBFormEdit.legrepCertType" type="LEGREP_CERT_TYPE" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="法定代表人证件号码" prop="legrepCertno">
            <el-input
                v-model="insuEmpInfoBFormEdit.legrepCertno"
                placeholder="请输入法定代表人证件号码"
                maxlength="40"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="组织机构代码证颁发单位" prop="orgcodeIssuEmp">
            <el-input
                v-model="insuEmpInfoBFormEdit.orgcodeIssuEmp"
                placeholder="请输入组织机构代码证颁发单位"
                maxlength="100"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="有效标志" prop="valiFlag">
            <el-select v-model="insuEmpInfoBFormEdit.valiFlag" type="VALI_FLAG" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="insuEmpInfoBFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="数据创建时间" prop="crteTime">
            <el-date-picker
                v-model="insuEmpInfoBFormEdit.crteTime"
                placeholder="请输入数据创建时间"
                :disabled="insuEmpInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="数据更新时间" prop="updtTime">
            <el-date-picker
                v-model="insuEmpInfoBFormEdit.updtTime"
                placeholder="请输入数据更新时间"
                :disabled="insuEmpInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="insuEmpInfoBFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="insuEmpInfoBFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建经办机构" prop="crteOptins">
            <el-input
                v-model="insuEmpInfoBFormEdit.crteOptins"
                placeholder="请输入创建经办机构"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="insuEmpInfoBFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="insuEmpInfoBFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="insuEmpInfoBFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="insuEmpInfoBFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="insuEmpInfoBFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="insuEmpInfoBFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="版本号" prop="ver">
            <el-input
                v-model="insuEmpInfoBFormEdit.ver"
                placeholder="请输入版本号"
                maxlength="20"
                :disabled="insuEmpInfoBFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="insuEmpInfoBEditCancel" size="medium">取 消</el-button>
        <el-button type="primary" @click="insuEmpInfoBEditConfirm" size="medium" :loading="buttonLoading" :disabled="buttonLoading">保 存</el-button>
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './insu-emp-info-b-mngr.service'
import InsuEmpInfoBClass from '@/modules/demo/class/insu-emp-info-b-mngr.class'
import InsuEmpInfoBQueryClass from '@/modules/demo/class/insu-emp-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.insuEmpInfoBFormQuery = new InsuEmpInfoBQueryClass()
      this.insuEmpInfoBFormEdit = new InsuEmpInfoBClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.insuEmpInfoBList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.insuEmpInfoBFormDisabled = false
      this.insuEmpInfoBFormEditDisabled = false
    },
    // 异步调用，一律采用 async/await 语法
    async queryInsuEmpInfoB () {
      try {
        this.tableLoading = true
        const insuEmpInfoBResult = await Service.resources.getByPage(this.insuEmpInfoBFormQuery, this.paginationConfig)
        if (insuEmpInfoBResult.result.length == '0') {
          this.$message.info('没有查询到数据！')
          this.insuEmpInfoBList = []
        } else {
          this.insuEmpInfoBList = insuEmpInfoBResult.result
          this.paginationConfig.pageNumber = insuEmpInfoBResult.pageNumber
          this.paginationConfig.pageSize = insuEmpInfoBResult.pageSize
          this.paginationConfig.total = insuEmpInfoBResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async addInsuEmpInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.post(this.insuEmpInfoBFormEdit)
        this.$message.info('新增成功！')
        this.editDialogVisible = false
        this.queryInsuEmpInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateInsuEmpInfoB () {
      try {
        this.dialogLoading = true
        this.buttonLoading = true
        await Service.resources.put(this.insuEmpInfoBFormEdit)
        this.$message.info('更新成功！')
        this.editDialogVisible = false
        this.queryInsuEmpInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteInsuEmpInfoB (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryInsuEmpInfoB()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetInsuEmpInfoBEditForm () {
      this.$refs.insuEmpInfoBEditForm.resetFields()
    },
    insuEmpInfoBEditCancel () {
      this.resetInsuEmpInfoBEditForm()
      this.editDialogVisible = false
    },
    showAddDialog () {
      this.insuEmpInfoBFormEdit = new InsuEmpInfoBClass()
      this.operateType = 'add'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.insuEmpInfoBEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.insuEmpInfoBFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.insuEmpInfoBEditForm.clearValidate()
      })
    },
    insuEmpInfoBEditConfirm () {
      this.$refs.insuEmpInfoBEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateInsuEmpInfoB()
          } else {
            this.addInsuEmpInfoB()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm(
        '是否刪除?', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'info'
        }
      ).then(() => {
        this.deleteInsuEmpInfoB(row.empNo)
      })
    }
  },
  data () {
    const insuEmpInfoBColDefs = [
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位实体编码', prop: 'empEnttCodg', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位管理类型', prop: 'empMgtType', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '上级单位编号', prop: 'prntEmpNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '关联法人标志', prop: 'asocLegentFlag', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '单位类型',
        prop: 'empType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'EMP_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位名称', prop: 'empName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '注册名称', prop: 'regName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '所属行政区', prop: 'locAdmdvs', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系人姓名', prop: 'conerName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系人电子邮箱', prop: 'conerEmail', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '联系电话', prop: 'tel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '传真号码', prop: 'faxNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '税号', prop: 'taxNo', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '组织机构代码', prop: 'orgcode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '注册号', prop: 'regno', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '注册号证件类型',
        prop: 'regnoCertType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'REGNO_CERT_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '单位地址', prop: 'empAddr', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '邮政编码', prop: 'poscode', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '批准成立部门', prop: 'aprvEstaDept', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '批准成立日期',
        prop: 'aprvEstaDate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '批准成立文号', prop: 'aprvEstaDocno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '上级行政区划', prop: 'prntAdmdvs', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '参保所属机构', prop: 'insuOptins', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '组织有效状态',
        prop: 'orgValiStas',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'ORG_VALI_STAS') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '法定代表人电话号码', prop: 'legrepTel', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '法定代表人姓名', prop: 'legrepName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '法定代表人证件类型',
        prop: 'legrepCertType',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'LEGREP_CERT_TYPE') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '法定代表人证件号码', prop: 'legrepCertno', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '组织机构代码证颁发单位', prop: 'orgcodeIssuEmp', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [{ filter: cellValue => { return codeFilter(cellValue, 'VALI_FLAG') } }] },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '唯一记录号', prop: 'rid', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '数据创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '数据更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人', prop: 'crter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建人姓名', prop: 'crterName', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '创建经办机构', prop: 'crteOptins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人', prop: 'opter', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办人姓名', prop: 'opterName', width: '120px' },
      { align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '经办机构', prop: 'optins', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '统筹区', prop: 'poolarea', width: '120px' },
      { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '版本号', prop: 'ver', width: '120px' },
      { label: '操作',
        type: 'Button',
        buttonGroup: [
          { type: 'primary', icon: 'el-icon-edit', size: 'mini', handle: row => this.showEditDialog(row) },
          { type: 'danger', icon: 'el-icon-delete', size: 'mini', handle: row => this.deleteRow(row) }],
        width: '150px',
        fixed: 'right'
      }
    ]
    const insuEmpInfoBRules = {
      empEnttCodg: [{ required: true, message: '请填写单位实体编码', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      empMgtType: [{ required: true, message: '请填写单位管理类型', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      prntEmpNo: [{ required: true, message: '请填写上级单位编号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      asocLegentFlag: [{ required: true, message: '请填写关联法人标志', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      empType: [{ required: true, message: '请选择单位类型', trigger: 'change' }],
      empName: [{ required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      regName: [{ required: true, message: '请填写注册名称', trigger: 'blur' },
        { max: 255, message: '长度不能超过 255 个字符', trigger: 'blur' }
      ],
      locAdmdvs: [{ required: true, message: '请填写所属行政区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      conerName: [{ required: true, message: '请填写联系人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      conerEmail: [{ required: true, message: '请填写联系人电子邮箱', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      tel: [{ required: true, message: '请填写联系电话', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      faxNo: [{ required: true, message: '请填写传真号码', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      taxNo: [{ required: true, message: '请填写税号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      orgcode: [{ required: true, message: '请填写组织机构代码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      regno: [{ required: true, message: '请填写注册号', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      regnoCertType: [{ required: true, message: '请选择注册号证件类型', trigger: 'change' }],
      empAddr: [{ required: true, message: '请填写单位地址', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      poscode: [{ required: true, message: '请填写邮政编码', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      aprvEstaDept: [{ required: true, message: '请填写批准成立部门', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      aprvEstaDate: [{ required: true, type: 'date', message: '请选择批准成立日期', trigger: 'change' }],
      aprvEstaDocno: [{ required: true, message: '请填写批准成立文号', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      prntAdmdvs: [{ required: true, message: '请填写上级行政区划', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      insuOptins: [{ required: true, message: '请填写参保所属机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      orgValiStas: [{ required: true, message: '请选择组织有效状态', trigger: 'change' }],
      legrepTel: [{ required: true, message: '请填写法定代表人电话号码', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      legrepName: [{ required: true, message: '请填写法定代表人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      legrepCertType: [{ required: true, message: '请选择法定代表人证件类型', trigger: 'change' }],
      legrepCertno: [{ required: true, message: '请填写法定代表人证件号码', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      orgcodeIssuEmp: [{ required: true, message: '请填写组织机构代码证颁发单位', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      valiFlag: [{ required: true, message: '请选择有效标志', trigger: 'change' }],
      rid: [{ required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      crteTime: [{ required: true, type: 'date', message: '请选择数据创建时间', trigger: 'change' }],
      updtTime: [{ required: true, type: 'date', message: '请选择数据更新时间', trigger: 'change' }],
      crter: [{ required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      crterName: [{ required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteOptins: [{ required: true, message: '请填写创建经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opter: [{ required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      opterName: [{ required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [{ required: true, type: 'date', message: '请选择经办时间', trigger: 'change' }],
      optins: [{ required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ],
      poolarea: [{ required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      ver: [{ required: true, message: '请填写版本号', trigger: 'blur' },
        { max: 20, message: '长度不能超过 20 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      insuEmpInfoBTabColDefs: insuEmpInfoBColDefs,
      insuEmpInfoBList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      insuEmpInfoBFormDisabled: false,
      insuEmpInfoBFormEditDisabled: false,
      insuEmpInfoBFormQuery: new InsuEmpInfoBQueryClass(),
      insuEmpInfoBFormEdit: new InsuEmpInfoBClass(),
      insuEmpInfoBEditFormRules: insuEmpInfoBRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
