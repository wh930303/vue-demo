<template>
  <hsa-adaptive-container>
    <hsa-adaptive-pane>
      <hsa-title-pane :value="['queryForm']">
        <hsa-title-pane-item title="查询条件" name="queryForm">
          <el-form
            :model="psnInfoBFormQuery"
            label-position="right"
            label-width="120px"
            size="medium"
            @submit.native.prevent
          >
            <hsa-row collapseBtn>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员编号">
                  <el-input
                    v-model="psnInfoBFormQuery.psnNo"
                    placeholder="请输入人员编号"
                    maxlength="20"
                    @blur="blurPsnInfoB"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="人员姓名">
                  <el-input
                    v-model="psnInfoBFormQuery.psnName"
                    placeholder="请输入人员姓名"
                    maxlength="50"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="出生日期">
                  <el-date-picker
                    v-model="psnInfoBFormQuery.brdy"
                    placeholder="请输入出生日期"
                    style="width: 100%"
                    type="date"
                    format="yyyy 年 MM 月 dd 日"
                    value-format="timestamp"
                  ></el-date-picker>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="证件号码">
                  <el-input
                    v-model="psnInfoBFormQuery.certNo"
                    placeholder="请输入证件号码"
                    maxlength="30"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系电话">
                  <el-input
                    v-model="psnInfoBFormQuery.tel"
                    placeholder="请输入联系电话"
                    maxlength="50"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="民族">
                  <el-input
                    v-model="psnInfoBFormQuery.naty"
                    placeholder="请输入民族"
                    maxlength="6"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="联系地址">
                  <el-input
                    v-model="psnInfoBFormQuery.addr"
                    placeholder="请输入联系地址"
                    maxlength="200"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="性别">
                  <el-input
                    v-model="psnInfoBFormQuery.gend"
                    placeholder="请输入性别"
                    maxlength="1"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="险种">
                  <el-input
                    v-model="psnInfoBFormQuery.insutype"
                    placeholder="请输入险种"
                    maxlength="6"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位名称">
                  <el-input
                    v-model="psnInfoBFormQuery.empName"
                    placeholder="请输入单位名称"
                    maxlength="200"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="参保所属机构">
                  <el-input
                    v-model="psnInfoBFormQuery.insuOptins"
                    placeholder="请输入参保所属机构"
                    maxlength="6"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="单位编码">
                  <el-input
                    v-model="psnInfoBFormQuery.empCode"
                    placeholder="请输入单位编码"
                    maxlength="30"
                  ></el-input>
                </el-form-item>
              </hsa-col>
              <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="测试创建">
                  <el-input
                      v-model="psnInfoBFormQuery.test"
                      placeholder="请输入测试创建"
                      maxlength="255"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
              <!-- <hsa-col :sm="12" :md="8" :lg="6">
                <el-form-item label="唯一记录号">
                  <el-input
                      v-model="psnInfoBFormQuery.rid"
                      placeholder="请输入唯一记录号"
                      maxlength="40"
                      :disabled="psnInfoBFormDisabled"
                  ></el-input>
                </el-form-item>
              </hsa-col> -->
              <!-- 通过 slot="footbar" 在查询区末尾添加查询操作按钮，按钮规定使用 medium 大小 -->
              <template slot="footbar">
                <el-button size="medium" @click="clear">重置</el-button>
                <el-button type="primary" size="medium" @click="queryErChkRegD"
                  >查询</el-button
                >
              </template>
            </hsa-row>
          </el-form>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>
    <hsa-adaptive-pane :autoHeight="true">
      <hsa-title-pane :value="['queryResult']">
        <hsa-title-pane-item title="查询结果" name="queryResult">
          <!-- 通过 slot="toolbar" 在查询结果区顶部添加操作按钮 -->
          <template slot="toolbar">
            <el-button size="medium" type="success" @click="showAddDialog"
              >增加
            </el-button>
          </template>

          <ncp-table
            :columnDefs="erChkRegDTabColDefs"
            :data="erChkRegDList"
            :enablePagination="true"
            :paginationConfig="paginationConfig"
            :useExternalPagination="true"
            @paginationConfigChange="queryErChkRegD"
            v-loading="tableLoading"
            :tableHeight="tableMaxHeight"
          ></ncp-table>
        </hsa-title-pane-item>
      </hsa-title-pane>
    </hsa-adaptive-pane>

    <el-dialog
      title="急诊审核登记信息"
      :visible.sync="editDialogVisible"
      width="80%"
      :close-on-click-modal="false"
      class="hsa-dialog"
    >
      <el-form
        :model="erChkRegDFormEdit"
        label-position="right"
        label-width="120px"
        size="medium"
        :rules="erChkRegDEditFormRules"
        ref="erChkRegDEditForm"
        @submit.native.prevent
      >
        <hsa-row>
          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="待遇申报明细流水号" prop="trtDclaDetlSn">
            <el-input
                v-model="erChkRegDFormEdit.trtDclaDetlSn"
                placeholder="请输入待遇申报明细流水号"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>

        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员编号" prop="psnNo">
            <el-input
                v-model="erChkRegDFormEdit.psnNo"
                placeholder="请输入人员编号"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="人员参保关系ID" prop="psnInsuRltsId">
            <el-input
                v-model="erChkRegDFormEdit.psnInsuRltsId"
                placeholder="请输入人员参保关系ID"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件类型" prop="certType">
            <el-input
                v-model="erChkRegDFormEdit.certType"
                placeholder="请输入证件类型"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="证件号码" prop="certno">
            <el-input
                v-model="erChkRegDFormEdit.certno"
                placeholder="请输入证件号码"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="姓名" prop="psnName">
            <el-input
                v-model="erChkRegDFormEdit.psnName"
                placeholder="请输入姓名"
                maxlength="50"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="性别" prop="gend">
            <el-input
                v-model="erChkRegDFormEdit.gend"
                placeholder="请输入性别"
                maxlength="1"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="民族" prop="naty">
            <el-select v-model="erChkRegDFormEdit.naty" type="NATY" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="出生日期" prop="brdy">
            <el-date-picker
                v-model="erChkRegDFormEdit.brdy"
                placeholder="请输入出生日期"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位编号" prop="empNo">
            <el-input
                v-model="erChkRegDFormEdit.empNo"
                placeholder="请输入单位编号"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="单位名称" prop="empName">
            <el-input
                v-model="erChkRegDFormEdit.empName"
                placeholder="请输入单位名称"
                maxlength="100"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="参保所属机构" prop="insuOptins">
            <el-input
                v-model="erChkRegDFormEdit.insuOptins"
                placeholder="请输入参保所属机构"
                maxlength="10"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="险种类型" prop="insutype">
            <el-input
                v-model="erChkRegDFormEdit.insutype"
                placeholder="请输入险种类型"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
         -->
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="定点机构编码" prop="fixmedinsCode">
              <el-input
                v-model="erChkRegDFormEdit.fixmedinsCode"
                placeholder="请输入定点机构编码"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
                @blur="queryMedinsInfoB"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="定点机构名称" prop="fixmedinsName">
              <el-input
                v-model="erChkRegDFormEdit.fixmedinsName"
                placeholder="请输入定点机构名称"
                maxlength="100"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <!-- <el-form-item label="医药机构等级" prop="fixmedinsLv">
            <el-input
                v-model="erChkRegDFormEdit.fixmedinsLv"
                placeholder="请输入医药机构等级"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item> -->
            <el-form-item label="医药机构等级">
              <el-select
                v-model="erChkRegDFormEdit.fixmedinsLv"
                type="MEDINSLV"
                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="开始日期" prop="begndate">
              <el-date-picker
                v-model="erChkRegDFormEdit.begndate"
                placeholder="请输入开始日期"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="结束日期" prop="enddate">
              <el-date-picker
                v-model="erChkRegDFormEdit.enddate"
                placeholder="请输入结束日期"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
                @blur="checkBegnDate"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="入院时间" prop="admTime">
              <el-date-picker
                v-model="erChkRegDFormEdit.admTime"
                placeholder="请输入入院时间"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="入院诊断" prop="admDise">
              <el-input
                v-model="erChkRegDFormEdit.admDise"
                placeholder="请输入入院诊断"
                maxlength="100"
                :disabled="erChkRegDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="就医地行政区划" prop="mdtrtareaAdmdvs">
              <el-input
                v-model="erChkRegDFormEdit.mdtrtareaAdmdvs"
                placeholder="请输入就医地行政区划"
                maxlength="10"
                :disabled="erChkRegDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="病情描述" prop="condDscr">
              <el-input
                v-model="erChkRegDFormEdit.condDscr"
                placeholder="请输入病情描述"
                maxlength="1000"
                :disabled="erChkRegDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="留院观察标志" prop="obsvFlag">
              <el-select
                v-model="erChkRegDFormEdit.obsvFlag"
                type="OBSV_FLAG"
                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="住院号" prop="mdtrtsn">
              <el-input
                v-model="erChkRegDFormEdit.mdtrtsn"
                placeholder="请输入住院号"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="备注" prop="memo">
              <el-input
                v-model="erChkRegDFormEdit.memo"
                placeholder="请输入备注"
                maxlength="500"
                :disabled="erChkRegDFormEditDisabled"
              ></el-input>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="有效标志" prop="valiFlag">
              <el-select
                v-model="erChkRegDFormEdit.valiFlag"
                type="VALI_FLAG"
                class="widthAuto"
              ></el-select>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="更新时间" prop="updtTime">
              <el-date-picker
                v-model="erChkRegDFormEdit.updtTime"
                placeholder="请输入更新时间"
                style="width: 100%"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
              ></el-date-picker>
            </el-form-item>
          </hsa-col>
          <hsa-col :sm="24" :md="12" :lg="8">
            <el-form-item label="申报来源" prop="dclaSouc">
              <el-input
                v-model="erChkRegDFormEdit.dclaSouc"
                placeholder="请输入申报来源"
                maxlength="6"
              ></el-input>
            </el-form-item>
          </hsa-col>

          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="审核状态" prop="chkStas">
            <el-input
                v-model="erChkRegDFormEdit.chkStas"
                placeholder="请输入审核状态"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->

          <!-- <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人姓名" prop="agntName">
            <el-input
                v-model="erChkRegDFormEdit.agntName"
                placeholder="请输入代办人姓名"
                maxlength="50"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人证件类型" prop="agntCertType">
            <el-input
                v-model="erChkRegDFormEdit.agntCertType"
                placeholder="请输入代办人证件类型"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人证件号码" prop="agntCertno">
            <el-input
                v-model="erChkRegDFormEdit.agntCertno"
                placeholder="请输入代办人证件号码"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人联系方式" prop="agntTel">
            <el-input
                v-model="erChkRegDFormEdit.agntTel"
                placeholder="请输入代办人联系方式"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人联系地址" prop="agntAddr">
            <el-input
                v-model="erChkRegDFormEdit.agntAddr"
                placeholder="请输入代办人联系地址"
                maxlength="200"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="代办人关系" prop="agntRlts">
            <el-select v-model="erChkRegDFormEdit.agntRlts" type="AGNT_RLTS" class="widthAuto"></el-select>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="唯一记录号" prop="rid">
            <el-input
                v-model="erChkRegDFormEdit.rid"
                placeholder="请输入唯一记录号"
                maxlength="40"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人" prop="crter">
            <el-input
                v-model="erChkRegDFormEdit.crter"
                placeholder="请输入创建人"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建人姓名" prop="crterName">
            <el-input
                v-model="erChkRegDFormEdit.crterName"
                placeholder="请输入创建人姓名"
                maxlength="50"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建时间" prop="crteTime">
            <el-date-picker
                v-model="erChkRegDFormEdit.crteTime"
                placeholder="请输入创建时间"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="创建机构" prop="crteOptins">
            <el-input
                v-model="erChkRegDFormEdit.crteOptins"
                placeholder="请输入创建机构"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人" prop="opter">
            <el-input
                v-model="erChkRegDFormEdit.opter"
                placeholder="请输入经办人"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办人姓名" prop="opterName">
            <el-input
                v-model="erChkRegDFormEdit.opterName"
                placeholder="请输入经办人姓名"
                maxlength="50"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办时间" prop="optTime">
            <el-date-picker
                v-model="erChkRegDFormEdit.optTime"
                placeholder="请输入经办时间"
                :disabled="erChkRegDFormEditDisabled"
                style="width: 100%;"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="timestamp"
            ></el-date-picker>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="经办机构" prop="optins">
            <el-input
                v-model="erChkRegDFormEdit.optins"
                placeholder="请输入经办机构"
                maxlength="30"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col>
        <hsa-col :sm="24" :md="12" :lg="8">
          <el-form-item label="统筹区" prop="poolarea">
            <el-input
                v-model="erChkRegDFormEdit.poolarea"
                placeholder="请输入统筹区"
                maxlength="6"
                :disabled="erChkRegDFormEditDisabled"
            ></el-input>
          </el-form-item>
        </hsa-col> -->
        </hsa-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="erChkRegDEditCancel" size="medium">取 消</el-button>
        <el-button
          type="primary"
          @click="erChkRegDEditConfirm"
          size="medium"
          :loading="buttonLoading"
          :disabled="buttonLoading"
          >保 存</el-button
        >
      </div>
    </el-dialog>
  </hsa-adaptive-container>
</template>

<script>
// 如果采用架构提供的自适应布局框架，则必需引入 coreMixin
import layoutMixin from '@ncp-web/hsa-ui/lib/mixins/adaptive-layout-mixin'
import { codeFilter, tableDataFilter } from '@/common/filters/index'
// 导入对应的 service，service 命名采用小驼峰，同文件名保持一直
import Service from './er-chk-reg-d-mngr.service'
import ErChkRegDClass from '@/modules/demo/class/er-chk-reg-d-mngr.class'
import ErChkRegDQueryClass from '@/modules/demo/class/er-chk-reg-d-mngr-query.class'
import psnInfoBService from '@/common/utils/core/psn-info-b'
import PsnInfoBQueryClass from '@/modules/demo/class/psn-info-b-mngr-query.class'
import PsnInsuDQueryClass from '@/modules/demo/class/psn-insu-d-mngr-query.class'
import MedinsInfoBQueryClass from '@/modules/demo/class/medins-info-b-mngr-query.class'
export default {
  // 如果采用架构提供的自适应布局框架，则必需 mixin coreMixin
  mixins: [layoutMixin],
  // 初始化页面数据在 created 生命周期钩子中进行
  created () {},
  // 通过 $refs 对页面进行初始化的操作一律在 mounted 生命周期钩子中进行
  mounted () {},
  computed: {},
  methods: {
    clear () {
      this.erChkRegDFormQuery = new ErChkRegDQueryClass()
      this.erChkRegDFormEdit = new ErChkRegDClass()
      this.psnInfoBFormQuery = new PsnInfoBQueryClass()
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.medinsInfoBFormQuery = new MedinsInfoBQueryClass()
      this.paginationConfig = {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      }
      this.erChkRegDList = []
      this.tableLoading = false
      this.editDialogVisible = false
      this.dialogLoading = false
      this.erChkRegDFormDisabled = false
      this.erChkRegDFormEditDisabled = false
    },
    // 查询个人基本信息
    async blurPsnInfoB () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo != null && psnNo !== '') {
        try {
          this.psnInfoBFormQuery = new PsnInfoBQueryClass()
          this.psnInfoBFormQuery.psnNo = psnNo
          const psnInfoBResult = await psnInfoBService.getPsnInfoB(
            this.psnInfoBFormQuery
          )
          if (psnInfoBResult.length !== 0) {
            this.psnInfoBFormQuery = psnInfoBResult[0]
          }
        } catch (err) {
          let errStr = err.message
          this.$message.error('查询失败！' + errStr)
        }
      } else {
        this.psnInfoBFormQuery = new PsnInfoBQueryClass()
        this.psnInfoBFormQuery.psnNo = psnNo
      }
    },
    async checkIsPass () {
      this.psnInsuDFormQuery = new PsnInsuDQueryClass()
      this.psnInsuDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
      const psnInsuDResult = await psnInfoBService.getPsnInsuD(
        this.psnInsuDFormQuery
      )
      // 已经参保且参保状正常
      if (psnInsuDResult.length > 0 && psnInsuDResult[0].psnInsuStas === '1') {
        this.psnInsuDFormQuery = psnInsuDResult[0]
        return true
      } else {
        return false
      }
    },
    // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
    checkBegnDate () {
      const begnDate = this.erChkRegDFormEdit.begndate
      const endDate = this.erChkRegDFormEdit.enddate
      if (
        begnDate != null &&
        begnDate !== '' &&
        endDate != null &&
        endDate !== ''
      ) {
        if (begnDate > endDate) {
          this.$message.error('开始日期不得晚于结束日期!')
          return false
        }
      }
      return true
    },
    // 查询开始时间和结束时间相交的信息
    async checkOverlapping () {
      try {
        this.erChkRegDFormQuery = new ErChkRegDQueryClass()
        this.erChkRegDFormQuery.rid = this.erChkRegDFormEdit.rid
        this.erChkRegDFormQuery.psnNo = this.erChkRegDFormEdit.psnNo
        if (
          this.erChkRegDFormEdit.begndate != null &&
          this.erChkRegDFormEdit.begndate !== ''
        ) {
          this.erChkRegDFormQuery.begndate = new Date(
            this.erChkRegDFormEdit.begndate
          ).getTime()
        }

        if (
          this.erChkRegDFormEdit.enddate != null &&
          this.erChkRegDFormEdit.enddate !== ''
        ) {
          this.erChkRegDFormQuery.enddate = new Date(
            this.erChkRegDFormEdit.enddate
          ).getTime()
        } else {
          this.erChkRegDFormQuery.enddate = new Date(
            this.erChkRegDFormEdit.begndate
          )
          this.erChkRegDFormQuery.enddate.setDate(
            this.erChkRegDFormQuery.enddate.getDate() + 1
          )
          this.erChkRegDFormQuery.enddate = new Date(
            this.erChkRegDFormQuery.enddate
          ).getTime()
        }
        const reflAppyDResult = await Service.resources.queryOverlapping(
          this.erChkRegDFormQuery
        )
        if (reflAppyDResult.length === 0) {
          return true
        } else {
          this.$message.error(
            '与其他登记信息的开始日期和结束日期不能交叉、重叠!'
          )
          return false
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.erChkRegDFormQuery = new ErChkRegDQueryClass()
      }
    },
    // 查询医药机构信息
    async queryMedinsInfoB () {
      this.medinsInfoBFormQuery.medinsNo = this.erChkRegDFormEdit.fixmedinsCode
      if (
        this.medinsInfoBFormQuery.medinsNo != null &&
        this.medinsInfoBFormQuery.medinsNo !== ''
      ) {
        const result = await psnInfoBService.getMedinsInfoB(
          this.medinsInfoBFormQuery
        )
        // 存在医药机构信息且有效
        if (result.length > 0 && result[0].valiFlag === '1') {
          // 医药机构名称
          this.erChkRegDFormEdit.fixmedinsName = result[0].medinsName
          // 医药机构等级
          this.erChkRegDFormEdit.fixmedinsLv = result[0].medinslv
        } else {
          this.erChkRegDFormEdit.fixmedinsName = ''
          this.erChkRegDFormEdit.fixmedinsLv = ''
          this.$message.error('该医药机构不存在或无效！')
        }
        this.checkMedins()
      } else {
        this.erChkRegDFormEdit.fixmedinsName = ''
        this.erChkRegDFormEdit.fixmedinsLv = ''
      }
    },
    // 异步调用，一律采用 async/await 语法
    async queryErChkRegD () {
      try {
        this.erChkRegDFormQuery.psnNo = this.psnInfoBFormQuery.psnNo
        this.tableLoading = true
        const erChkRegDResult = await Service.resources.getByPage(
          this.erChkRegDFormQuery,
          this.paginationConfig
        )
        if (erChkRegDResult.result.length === 0) {
          this.$message.info('没有查询到数据！')
          this.erChkRegDList = []
        } else {
          this.erChkRegDList = erChkRegDResult.result
          this.paginationConfig.pageNumber = erChkRegDResult.pageNumber
          this.paginationConfig.pageSize = erChkRegDResult.pageSize
          this.paginationConfig.total = erChkRegDResult.total
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('查询失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    async saveBeforeCheck () {
      // 验证开始日期（开始日期默认为系统日期，允许修改。开始日期不得晚于结束日期）
      const flag1 = this.checkBegnDate()
      if (flag1) {
        // 转出医院不能和转入医院相同
        const flag2 = await this.checkOverlapping()
        if (flag2) {
          return true
        }
      }
      return false
    },
    async addErChkRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.post(this.erChkRegDFormEdit)
          this.$message.info('新增成功！')
          this.editDialogVisible = false
          this.queryErChkRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('新增失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async updateErChkRegD () {
      try {
        const flag = await this.saveBeforeCheck()
        if (flag) {
          this.dialogLoading = true
          this.buttonLoading = true
          await Service.resources.put(this.erChkRegDFormEdit)
          this.$message.info('更新成功！')
          this.editDialogVisible = false
          this.queryErChkRegD()
        }
      } catch (err) {
        let errStr = err.message
        this.$message.error('更新失败！' + errStr)
      } finally {
        this.dialogLoading = false
        this.buttonLoading = false
      }
    },
    async deleteErChkRegD (id) {
      try {
        this.tableLoading = true
        await Service.resources.delete(id)
        this.$message.info('删除成功！')
        this.queryErChkRegD()
      } catch (err) {
        let errStr = err.message
        this.$message.error('删除失败！' + errStr)
      } finally {
        this.tableLoading = false
      }
    },
    resetErChkRegDEditForm () {
      this.$refs.erChkRegDEditForm.resetFields()
    },
    erChkRegDEditCancel () {
      this.resetErChkRegDEditForm()
      this.editDialogVisible = false
    },
    async showAddDialog () {
      const psnNo = this.psnInfoBFormQuery.psnNo
      if (psnNo == null || psnNo === '') {
        this.$message.info('请输入人员编号！')
        return
      }
      const flag = await this.checkIsPass()
      if (!flag) {
        this.$message.info('该用户未参保或参保状态异常！')
        return
      }
      this.erChkRegDFormEdit = new ErChkRegDClass()
      this.operateType = 'add'
      // 添加默认信息
      this.erChkRegDFormEdit.dclaSouc = '中心经办系统'
      this.erChkRegDFormEdit.begndate = new Date()
      this.erChkRegDFormEdit.updtTime = new Date()
      this.erChkRegDFormEdit.valiFlag = '1'
      this.erChkRegDFormEdit.chkStas = '1' // 审核状态：审批通过

      // 添加个人基本信息
      this.erChkRegDFormEdit.psnNo = this.psnInfoBFormQuery.psnNo
      this.erChkRegDFormEdit.certno = this.psnInfoBFormQuery.certNo
      this.erChkRegDFormEdit.psnName = this.psnInfoBFormQuery.psnName
      this.erChkRegDFormEdit.gend = this.psnInfoBFormQuery.gend
      this.erChkRegDFormEdit.naty = '0' // 汉族
      this.erChkRegDFormEdit.brdy = this.psnInfoBFormQuery.brdy
      this.erChkRegDFormEdit.tel = this.psnInfoBFormQuery.tel
      this.erChkRegDFormEdit.addr = this.psnInfoBFormQuery.addr
      this.erChkRegDFormEdit.insuOptins = this.psnInfoBFormQuery.insuOptins
      this.erChkRegDFormEdit.empNo = this.psnInfoBFormQuery.empCode
      this.erChkRegDFormEdit.empName = this.psnInfoBFormQuery.empName
      this.erChkRegDFormEdit.certType = '0' // 身份证
      this.erChkRegDFormEdit.insutype = this.psnInfoBFormQuery.insutype
      // 添加人员参保关系ID
      this.erChkRegDFormEdit.psnInsuRltsId =
        this.psnInsuDFormQuery.psnInsuRltsId
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.erChkRegDEditForm.clearValidate()
      })
    },
    showEditDialog (row) {
      this.erChkRegDFormEdit = Object.assign({}, row)
      this.operateType = 'update'
      this.editDialogVisible = true
      this.$nextTick(() => {
        this.$refs.erChkRegDEditForm.clearValidate()
      })
    },
    erChkRegDEditConfirm () {
      this.$refs.erChkRegDEditForm.validate((valid) => {
        if (valid) {
          if (this.operateType === 'update') {
            this.updateErChkRegD()
          } else {
            this.addErChkRegD()
          }
        } else {
          return false
        }
      })
    },
    deleteRow (row) {
      this.$confirm('是否刪除?', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'info'
      }).then(() => {
        this.deleteErChkRegD(row.trtDclaDetlSn)
      })
    }
  },
  data () {
    const erChkRegDColDefs = [
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '申报来源',
        prop: 'dclaSouc',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员编号',
        prop: 'psnNo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '人员参保关系ID',
        prop: 'psnInsuRltsId',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '证件类型',
        prop: 'certType',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '证件号码',
        prop: 'certno',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '姓名',
        prop: 'psnName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '性别',
        prop: 'gend',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '民族',
        prop: 'naty',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'NATY')
            }
          }
        ]
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '出生日期',
        prop: 'brdy',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '单位编号',
        prop: 'empNo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '单位名称',
        prop: 'empName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '参保所属机构',
        prop: 'insuOptins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '险种类型',
        prop: 'insutype',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '就医地行政区划',
        prop: 'mdtrtareaAdmdvs',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '定点机构编码',
        prop: 'fixmedinsCode',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '定点机构名称',
        prop: 'fixmedinsName',
        width: '120px'
      },
      // { align: 'left', showOverflowTooltip: true, headerAlign: 'center', label: '医药机构等级', prop: 'fixmedinsLv', width: '120px' },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '医药机构等级',
        prop: 'fixmedinsLv',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'MEDINSLV')
            }
          }
        ]
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '入院时间',
        prop: 'admTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '入院诊断',
        prop: 'admDise',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '病情描述',
        prop: 'condDscr',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '留院观察标志',
        prop: 'obsvFlag',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'OBSV_FLAG')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '住院号',
        prop: 'mdtrtsn',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人姓名',
        prop: 'agntName',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人证件类型',
        prop: 'agntCertType',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人证件号码',
        prop: 'agntCertno',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人联系方式',
        prop: 'agntTel',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人联系地址',
        prop: 'agntAddr',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '代办人关系',
        prop: 'agntRlts',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'AGNT_RLTS')
            }
          }
        ]
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '开始日期',
        prop: 'begndate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '结束日期',
        prop: 'enddate',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '有效标志',
        prop: 'valiFlag',
        width: '120px',
        filters: [
          {
            filter: (cellValue) => {
              return codeFilter(cellValue, 'VALI_FLAG')
            }
          }
        ]
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '审核状态',
        prop: 'chkStas',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '备注',
        prop: 'memo',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '唯一记录号',
        prop: 'rid',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '更新时间',
        prop: 'updtTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建人',
        prop: 'crter',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建人姓名',
        prop: 'crterName',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建时间',
        prop: 'crteTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '创建机构',
        prop: 'crteOptins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办人',
        prop: 'opter',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办人姓名',
        prop: 'opterName',
        width: '120px'
      },
      {
        align: 'center',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办时间',
        prop: 'optTime',
        filters: [{ filter: tableDataFilter, params: ['yyyy年mm月dd日'] }],
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '经办机构',
        prop: 'optins',
        width: '120px'
      },
      {
        align: 'left',
        showOverflowTooltip: true,
        headerAlign: 'center',
        label: '统筹区',
        prop: 'poolarea',
        width: '120px'
      },
      {
        label: '操作',
        type: 'Button',
        buttonGroup: [
          {
            type: 'primary',
            icon: 'el-icon-edit',
            size: 'mini',
            handle: (row) => this.showEditDialog(row)
          },
          {
            type: 'danger',
            icon: 'el-icon-delete',
            size: 'mini',
            handle: (row) => this.deleteRow(row)
          }
        ],
        width: '150px',
        fixed: 'right'
      }
    ]
    const erChkRegDRules = {
      dclaSouc: [
        { required: true, message: '请填写申报来源', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      psnNo: [
        { required: true, message: '请填写人员编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnInsuRltsId: [
        { required: true, message: '请填写人员参保关系ID', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      certType: [
        { required: true, message: '请填写证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      certno: [
        { required: true, message: '请填写证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      psnName: [
        { required: true, message: '请填写姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      gend: [
        { required: true, message: '请填写性别', trigger: 'blur' },
        { max: 1, message: '长度不能超过 1 个字符', trigger: 'blur' }
      ],
      naty: [{ required: true, message: '请选择民族', trigger: 'change' }],
      brdy: [
        {
          required: true,
          type: 'date',
          message: '请选择出生日期',
          trigger: 'change'
        }
      ],
      empNo: [
        { required: true, message: '请填写单位编号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      empName: [
        { required: true, message: '请填写单位名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      insuOptins: [
        { required: true, message: '请填写参保所属机构', trigger: 'blur' },
        { max: 10, message: '长度不能超过 10 个字符', trigger: 'blur' }
      ],
      insutype: [
        { required: true, message: '请填写险种类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      mdtrtareaAdmdvs: [
        { required: false, message: '请填写就医地行政区划', trigger: 'blur' },
        { max: 10, message: '长度不能超过 10 个字符', trigger: 'blur' }
      ],
      fixmedinsCode: [
        { required: true, message: '请填写定点机构编码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      fixmedinsName: [
        { required: false, message: '请填写定点机构名称', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      // fixmedinsLv: [{  required:true, message: '请填写医药机构等级', trigger: 'blur' },
      //   {  max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      // ],
      fixmedinsLv: [
        { required: false, message: '请选择医疗机构等级', trigger: 'change' }
      ],
      admTime: [
        {
          required: false,
          type: 'date',
          message: '请选择入院时间',
          trigger: 'change'
        }
      ],
      admDise: [
        { required: false, message: '请填写入院诊断', trigger: 'blur' },
        { max: 100, message: '长度不能超过 100 个字符', trigger: 'blur' }
      ],
      condDscr: [
        { required: false, message: '请填写病情描述', trigger: 'blur' },
        { max: 1000, message: '长度不能超过 1000 个字符', trigger: 'blur' }
      ],
      obsvFlag: [
        { required: false, message: '请选择留院观察标志', trigger: 'change' }
      ],
      mdtrtsn: [
        { required: false, message: '请填写住院号', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntName: [
        { required: true, message: '请填写代办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      agntCertType: [
        { required: true, message: '请填写代办人证件类型', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      agntCertno: [
        { required: true, message: '请填写代办人证件号码', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntTel: [
        { required: true, message: '请填写代办人联系方式', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      agntAddr: [
        { required: true, message: '请填写代办人联系地址', trigger: 'blur' },
        { max: 200, message: '长度不能超过 200 个字符', trigger: 'blur' }
      ],
      agntRlts: [
        { required: true, message: '请选择代办人关系', trigger: 'change' }
      ],
      begndate: [
        {
          required: true,
          type: 'date',
          message: '请选择开始日期',
          trigger: 'change'
        }
      ],
      enddate: [
        {
          required: false,
          type: 'date',
          message: '请选择结束日期',
          trigger: 'change'
        }
      ],
      valiFlag: [
        { required: true, message: '请选择有效标志', trigger: 'change' }
      ],
      chkStas: [
        { required: true, message: '请填写审核状态', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ],
      memo: [
        { required: false, message: '请填写备注', trigger: 'blur' },
        { max: 500, message: '长度不能超过 500 个字符', trigger: 'blur' }
      ],
      rid: [
        { required: true, message: '请填写唯一记录号', trigger: 'blur' },
        { max: 40, message: '长度不能超过 40 个字符', trigger: 'blur' }
      ],
      updtTime: [
        {
          required: true,
          type: 'date',
          message: '请选择更新时间',
          trigger: 'change'
        }
      ],
      crter: [
        { required: true, message: '请填写创建人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      crterName: [
        { required: true, message: '请填写创建人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      crteTime: [
        {
          required: true,
          type: 'date',
          message: '请选择创建时间',
          trigger: 'change'
        }
      ],
      crteOptins: [
        { required: true, message: '请填写创建机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opter: [
        { required: true, message: '请填写经办人', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      opterName: [
        { required: true, message: '请填写经办人姓名', trigger: 'blur' },
        { max: 50, message: '长度不能超过 50 个字符', trigger: 'blur' }
      ],
      optTime: [
        {
          required: true,
          type: 'date',
          message: '请选择经办时间',
          trigger: 'change'
        }
      ],
      optins: [
        { required: true, message: '请填写经办机构', trigger: 'blur' },
        { max: 30, message: '长度不能超过 30 个字符', trigger: 'blur' }
      ],
      poolarea: [
        { required: true, message: '请填写统筹区', trigger: 'blur' },
        { max: 6, message: '长度不能超过 6 个字符', trigger: 'blur' }
      ]
    }

    // 所有的属性定义在 return 中
    return {
      // 所有的属性名都用小驼峰命名法
      // data 中声明的所有变量都要在页面的清屏方法中重置，并同声明时保持一致
      // 个别特殊属性可以不在清屏方法中处理
      paginationConfig: {
        pageSize: 10,
        pageNumber: 1,
        total: 0
      },
      erChkRegDTabColDefs: erChkRegDColDefs,
      erChkRegDList: [],
      tableLoading: false,
      dialogLoading: false,
      buttonLoading: false,
      editDialogVisible: false,
      erChkRegDFormDisabled: false,
      erChkRegDFormEditDisabled: false,
      erChkRegDFormQuery: new ErChkRegDQueryClass(),
      erChkRegDFormEdit: new ErChkRegDClass(),
      psnInfoBFormQuery: new PsnInfoBQueryClass(),
      psnInsuDFormQuery: new PsnInsuDQueryClass(),
      medinsInfoBFormQuery: new MedinsInfoBQueryClass(),
      erChkRegDEditFormRules: erChkRegDRules
    }
  }
}
</script>

<style lang="scss" scoped></style>
