/*
 * @Author: your name
 * @Date: 2022-03-01 21:50:24
 * @LastEditTime: 2022-03-02 14:23:43
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: /vue-demo/src/modules/demo/er-chk-reg-d/er-chk-reg-d-mngr.router.js
 */
/*
* Created: 2021-01-04
* Author: wanghao
* Description:
* -----
* Modified: 2021-01-04
* Modified By: wanghao
* Description:
*/
export default {
// path 保证全局唯一
  path: '/er-chk-reg-d',
  component: () => import('@/modules/demo/er-chk-reg-d/er-chk-reg-d-mngr.vue'),
  // typeList 中编写模块所需二级代码
  meta: { typeList: [
    'NATY',
    'MEDINSLV',
    'OBSV_FLAG',
    'AGNT_RLTS',
    'VALI_FLAG'
  ] }
}
